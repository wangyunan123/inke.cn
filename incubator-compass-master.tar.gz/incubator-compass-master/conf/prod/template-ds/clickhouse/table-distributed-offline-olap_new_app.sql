CREATE TABLE IF NOT EXISTS {{database_name}}.olap_new_app on cluster  default_cluster AS {{database_name}}.olap_new_app_local 
ENGINE = Distributed(default_cluster, {{database_name}},olap_new_app_local , rand());

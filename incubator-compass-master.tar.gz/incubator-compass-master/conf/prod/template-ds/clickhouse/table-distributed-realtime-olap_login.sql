CREATE TABLE IF NOT EXISTS {{database_name}}.olap_realtime_login on cluster  default_cluster AS {{database_name}}.olap_realtime_login_local 
ENGINE = Distributed(default_cluster, {{database_name}},olap_realtime_login_local , rand());

CREATE TABLE IF NOT EXISTS {{database_name}}.olap_realtime_new on cluster  default_cluster AS {{database_name}}.olap_realtime_new_local 
ENGINE = Distributed(default_cluster, {{database_name}},olap_realtime_new_local , rand());

--分布式表
CREATE TABLE IF NOT EXISTS {{database_name}}.kafka_{{database_name}}_transform on cluster  default_cluster   AS {{database_name}}.kafka_{{database_name}}_transform_local 
ENGINE = Distributed(default_cluster, {{database_name}},kafka_{{database_name}}_transform_local , rand());
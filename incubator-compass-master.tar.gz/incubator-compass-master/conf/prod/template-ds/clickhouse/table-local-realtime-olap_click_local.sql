-- 点击表

CREATE TABLE IF NOT EXISTS  {{database_name}}.olap_realtime_click_local on cluster default_cluster
(
    `uid` Nullable(UInt64),
    `md_mod` Nullable(String),
    `record_time` Nullable(String),
    `cv` Nullable(String),
    `cc` Nullable(String),
    `ua` Nullable(String),
    `smid` Nullable(String),
    `imei` Nullable(String),
    `oaid` Nullable(String),
    `idfa` Nullable(String),
    `ndid` Nullable(String),
    `conn` Nullable(String),
    `osversion` Nullable(String),
    `ip` Nullable(String),
    `logid` Nullable(String),
    `ropklv` Nullable(String),
    `client` Nullable(String),
    `apm` Nullable(String),
    `xpath` Nullable(String),
    `appname` Nullable(String),
    `ymd` String,
    `eid` Nullable(String),
    `ename` Nullable(String)
)
ENGINE = ReplicatedMergeTree('/clickhouse/table/{shard}/{{database_name}}/olap_realtime_click_local', '{replica}')
    PARTITION BY ymd
    ORDER BY (ymd)
    SETTINGS
        index_granularity = 8192;;

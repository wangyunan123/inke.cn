CREATE TABLE IF NOT EXISTS {{database_name}}.olap_user_lost on cluster  default_cluster AS {{database_name}}.olap_user_lost_local 
ENGINE = Distributed(default_cluster, {{database_name}},olap_user_lost_local , rand());

CREATE TABLE IF NOT EXISTS {{database_name}}.olap_realtime_pay on cluster  default_cluster AS {{database_name}}.olap_realtime_pay_local 
ENGINE = Distributed(default_cluster, {{database_name}},olap_realtime_pay_local , rand());

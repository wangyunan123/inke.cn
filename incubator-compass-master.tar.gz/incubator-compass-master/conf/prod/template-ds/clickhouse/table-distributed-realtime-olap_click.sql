CREATE TABLE IF NOT EXISTS {{database_name}}.olap_realtime_click on cluster  default_cluster AS {{database_name}}.olap_realtime_click_local 
ENGINE = Distributed(default_cluster, {{database_name}},olap_realtime_click_local , rand());

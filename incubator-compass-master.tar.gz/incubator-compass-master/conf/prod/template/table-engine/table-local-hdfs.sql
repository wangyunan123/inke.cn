CREATE TABLE IF NOT EXISTS {{app_name}}.{{database_name}}_{{table_name}}_local ON CLUSTER {{cluster_name}}
(
    {{columns}}
)
    ENGINE = MergeTree
    PARTITION BY (ymd)
    ORDER BY (ymd)
    SETTINGS
        index_granularity = 8192;;
CREATE MATERIALIZED VIEW IF NOT EXISTS {{database_name}}.olap_kafka_{{kafka_cluster_topic}}_view_local TO {{database_name}}.{{kafka_cluster_topic}}_local ON CLUSTER {{cluster_name}}
(
    {{columns}}
)
SELECT
    {{columns}}
FROM
    {{database_name}}.kafka_{{kafka_cluster_topic}}_transform_local
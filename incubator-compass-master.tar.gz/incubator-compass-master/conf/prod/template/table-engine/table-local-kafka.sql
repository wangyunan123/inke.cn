CREATE MATERIALIZED VIEW IF NOT EXISTS {{database_name}}.olap_kafka_{{kafka_cluster_topic}}_local ON CLUSTER {{cluster_name}}
(
    {{columns}}
)
    ENGINE = MergeTree
    PARTITION BY (ymd)
    ORDER BY (ymd)
    SETTINGS
        index_granularity = 8192;;
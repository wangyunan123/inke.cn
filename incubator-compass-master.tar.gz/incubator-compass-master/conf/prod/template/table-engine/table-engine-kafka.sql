CREATE TABLE IF NOT EXISTS {{database_name}}.olap_kafka_{{kafka_cluster_topic}}_transform_local on cluster {{cluster_name}}
(
    {{columns}}
) ENGINE = Kafka
    SETTINGS
    kafka_broker_list = '{{kafka_cluster}}',
    kafka_topic_list = '{{kafka_cluster_topic}}',
    kafka_group_name = '{{database_name}}-olap-{{cluster_name}}',
    kafka_format = 'JSONEachRow',
    kafka_num_consumers = 6,
    kafka_max_block_size = 1048576,
    kafka_skip_broken_messages = 1048577;;
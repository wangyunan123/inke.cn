CREATE TABLE IF NOT EXISTS {{app_name}}.{{database_name}}_{{table_name}}_{{partition}} ON CLUSTER {{cluster_name}}
(
    {{columns}}
)
    ENGINE = HDFS('hdfs://{{hdfs}}/user/hive/warehouse/{{database_name}}.db/{{table_name}}/ymd={{partition}}/*', '{{table_engine}}')

-- 用户流失

CREATE TABLE {{database_name}}.olap_fs_pay_local on cluster {{cluster_name}}
(
    `uid` Nullable(UInt64),
    `agree_time` Nullable(String),
    `reg_time` Nullable(String),
    `active_time` Nullable(String),
    `money` Nullable(UInt64),
    `manner` Nullable(String),
    `sub_manner` Nullable(String),
    `coin_type` Nullable(String),
    `client` Nullable(String),
    `cv` Nullable(String),
    `apm` Nullable(String),
    `cc` Nullable(String),
    `cc_agent_name` Nullable(String),
    `op_type` Nullable(String),
    `cc_level1_name` Nullable(String),
    `cc_level2_name` Nullable(String),
    `cc_level3_name` Nullable(String),
    `channel` Nullable(String),
    `chl_agent_name` Nullable(String),
    `chl_level1_name` Nullable(String),
    `chl_level2_name` Nullable(String),
    `chl_level3_name` Nullable(String),
    `campaign_id` Nullable(String),
    `adgroup_id` Nullable(String),
    `creative_id` Nullable(String),
    `dt` Nullable(String),
    `yw` String,
    `ym` String,
    `is_new_uid` Nullable(UInt32),
    `is_new_smid` Nullable(UInt32),
    `pay_layer` Nullable(String),
    `bill_id` String,
    `ymd` String
)
ENGINE = MergeTree
    PARTITION BY (ymd, yw, ym)
    ORDER BY (ymd, yw, ym, bill_id)
    SETTINGS
        index_granularity = 8192;;

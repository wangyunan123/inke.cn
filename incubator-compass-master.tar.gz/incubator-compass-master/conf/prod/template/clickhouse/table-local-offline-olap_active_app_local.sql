-- 创建活跃数据本地表

CREATE TABLE IF NOT EXISTS {{database_name}}.olap_active_app_local on cluster {{cluster_name}}
(
    `uid`                Nullable(UInt64) COMMENT '用户ID',
    `client`             Nullable(String) COMMENT '端',
    `md_mod`             Nullable(Int32),
    `session`            Nullable(String) COMMENT '一次会话session',
    `event_time`         Nullable(String) COMMENT '活跃时间',
    `smid`               Nullable(String) COMMENT '数盟ID',
    `imei`               Nullable(String) COMMENT '手机串号imei',
    `oaid`               Nullable(String) COMMENT 'oaid',
    `idfa`               Nullable(String) COMMENT 'ios设备idfa',
    `cc`                 Nullable(String) COMMENT '渠道',
    `agent_name`         Nullable(String),
    `op_type`            Nullable(String),
    `cc_level1_name`     Nullable(String),
    `cc_level2_name`     Nullable(String),
    `cc_level3_name`     Nullable(String),
    `cv`                 Nullable(String) COMMENT '客户端版本',
    `apm`                Nullable(String) COMMENT 'cv前缀',
    `ip`                 Nullable(String) COMMENT 'ip',
    `country`            Nullable(String) COMMENT 'ip地域国家',
    `prov`               Nullable(String) COMMENT 'ip地域省份',
    `city`               Nullable(String) COMMENT 'ip地域城市',
    `operator`           Nullable(String) COMMENT '网络运营商',
    `brand`              Nullable(String) COMMENT '手机品牌',
    `conn`               Nullable(String) COMMENT '网络连接方式',
    `osversion`          Nullable(String) COMMENT '手机系统版本',
    `dt`                 Nullable(String) COMMENT '活跃日期',
    `yw`                 String COMMENT '自然周',
    `ym`                 String COMMENT '自然月',
    `reg_dt`             Nullable(String),
    `reg_distance_layer` Nullable(String) COMMENT '注册距离分层：注册0天、注册1-7天、注册8-30天、注册大于31天',
    `smid_active_layer`  Nullable(String) COMMENT '设备活跃分层',
    `smid_is_black`      Nullable(Int32) COMMENT 'smid是否黑名单',
    `uid_is_black`       Nullable(Int32) COMMENT 'uid是否黑名单',
    `ymd`                String COMMENT '分区字段：活跃日期'
) ENGINE = MergeTree
    PARTITION BY (ymd, yw, ym)
    ORDER BY (ym, yw, ymd)
    SETTINGS
    index_granularity = 8192;;

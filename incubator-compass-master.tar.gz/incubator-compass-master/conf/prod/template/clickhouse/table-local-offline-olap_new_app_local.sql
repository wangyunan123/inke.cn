-- 用户新增

CREATE TABLE IF NOT EXISTS {{database_name}}.olap_new_app_local ON CLUSTER {{cluster_name}}
(
    `uid` Nullable(UInt64),
    `client` Nullable(String),
    `active_time` Nullable(String),
    `reg_time` Nullable(String),
    `smid` Nullable(String),
    `imei` Nullable(String),
    `oaid` Nullable(String),
    `idfa` Nullable(String),
    `cc` Nullable(String),
    `cc_agent_name` Nullable(String),
    `op_type` Nullable(String),
    `cc_level1_name` Nullable(String),
    `cc_level2_name` Nullable(String),
    `cc_level3_name` Nullable(String),
    `channel` Nullable(String),
    `chl_agent_name` Nullable(String),
    `chl_level1_name` Nullable(String),
    `chl_level2_name` Nullable(String),
    `chl_level3_name` Nullable(String),
    `campaign_id` Nullable(String),
    `adgroup_id` Nullable(String),
    `creative_id` Nullable(String),
    `cv` Nullable(String),
    `apm` Nullable(String),
    `ip` Nullable(String),
    `country` Nullable(String),
    `prov` Nullable(String),
    `city` Nullable(String),
    `operator` Nullable(String),
    `brand` Nullable(String),
    `dt` Nullable(String),
    `yw` String,
    `ym` String,
    `is_new_smid` Nullable(UInt32),
    `is_new_uid` Nullable(UInt32),
    `smid_is_black` Nullable(UInt32),
    `uid_is_black` Nullable(UInt32),
    `ymd` String
)
ENGINE = MergeTree
    PARTITION BY (ymd, yw, ym)
    ORDER BY (ymd, yw, ym)
    SETTINGS
        index_granularity = 8192;;

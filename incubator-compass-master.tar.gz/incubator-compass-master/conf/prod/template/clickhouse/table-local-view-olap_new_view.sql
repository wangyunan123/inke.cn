-- 点击物化表

CREATE MATERIALIZED VIEW IF NOT EXISTS {{database_name}}.olap_realtime_new_view  ON CLUSTER {{cluster_name}} TO {{database_name}}.olap_realtime_new_local (
    uid Nullable(UInt64) COMMENT '用户ID',
    client Nullable(String) COMMENT '端',
    active_time Nullable(String) COMMENT '设备激活时间',
    smid Nullable(String) COMMENT '数盟ID',
    imei Nullable(String) COMMENT '手机串号imei',
    oaid Nullable(String) COMMENT 'oaid',
    idfa Nullable(String) COMMENT 'ios设备idfa',
    cc Nullable(String) COMMENT '渠道',
    cv Nullable(String) COMMENT '客户端版本',
    apm Nullable(String) COMMENT 'cv前缀',
    ip Nullable(String) COMMENT 'ip',
    conn Nullable(String) COMMENT '网络连接方式',
    dt Nullable(String) COMMENT '活跃日期',
    `hour` Nullable(String),
    yw Nullable(String) COMMENT '自然周',
    ym Nullable(String) COMMENT '自然月',
    ymd Nullable(String) comment '分区字段：新增日期'
) AS
SELECT
    uid,
    client,
    active_time,
    smid,
    imei,
    oaid,
    idfa,
    cc,
    cv,
    apm,
    ip,
    conn,
    dt,
    substr(active_time, 12, 2) as hour,
    yw,
    ym,
    ymd
FROM {{database_name}}.olap_kafka_{{database_name}}_new_transform_local;;

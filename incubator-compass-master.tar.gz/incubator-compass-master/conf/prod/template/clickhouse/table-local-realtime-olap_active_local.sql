-- 点击表

CREATE TABLE IF NOT EXISTS {{database_name}}.olap_realtime_active_local  on cluster {{cluster_name}}
(
    `md_eid` Nullable(String),
    `uid` Nullable(UInt64),
    `md_mod` Nullable(String),
    `md_session` Nullable(String),
    `md_etime` Nullable(String),
    `record_time` Nullable(String),
    `md_path` Nullable(String),
    `md_einfo` Nullable(String),
    `lc` Nullable(String),
    `cv` Nullable(String),
    `cc` Nullable(String),
    `ua` Nullable
(
    String
),
    `devi` Nullable
(
    String
),
    `imsi` Nullable
(
    String
),
    `imei` Nullable
(
    String
),
    `smid` Nullable
(
    String
),
    `deviceid` Nullable
(
    String
),
    `aid` Nullable
(
    String
),
    `conn` Nullable
(
    String
),
    `osversion` Nullable
(
    String
),
    `proto` Nullable
(
    String
),
    `idfa` Nullable
(
    String
),
    `idfv` Nullable
(
    String
),
    `client_ip` Nullable
(
    String
),
    `md_logid` Nullable
(
    String
),
    `jb` Nullable
(
    String
),
    `seq` Nullable
(
    String
),
    `md_etype` Nullable
(
    String
),
    `latitude` Nullable
(
    String
),
    `longitude` Nullable
(
    String
),
    `ymd` String,
    `year` Nullable
(
    String
),
    `ym` Nullable
(
    String
),
    `hour` Nullable
(
    String
)
    )
    ENGINE = MergeTree
    PARTITION BY ymd
    ORDER BY
(
    ymd
)
    SETTINGS
    index_granularity = 8192;;

-- 创建流失物化视图表

CREATE MATERIALIZED VIEW IF NOT EXISTS {{database_name}}.olap_user_lost_view  ON CLUSTER {{cluster_name}} TO {{database_name}}.olap_user_lost_local (
    `uid`           Nullable(UInt64) COMMENT '用户ID',
    `smid`          Nullable(String) COMMENT '流失前使用的设备smid',
    `client`        Nullable(String) COMMENT 'ios/android',
    `apm`           Nullable(String) COMMENT 'cv前缀，区分不同app包',
    `lost_type`     Nullable(String) COMMENT '流失类型',
    `dt`            Nullable(String) COMMENT '日期',
    `smid_is_black` Int32 COMMENT 'smid是否黑名单，level=3',
    `uid_is_black`  Int32 COMMENT 'uid是否黑名单，level=3',
    `ymd`           Nullable(String) COMMENT '分区字段：流失日期yyyyMMdd'
) AS
SELECT visitParamExtractUInt(str, 'uid')          AS uid,
       visitParamExtractString(str, 'smid')       AS smid,
       visitParamExtractInt(str, 'client')        AS client,
       visitParamExtractString(str, 'apm')        AS apm,
       visitParamExtractString(str, 'lost_type')  AS lost_type,
       visitParamExtractString(str, 'dt')         AS dt,
       visitParamExtractInt(str, 'smid_is_black') AS smid_is_black,
       visitParamExtractInt(str, 'uid_is_black')  AS uid_is_black,
       visitParamExtractString(str, 'ymd')        AS ymd
FROM {{database_name}}.kafka_{{database_name}}_transform_local
WHERE appname = '{{database_name}}cm_olap_user_lost';;

-- 支付表

CREATE TABLE {{database_name}}.olap_realtime_pay_local on cluster {{cluster_name}}
(
    `bill_id`    Nullable(String),
    `appname`    Nullable(String),
    `event_time` Nullable(String),
    `dt`         String,
    `hour`       Nullable(String),
    `uid`        Nullable(UInt64),
    `money`      Float64,
    `money_type` Nullable(UInt64),
    `manner`     Nullable(String),
    `sub_manner` Nullable(String),
    `eid`        Nullable(String),
    `ymd`        Nullable(String)
)
ENGINE = MergeTree
    PARTITION BY dt
    ORDER BY (dt)
    SETTINGS
        index_granularity = 8192;;

CREATE MATERIALIZED VIEW {{database_name}}.d_cc_info_view on cluster {{cluster_name}} TO {{database_name}}.d_cc_info_local
(
    `id` String COMMENT '主键ID',
    `cc` String COMMENT 'CC编号',
    `chl_name` String COMMENT '渠道包名',
    `client` String COMMENT '客户端ios/android/other',
    `app_id` UInt64 COMMENT '1映客,2不就,9音泡,15对缘等',
    `agent_id` UInt32 COMMENT '关联代理商id',
    `agent_name` String COMMENT '代理商名称',
    `cc_level1_name` String COMMENT '渠道一级id',
    `cc_level2_name` String COMMENT '渠道二级id',
    `cc_level3_name` String COMMENT '渠道三级id',
    `channel` String COMMENT 'cc对应的渠道号',
    `chl_level1_name` String COMMENT '渠道一级id',
    `chl_level2_name` String COMMENT '渠道二级id',
    `chl_level3_name` String COMMENT '渠道三级id',
    `apm` String COMMENT '用来区分马甲包',
    `app_key` String COMMENT 'app_key管控唯一标识'
) AS
SELECT
    visitParamExtractString(str, 'id') AS id,
    visitParamExtractString(str, 'cc') AS cc,
    visitParamExtractString(str, 'chl_name') AS chl_name,
    visitParamExtractString(str, 'client') AS client,
    visitParamExtractUInt(str, 'app_id') AS app_id,
    visitParamExtractInt(str, 'agent_id') AS agent_id,
    visitParamExtractString(str, 'agent_name') AS agent_name,
    visitParamExtractString(str, 'cc_level1_name') AS cc_level1_name,
    visitParamExtractString(str, 'cc_level2_name') AS cc_level2_name,
    visitParamExtractString(str, 'cc_level3_name') AS cc_level3_name,
    visitParamExtractString(str, 'channel') AS channel,
    visitParamExtractString(str, 'chl_level1_name') AS chl_level1_name,
    visitParamExtractString(str, 'chl_level2_name') AS chl_level2_name,
    visitParamExtractString(str, 'chl_level3_name') AS chl_level3_name,
    visitParamExtractString(str, 'apm') AS apm,
    visitParamExtractString(str, 'app_key') AS app_key
FROM {{database_name}}.kafka_{{database_name}}_transform_local
WHERE appname = '{{database_name}}cm_d_cc_info'
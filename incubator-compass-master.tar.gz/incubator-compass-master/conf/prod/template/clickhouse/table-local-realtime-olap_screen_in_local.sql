-- screen_in表

CREATE TABLE IF NOT EXISTS {{database_name}}.olap_realtime_screen_in_local on cluster {{cluster_name}}
(
    `uid` Nullable(UInt64),
    `md_mod` Nullable(String),
    `record_time` Nullable(String),
    `cv` Nullable(String),
    `cc` Nullable(String),
    `ua` Nullable(String),
    `smid` Nullable(String),
    `imei` Nullable(String),
    `oaid` Nullable(String),
    `idfa` Nullable(String),
    `ndid` Nullable(String),
    `conn` Nullable(String),
    `osversion` Nullable(String),
    `ip` Nullable(String),
    `logid` Nullable(String),
    `ropklv` Nullable(String),
    `client` Nullable(String),
    `apm` Nullable(String),
    `eid` Nullable(String),
    `screen_name` Nullable(String),
    `screen_cn_name` Nullable(String),
    `last_eid` Nullable(String),
    `last_screen_name` Nullable(String),
    `last_screen_cn_name` Nullable(String),
    `appname` Nullable(String),
    `ymd` String
)
ENGINE = MergeTree
    PARTITION BY ymd
    ORDER BY (ymd)
    SETTINGS
        index_granularity = 8192;;

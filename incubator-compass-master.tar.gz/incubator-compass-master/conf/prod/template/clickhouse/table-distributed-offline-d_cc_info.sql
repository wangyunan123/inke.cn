CREATE TABLE {{database_name}}.d_cc_info on cluster {{cluster_name}}
(
    `id` String COMMENT '主键ID',
    `cc` String COMMENT 'CC编号',
    `chl_name` String COMMENT '渠道包名',
    `client` String COMMENT '客户端ios/android/other',
    `app_id` UInt64 COMMENT '1映客,2不就,9音泡,15对缘等',
    `agent_id` UInt32 COMMENT '关联代理商id',
    `agent_name` String COMMENT '代理商名称',
    `cc_level1_name` String COMMENT '渠道一级id',
    `cc_level2_name` String COMMENT '渠道二级id',
    `cc_level3_name` String COMMENT '渠道三级id',
    `channel` String COMMENT 'cc对应的渠道号',
    `chl_level1_name` String COMMENT '渠道一级id',
    `chl_level2_name` String COMMENT '渠道二级id',
    `chl_level3_name` String COMMENT '渠道三级id',
    `apm` String COMMENT 'cv 用来区分马甲包',
    `app_key` String COMMENT 'app_key管控唯一标识'
)
    ENGINE = Distributed({{cluster_name}}, {{database_name}}, 'd_cc_info_local', rand())
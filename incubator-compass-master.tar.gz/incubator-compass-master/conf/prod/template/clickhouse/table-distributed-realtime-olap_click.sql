CREATE TABLE IF NOT EXISTS {{database_name}}.olap_realtime_click on cluster  {{cluster_name}} AS {{database_name}}.olap_realtime_click_local
ENGINE = Distributed({{cluster_name}}, {{database_name}},olap_realtime_click_local , rand());

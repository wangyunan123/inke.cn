CREATE TABLE {{database_name}}.olap_kafka_{{database_name}}_day_cc_cost_transform_local on cluster {{cluster_name}}
(
    `id` String COMMENT '主键ID',
    `dt` String,
    `cc_level1_name` String COMMENT '一级渠道',
    `cc_level2_name` String COMMENT '二级渠道',
    `cc_level3_name` String COMMENT '三级渠道',
    `app_id` UInt32,
    `agent_id` UInt32,
    `cc` String,
    `money` Float64 COMMENT '消耗金额',
    `money_priority` UInt32 COMMENT '消耗金额优先级 ： 1--manual 人工上传 2--大数据 3--脚本执行汇总',
    `discount` Float64 COMMENT '折后消耗',
    `gross_margin` Float64 COMMENT '毛利率',
    `ymd` String COMMENT '天',
    `yw` String COMMENT '周',
    `ym` String COMMENT '月'
)
    ENGINE = Kafka
    SETTINGS kafka_broker_list = '{{kafka_cluster}}', kafka_topic_list = '{{kafka_cluster_topic}}', kafka_group_name = '{{database_name}}-olap_consume_offline_{{cluster_name}}', kafka_format = 'JSONEachRow', kafka_num_consumers = 6, kafka_max_block_size = 20000, kafka_skip_broken_messages = 1048577

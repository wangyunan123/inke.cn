

CREATE MATERIALIZED VIEW {{database_name}}.day_cc_cost_view  on cluster {{cluster_name}} TO {{database_name}}.day_cc_cost_local
(
    `id` String COMMENT '主键ID',
    `dt` String,
    `cc_level1_name` String COMMENT '一级渠道',
    `cc_level2_name` String COMMENT '二级渠道',
    `cc_level3_name` String COMMENT '三级渠道',
    `app_id` UInt32,
    `agent_id` UInt32,
    `cc` String,
    `money` Decimal(19, 2) COMMENT '消耗金额',
    `money_priority` UInt32 COMMENT '消耗金额优先级 ： 1--manual 人工上传 2--大数据 3--脚本执行汇总',
    `discount` Float64 COMMENT '折后消耗',
    `gross_margin` Float64 COMMENT '毛利率',
    `channel` String COMMENT '渠道号',
    `chl_level1_name` String COMMENT 'channel对应一级渠道',
    `chl_level2_name` String COMMENT 'channel对应二级渠道',
    `chl_level3_name` String COMMENT 'channel对应三级渠道',
    `apm` String COMMENT '用来区分马甲包',
    `app_key` String COMMENT 'app_key 管控唯一标识',
    `ymd` String COMMENT '天',
    `yw` String COMMENT '周',
    `ym` String COMMENT '月'
) AS
SELECT
    a.id,
    a.dt,
    a.cc_level1_name,
    a.cc_level2_name,
    a.cc_level3_name,
    a.app_id,
    a.agent_id,
    a.cc,
    a.money,
    a.money_priority,
    a.discount,
    a.gross_margin,
    b.channel,
    b.chl_level1_name,
    b.chl_level2_name,
    b.chl_level3_name,
    b.apm,
    b.app_key,
    a.ymd,
    a.yw,
    a.ym
FROM {{database_name}}.olap_kafka_{{database_name}}_day_cc_cost_transform_local AS a
INNER JOIN {{database_name}}.d_cc_info AS b ON a.cc = b.cc
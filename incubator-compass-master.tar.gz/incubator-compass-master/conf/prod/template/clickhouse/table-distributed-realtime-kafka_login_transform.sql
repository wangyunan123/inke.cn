CREATE TABLE IF NOT EXISTS {{database_name}}.olap_kafka_{{database_name}}_login_transform on cluster  {{cluster_name}} AS {{database_name}}.olap_kafka_{{database_name}}_login_transform_local
ENGINE = Distributed({{cluster_name}}, {{database_name}},olap_kafka_{{database_name}}_login_transform_local , rand());

-- Kafka原始数据表

CREATE TABLE IF NOT EXISTS {{database_name}}.kafka_{{database_name}}_transform_local on cluster {{cluster_name}}
(
    `str`     Nullable(String) COMMENT '详细信息JSON数据',
    `appname` Nullable(String) COMMENT '应用名称'
) ENGINE = Kafka
    SETTINGS
    kafka_broker_list = '{{kafka_cluster}}',
    kafka_topic_list = '{{database_name}}_olap_offline',
    kafka_group_name = '{{database_name}}-olap_offline_{{cluster_name}}',
    kafka_format = 'JSONEachRow',
    kafka_num_consumers = 6,
    kafka_max_block_size = 1048576,
    kafka_skip_broken_messages = 1048577;;




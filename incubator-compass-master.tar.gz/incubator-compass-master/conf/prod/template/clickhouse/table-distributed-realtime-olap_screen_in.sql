CREATE TABLE IF NOT EXISTS {{database_name}}.olap_realtime_screen_in on cluster  {{cluster_name}} AS {{database_name}}.olap_realtime_screen_in_local
ENGINE = Distributed({{cluster_name}}, {{database_name}},olap_realtime_screen_in_local , rand());

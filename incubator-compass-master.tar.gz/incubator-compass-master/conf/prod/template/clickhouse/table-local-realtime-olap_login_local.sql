-- 登录表

CREATE TABLE IF NOT EXISTS {{database_name}}.olap_realtime_login_local on cluster {{cluster_name}}
(
    `appname`     Nullable(String),
    `uid`         Nullable(UInt64),
    `smid`        Nullable(String),
    `apm`         Nullable(String),
    `cc`          Nullable(String),
    `cv`          Nullable(String),
    `platform`    Nullable(String),
    `new_add`     Nullable(String),
    `from_web`    Nullable(UInt64),
    `phone_channel`  Nullable(String),
    `event_time`  Nullable(String),
    `dt`          String,
    `ymd`        Nullable(String)
)
ENGINE = MergeTree
    PARTITION BY dt
    ORDER BY (dt)
    SETTINGS
        index_granularity = 8192;;

CREATE TABLE IF NOT EXISTS {{database_name}}.olap_realtime_screen_in on cluster default_cluster AS {{database_name}}.olap_realtime_screen_in_local
    ENGINE = Distributed
(
    default_cluster, {
    {
    database_name}},
    olap_realtime_screen_in_local,
    rand
(
));

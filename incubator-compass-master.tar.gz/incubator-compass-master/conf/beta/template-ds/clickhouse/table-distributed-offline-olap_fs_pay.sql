CREATE TABLE IF NOT EXISTS {{database_name}}.olap_fs_pay on cluster default_cluster AS {{database_name}}.olap_fs_pay_local
    ENGINE = Distributed
(
    default_cluster, {
    {
    database_name}},
    olap_fs_pay_local,
    rand
(
));

-- CREATE TABLE IF NOT EXISTS {{database_name}}.olap_fs_pay on cluster  default_cluster AS {{database_name}}.olap_fs_pay_local
--     ENGINE = Distributed(default_cluster, {{database_name}}, olap_fs_pay_local , cityHash64(bill_id));


CREATE TABLE IF NOT EXISTS {{database_name}}.olap_active_app on cluster default_cluster AS {{database_name}}.olap_active_app_local
    ENGINE = Distributed
(
    default_cluster, {
    {
    database_name}},
    olap_active_app_local,
    rand
(
));

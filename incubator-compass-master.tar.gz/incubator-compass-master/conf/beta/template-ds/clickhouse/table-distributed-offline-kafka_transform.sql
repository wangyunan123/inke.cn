--分布式表
CREATE TABLE IF NOT EXISTS {{database_name}}.kafka_{{database_name}} _ transform on cluster default_cluster AS {{database_name}}.kafka_{{database_name}} _transform_local
    ENGINE = Distributed
(
    default_cluster, {
    {
    database_name}},
    kafka_{
    {
    database_name}}
    _
    transform_local,
    rand
(
));
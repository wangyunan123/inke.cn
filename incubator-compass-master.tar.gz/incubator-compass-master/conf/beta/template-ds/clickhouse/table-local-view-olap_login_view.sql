-- 登录物化表

CREATE
MATERIALIZED VIEW IF NOT EXISTS {{database_name}}.olap_realtime_login_view  ON CLUSTER default_cluster TO {{database_name}}.olap_realtime_login_local (
    `appname`     Nullable(String),
    `uid`         Nullable(UInt64),
    `smid`        Nullable(String),
    `apm`         Nullable(String),
    `cc`          Nullable(String),
    `cv`          Nullable(String),
    `platform`    Nullable(String),
    `new_add`     Nullable(String),
    `from_web`    Nullable(UInt32),
    `phone_channel`  Nullable(String),
    `event_time`  Nullable(String),
    `dt`          Nullable(String),
    `ymd`        Nullable(String)
) AS
SELECT `appname`,
       `uid`,
       `smid`,
       `apm`,
       `cc`,
       `cv`,
       `platform`,
       `new_add`,
       `from_web`,
       `phone_channel`,
       `event_time`,
       `dt`,
       `ymd`
FROM {{database_name}}.olap_kafka_{{database_name}}_login_transform_local;

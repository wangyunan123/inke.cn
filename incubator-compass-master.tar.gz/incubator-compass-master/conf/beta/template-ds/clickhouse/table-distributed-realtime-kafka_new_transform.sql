CREATE TABLE IF NOT EXISTS {{database_name}}.olap_kafka_{{database_name}} _new_transform on cluster default_cluster AS {{database_name}}.olap_kafka_{{database_name}} _new_transform_local
    ENGINE = Distributed
(
    default_cluster, {
    {
    database_name}},
    olap_kafka_{
    {
    database_name}}
    _
    new_transform_local,
    rand
(
));

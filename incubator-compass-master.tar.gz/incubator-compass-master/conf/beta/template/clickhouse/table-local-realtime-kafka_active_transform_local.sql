-- Kafka原始数据表

CREATE TABLE IF NOT EXISTS {{database_name}}.olap_kafka_{{database_name}} _active_transform_local on cluster {{cluster_name}}
(
    `md_eid` Nullable
(
    String
),
    `uid` Nullable
(
    UInt64
),
    `md_mod` Nullable
(
    String
),
    `md_session` Nullable
(
    String
),
    `md_etime` Nullable
(
    String
),
    `record_time` Nullable
(
    String
),
    `md_path` Nullable
(
    String
),
    `md_einfo` Nullable
(
    String
),
    `lc` Nullable
(
    String
),
    `cv` Nullable
(
    String
),
    `cc` Nullable
(
    String
),
    `ua` Nullable
(
    String
),
    `devi` Nullable
(
    String
),
    `imsi` Nullable
(
    String
),
    `imei` Nullable
(
    String
),
    `smid` Nullable
(
    String
),
    `deviceid` Nullable
(
    String
),
    `aid` Nullable
(
    String
),
    `conn` Nullable
(
    String
),
    `osversion` Nullable
(
    String
),
    `proto` Nullable
(
    String
),
    `idfa` Nullable
(
    String
),
    `idfv` Nullable
(
    String
),
    `client_ip` Nullable
(
    String
),
    `md_logid` Nullable
(
    String
),
    `jb` Nullable
(
    String
),
    `seq` Nullable
(
    String
),
    `md_etype` Nullable
(
    String
),
    `latitude` Nullable
(
    String
),
    `longitude` Nullable
(
    String
),
    `ymd` Nullable
(
    String
),
    `year` Nullable
(
    String
),
    `ym` Nullable
(
    String
),
    `hour` Nullable
(
    String
)
    ) ENGINE = Kafka
    SETTINGS
    kafka_broker_list = '{{kafka_cluster}}',
    kafka_topic_list = 'olap_{{database_name}}_applog_active',
    kafka_group_name = 'olap_{{database_name}}_applog_active_{{cluster_name}}',
    kafka_format = 'JSONEachRow',
    kafka_num_consumers = 6,
    kafka_max_block_size = 1048576,
    kafka_skip_broken_messages = 1048577;;

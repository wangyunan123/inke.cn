CREATE TABLE IF NOT EXISTS {{database_name}}.day_cc_cost on cluster {{cluster_name}} AS {{database_name}}.day_cc_cost_local
    ENGINE = Distributed
(
    {
    {
    cluster_name}}, {
    {
    database_name}},
    day_cc_cost_local,
    rand
(
));

-- Kafka原始支付数据表

CREATE TABLE IF NOT EXISTS {{database_name}}.olap_kafka_{{database_name}} _pay_transform_local on cluster {{cluster_name}}
(
    `bill_id` Nullable
(
    String
),
    `appname` Nullable
(
    String
),
    `event_time` Nullable
(
    String
),
    `dt` Nullable
(
    String
),
    `hour` Nullable
(
    String
),
    `uid` Nullable
(
    UInt64
),
    `money` Float64,
    `money_type` Nullable
(
    UInt64
),
    `manner` Nullable
(
    String
),
    `sub_manner` Nullable
(
    String
),
    `eid` Nullable
(
    String
),
    `ymd` Nullable
(
    String
)
    ) ENGINE = Kafka
    SETTINGS
    kafka_broker_list = '{{kafka_cluster}}',
    kafka_topic_list = 'olap_{{database_name}}_serverlog_pay',
    kafka_group_name = 'olap_{{database_name}}_serverlog_pay_{{cluster_name}}',
    kafka_format = 'JSONEachRow',
    kafka_num_consumers = 6,
    kafka_max_block_size = 1048576,
    kafka_skip_broken_messages = 1048577;;

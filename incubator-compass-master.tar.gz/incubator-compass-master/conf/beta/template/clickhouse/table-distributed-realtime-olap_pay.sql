CREATE TABLE IF NOT EXISTS {{database_name}}.olap_realtime_pay on cluster {{cluster_name}} AS {{database_name}}.olap_realtime_pay_local
    ENGINE = Distributed
(
    {
    {
    cluster_name}}, {
    {
    database_name}},
    olap_realtime_pay_local,
    rand
(
));

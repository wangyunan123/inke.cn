-- 支付物化表

CREATE
MATERIALIZED VIEW IF NOT EXISTS {{database_name}}.olap_realtime_pay_view  ON CLUSTER {{cluster_name}} TO {{database_name}}.olap_realtime_pay_local (
    `bill_id`    Nullable(String),
    `appname`    Nullable(String),
    `event_time` Nullable(String),
    `dt`         Nullable(String),
    `hour`       Nullable(String),
    `uid`        Nullable(UInt64),
    `money`      Float64,
    `money_type` Nullable(UInt64),
    `manner`     Nullable(String),
    `sub_manner` Nullable(String),
    `eid`        Nullable(String),
    `ymd`        Nullable(String)
) AS
SELECT `bill_id`,
       `appname`,
       `event_time`,
       `dt`,
       `hour`,
       `uid`,
       `money`,
       `money_type`,
       `manner`,
       `sub_manner`,
       `eid`,
       `ymd`
FROM {{database_name}}.olap_kafka_{{database_name}}_pay_transform_local;;

CREATE TABLE IF NOT EXISTS {{database_name}}.olap_active_app on cluster {{cluster_name}} AS {{database_name}}.olap_active_app_local
    ENGINE = Distributed
(
    {
    {
    cluster_name}}, {
    {
    database_name}},
    olap_active_app_local,
    rand
(
));

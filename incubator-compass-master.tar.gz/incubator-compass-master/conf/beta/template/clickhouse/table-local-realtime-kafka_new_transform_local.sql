-- Kafka原始数据表

CREATE TABLE IF NOT EXISTS {{database_name}}.olap_kafka_{{database_name}} _new_transform_local on cluster {{cluster_name}}
(
    uid Nullable
(
    UInt64
) COMMENT '用户ID',
    client Nullable
(
    String
) COMMENT '端',
    active_time Nullable
(
    String
) COMMENT '设备激活时间',
    smid Nullable
(
    String
) COMMENT '数盟ID',
    imei Nullable
(
    String
) COMMENT '手机串号imei',
    oaid Nullable
(
    String
) COMMENT 'oaid',
    idfa Nullable
(
    String
) COMMENT 'ios设备idfa',
    cc Nullable
(
    String
) COMMENT '渠道',
    cv Nullable
(
    String
) COMMENT '客户端版本',
    apm Nullable
(
    String
) COMMENT 'cv前缀',
    ip Nullable
(
    String
) COMMENT 'ip',
    conn Nullable
(
    String
) COMMENT '网络连接方式',
    dt Nullable
(
    String
) COMMENT '活跃日期',
    yw Nullable
(
    String
) COMMENT '自然周',
    ym Nullable
(
    String
) COMMENT '自然月',
    ymd Nullable
(
    String
) comment '分区字段：新增日期'
    ) ENGINE = Kafka
    SETTINGS
    kafka_broker_list = '{{kafka_cluster}}',
    kafka_topic_list = 'olap_{{database_name}}_applog_new',
    kafka_group_name = 'olap_{{database_name}}_applog_new_{{cluster_name}}',
    kafka_format = 'JSONEachRow',
    kafka_num_consumers = 6,
    kafka_max_block_size = 1048576,
    kafka_skip_broken_messages = 1048577;;

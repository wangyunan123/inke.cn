-- Kafka原始数据表

CREATE TABLE IF NOT EXISTS {{database_name}}.olap_kafka_{{database_name}} _click_transform_local on cluster {{cluster_name}}
(
    `uid` Nullable
(
    UInt64
),
    `md_mod` Nullable
(
    String
),
    `record_time` Nullable
(
    String
),
    `cv` Nullable
(
    String
),
    `cc` Nullable
(
    String
),
    `ua` Nullable
(
    String
),
    `smid` Nullable
(
    String
),
    `imei` Nullable
(
    String
),
    `oaid` Nullable
(
    String
),
    `idfa` Nullable
(
    String
),
    `ndid` Nullable
(
    String
),
    `conn` Nullable
(
    String
),
    `osversion` Nullable
(
    String
),
    `ip` Nullable
(
    String
),
    `logid` Nullable
(
    String
),
    `ropklv` Nullable
(
    String
),
    `client` Nullable
(
    String
),
    `apm` Nullable
(
    String
),
    `xpath` Nullable
(
    String
),
    `appname` Nullable
(
    String
),
    `ymd` Nullable
(
    String
),
    `eid` Nullable
(
    String
),
    `ename` Nullable
(
    String
)
    ) ENGINE = Kafka
    SETTINGS
    kafka_broker_list = '{{kafka_cluster}}',
    kafka_topic_list = 'olap_{{database_name}}_applog_click',
    kafka_group_name = 'olap_{{database_name}}_applog_click_{{cluster_name}}',
    kafka_format = 'JSONEachRow',
    kafka_num_consumers = 6,
    kafka_max_block_size = 1048576,
    kafka_skip_broken_messages = 1048577;;

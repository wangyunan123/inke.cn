--分布式表
CREATE TABLE IF NOT EXISTS {{database_name}}.kafka_{{database_name}} _ transform on cluster {{cluster_name}} AS {{database_name}}.kafka_{{database_name}} _transform_local
    ENGINE = Distributed
(
    {
    {
    cluster_name}}, {
    {
    database_name}},
    kafka_{
    {
    database_name}}
    _
    transform_local,
    rand
(
));
CREATE TABLE IF NOT EXISTS {{database_name}}.olap_user_lost on cluster {{cluster_name}} AS {{database_name}}.olap_user_lost_local
    ENGINE = Distributed
(
    {
    {
    cluster_name}}, {
    {
    database_name}},
    olap_user_lost_local,
    rand
(
));

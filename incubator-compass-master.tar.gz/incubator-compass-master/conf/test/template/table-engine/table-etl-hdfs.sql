INSERT INTO {{app_name}}.{{database_name}} _{{table_name}} _ local
({{columns}},
   ymd)
SELECT
    {{columns}},
    '{{partition}}' AS ymd
FROM {{app_name}}.{{database_name}} _{{table_name}} _{{partition}}

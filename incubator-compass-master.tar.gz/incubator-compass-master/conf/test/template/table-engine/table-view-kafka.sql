CREATE
MATERIALIZED VIEW IF NOT EXISTS {{database_name}}.olap_kafka_{{kafka_cluster_topic}}_view_local TO {{database_name}}.olap_kafka_{{kafka_cluster_topic}}_local
(
    {{columns}}
) AS
SELECT
    {{selectSql}}
FROM
    {{database_name}}.olap_kafka_{{kafka_cluster_topic}} _transform_local
CREATE TABLE IF NOT EXISTS {{database_name}}.olap_kafka_{{kafka_cluster_topic}} _ local
(
    {
{
    columns}}
)
    ENGINE = MergeTree
    PARTITION BY
(
    ymd
)
    ORDER BY
(
    ymd
)
    SETTINGS
    index_granularity = 8192;;
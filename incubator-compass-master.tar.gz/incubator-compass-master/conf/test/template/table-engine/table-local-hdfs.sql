CREATE TABLE IF NOT EXISTS {{app_name}}.{{database_name}} _{{table_name}} _ local
(
    {
{
    columns}}
)
    ENGINE = MergeTree
    PARTITION BY
(
    ymd
)
    ORDER BY
(
    ymd
)
    SETTINGS
    index_granularity = 8192;;
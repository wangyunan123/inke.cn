CREATE TABLE {{database_name}}.olap_kafka_{{database_name}}_day_cc_cost_transform_local on cluster {{cluster_name}}
(
     `id` String COMMENT '主键ID',
     `dt` String,
     `cc_level1_name` String COMMENT '一级渠道',
     `cc_level2_name` String COMMENT '二级渠道',
     `cc_level3_name` String COMMENT '三级渠道',
     `app_id` UInt64 COMMENT 'app_id',
     `cc_agent_name` String COMMENT '代理名称',
     `cc` String,
     `money` Decimal(19, 2) COMMENT '消耗金额',
     `money_priority` UInt32 COMMENT '消耗金额优先级 ： 1--manual 人工上传 2--大数据 3--脚本执行汇总',
     `discount` Float64 COMMENT '折后消耗',
     `gross_margin` Float64 COMMENT '毛利率',
     `channel` String COMMENT '渠道号',
     `chl_level1_name` String COMMENT 'channel对应一级渠道',
     `chl_level2_name` String COMMENT 'channel对应二级渠道',
     `chl_level3_name` String COMMENT 'channel对应三级渠道',
     `apm` String COMMENT 'cv 用来区分马甲包',
     `app_key` String COMMENT 'app_key 管控唯一标识',
     `ymd` String COMMENT '天',
     `yw` String COMMENT '周',
     `ym` String COMMENT '月',
     `exposure_num` Int64,
     `click_num` Int64 COMMENT '点击数',
     `download_num` Int64 COMMENT '下载数',
     `install_num` Int64 COMMENT '安装数',
     `op_type` String COMMENT '投放方式中文描述',
     `chl_op_type` String COMMENT 'channel投放方式中文描述',
     `chl_agent_name` String COMMENT '投放方式中文描述'
)
    ENGINE = Kafka
    SETTINGS kafka_broker_list = '{{kafka_cluster}}', kafka_topic_list = '{{kafka_cluster_topic}}', kafka_group_name = '{{database_name}}-olap_consume_offline_{{cluster_name}}', kafka_format = 'JSONEachRow', kafka_num_consumers = 6, kafka_max_block_size = 20000, kafka_skip_broken_messages = 1048577

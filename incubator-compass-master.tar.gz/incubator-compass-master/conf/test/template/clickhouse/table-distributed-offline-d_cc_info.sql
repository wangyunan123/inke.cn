CREATE TABLE {{database_name}}.d_cc_info on cluster {{cluster_name}} AS {{database_name}}.d_cc_info_local
ENGINE = Distributed({{cluster_name}}, {{database_name}}, 'd_cc_info_local', rand())

#!/bin/bash

cluster_name=$(echo "$1" | sed -r 's/^cop\.([^_\.]+)?_owt\.([^_\.]+)?_pdl\.([^_\.]+)?_cluster\.([^_\.]+)?.*/\4/')
service_name=$(echo "$1" | sed -r 's/^cop\.([^_\.]+)?_owt\.([^_\.]+)?_pdl\.([^_\.]+)?(.*)?_service\.([^_\.]+)?.*/\5/')
project_path=$(pwd)
release_path=release

env="dev"

function print_environment() {
    printf "================== 基础环境信息 ==================\n"
    printf "项目路径: %s\n" $project_path
    printf "服务名称: %s\n" $service_name
    printf "发行版地址: %s\n" $release_path
}

function build() {
    cd $project_path
    rm -rf $release_path
    mkdir -p $release_path
    mvn clean install package -DskipTests -U
    if [ $? != 0 ]; then
        printf "编译失败，退出编译！\n"
        exit 100
    fi
    tar -xvzf server/target/compass-server-release.tar.gz -C release/
    if [ $? != 0 ]; then
        printf "编译失败，退出编译！\n"
        exit 102
    else
        printf "编译成功！\n"
    fi

}

print_environment
build

exit 0

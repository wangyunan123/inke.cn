# Compass

Compass是一套自动化的OLAP数据分析系统。

### 如何使用代码规范

- 导入项目代码格式化文件

`Preferences...` --> `Editor` --> `Code Style` --> 选择右侧的`Scheme` --> `Import Scheme`

选择项目中的`style.xml`文件即可，做项目的编译时会做代码检查，不合规范会被停止编译操作

- 代码格式校验

```bash
./mvnw clean install checkstyle:check -DskipTests
```

- 代码静态bug校验

```bash
./mvnw clean install findbugs:check -DskipTests
```

- 代码bug校验

登录到代码检查系统上点击右侧头像下的我的账号，在安全中选择生成令牌，注意令牌ID只构建一次请记住它！

```bash
./mvnw clean install sonar:sonar \
  -Dsonar.scm.disabled=true \
  -Dsonar.projectKey=incubator-compass \
  -Dsonar.host.url=http://review.platform.dataworks.inkept.cn \
  -Dsonar.login=用户生成的Token
```

> 以上支持内容可以使用./bin/code.sh脚本

### 代码Commit提交规范
---

- 复制规范检查到git

```bash
cp git-pre/commit-msg .git/hooks
```

- 分配权限

```bash
chmod +x .git/hooks/commit-msg
```
package com.inke.compass.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;

public class FileUtils
{
    private static final Logger LOGGER = LoggerFactory.getLogger(FileUtils.class);

    public static Boolean downloadByNetwork(String uri, String target)
    {
        LOGGER.info("Download file form {}, local storage {}", uri, target);
        Boolean flag = Boolean.TRUE;
        int byteRead;
        try {
            URL url = new URL(uri);
            URLConnection conn = url.openConnection();
            InputStream inStream = conn.getInputStream();
            FileOutputStream fs = new FileOutputStream(target);
            byte[] buffer = new byte[1204];
            while ((byteRead = inStream.read(buffer)) != -1) {
                fs.write(buffer, 0, byteRead);
            }
        }
        catch (FileNotFoundException e) {
            LOGGER.info("Download file {} error {}", uri, e);
            e.printStackTrace();
            flag = Boolean.FALSE;
        }
        catch (IOException e) {
            LOGGER.info("Download file {} error {}", uri, e);
            e.printStackTrace();
            flag = Boolean.TRUE;
        }
        return flag;
    }
}

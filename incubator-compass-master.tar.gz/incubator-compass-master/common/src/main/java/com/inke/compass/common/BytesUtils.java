package com.inke.compass.common;

import java.text.DecimalFormat;

public class BytesUtils
{
    private BytesUtils()
    {
    }

    public static String getByteSize(int size)
    {
        int GB = 1024 * 1024 * 1024;
        int MB = 1024 * 1024;
        int KB = 1024;
        DecimalFormat df = new DecimalFormat("0.00");
        String resultSize = "";
        if (size / GB >= 1) {
            resultSize = df.format(size / (float) GB) + "GB";
        }
        else if (size / MB >= 1) {
            resultSize = df.format(size / (float) MB) + "MB";
        }
        else if (size / KB >= 1) {
            resultSize = df.format(size / (float) KB) + "KB";
        }
        else {
            resultSize = size + "B";
        }
        return resultSize;
    }
}

package com.inke.compass.model;

import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.List;

@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class ClickHouseResponse
{
    private String server;
    private String queryId;
    private String format;
    private String timeout;
    private Object response;
    private ClickHouseSummary summary;
    private List<ClickHouseConsume> consumes;

    @Data
    @ToString
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ClickHouseSummary
    {
        @SerializedName(value = "read_rows")
        private String readRows;
        @SerializedName(value = "read_bytes")
        private String readBytes;
        @SerializedName(value = "written_rows")
        private String writtenRows;
        @SerializedName(value = "written_bytes")
        private String writtenBytes;
        @SerializedName(value = "total_rows_to_read")
        private String totalRowsToRead;
    }

    @Data
    @ToString
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ClickHouseConsume
    {
        private String memoryUsage;
        private String peakMemoryUsage;
        private String elapsed;
    }
}

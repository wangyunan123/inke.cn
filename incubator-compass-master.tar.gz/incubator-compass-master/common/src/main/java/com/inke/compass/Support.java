package com.inke.compass;

import cn.hutool.crypto.digest.DigestUtil;

/**
 * <p> @Description :  </p>
 * <p> @incubator-compass </p>
 * <p> @Author : <a href="mailTo:mfr1339941169@qq.com">Mfrain</a>  </p>
 * <p> @Create Time : 2021/7/12 2:45 下午 </p>
 * <p> @Version : 1.0 </p>
 */
public class Support
{
    public static String ENV = "prod";
    public static String HOLOGRES = "hologres";
    public static String CLICKHOUSE = "clickhouse";
    // 用于标记区分sql自定义函数的开始
    public static String SQL_FN = "fn:";
    public static String EMPTY = "";
    public static String AT = "@";

    public static String getColumnAliasName(String fn)
    {
        if (!fn.startsWith(Support.SQL_FN)) {
            return fn;
        }
        return DigestUtil.md5Hex(fn.replace(" ", "")
                        .replace(":", "_")
                        .replace(",", "_")
                        .replace("(", "_")
                        .replace(")", ""))
                .replace("-", "_");
    }
}

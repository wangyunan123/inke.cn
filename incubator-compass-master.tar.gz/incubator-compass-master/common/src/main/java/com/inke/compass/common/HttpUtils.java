package com.inke.compass.common;

import com.google.common.base.Preconditions;
import com.google.gson.Gson;
import com.inke.compass.model.ClickHouseResponse;
import io.edurt.gcm.common.utils.StringUtils;
import okhttp3.Call;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class HttpUtils
{
    private HttpUtils() {}

    public static OkHttpClient okHttpClient = new OkHttpClient()
            .newBuilder()
            .retryOnConnectionFailure(true)
            .connectTimeout(800, TimeUnit.SECONDS)
            .readTimeout(600, TimeUnit.SECONDS)
            .writeTimeout(600, TimeUnit.SECONDS)
            .build();

    public static String runExecuteToString(String server, String sql)
    {
        Preconditions.checkArgument(StringUtils.isNotEmpty(server), "远程服务器地址不能为空");
        Preconditions.checkArgument(StringUtils.isNotEmpty(sql), "执行的SQL不能为空");
        Request.Builder reqBuild = new Request.Builder();
        okhttp3.RequestBody body = okhttp3.RequestBody
                .create(MediaType.parse("text/plain; charset=utf-8"), sql);
        Request request = reqBuild
                .url(String.format("http://%s:8123", server))
                .post(body)
                .build();
        Call call = okHttpClient.newCall(request);
        try {
            Response response = call.execute();
            String result = response.body().string();
            return StringUtils.isEmpty(result) ? "" : result;
        }
        catch (Exception exception) {
            return "";
        }
    }

    public static String runExecute(String uri)
    {
        Preconditions.checkArgument(StringUtils.isNotEmpty(uri), "远程服务器地址不能为空");
        Request.Builder reqBuild = new Request.Builder();
        Request request = reqBuild.url(uri).get().build();
        Call call = okHttpClient.newCall(request);
        try {
            Response response = call.execute();
            String result = response.body().string();
            return StringUtils.isEmpty(result) ? null : result;
        }
        catch (Exception exception) {
            return null;
        }
    }

    public static ClickHouseResponse runExecuteToStringFull(String server, String sql)
    {
        Request.Builder reqBuild = new Request.Builder();
        okhttp3.RequestBody body = okhttp3.RequestBody
                .create(MediaType.parse("text/plain; charset=utf-8"), sql);
        Request request = reqBuild
                .url(String.format("http://%s:8123", server))
                .post(body)
                .build();
        Call call = okHttpClient.newCall(request);
        try {
            Response response = call.execute();
            String result = response.body().string();
            ClickHouseResponse clickHouseResponse = new ClickHouseResponse();
            clickHouseResponse.setResponse(result);
            clickHouseResponse.setFormat(response.header("X-ClickHouse-Format"));
            clickHouseResponse.setServer(response.header("X-ClickHouse-Server-Display-Name"));
            clickHouseResponse.setQueryId(response.header("X-ClickHouse-Query-Id"));
            clickHouseResponse.setTimeout(response.header("Keep-Alive"));
            clickHouseResponse.setSummary(new Gson().fromJson(response.header("X-ClickHouse-Summary"), ClickHouseResponse.ClickHouseSummary.class));
            // 添加查询状态结果
            List<ClickHouseResponse.ClickHouseConsume> consumes = new ArrayList<>();
            getConsume(server, clickHouseResponse.getQueryId(), consumes);
            clickHouseResponse.setConsumes(consumes);
            System.out.println(response.headers());
            return StringUtils.isEmpty(result) ? null : clickHouseResponse;
        }
        catch (Exception exception) {
            return null;
        }
    }

    private static void getConsume(String server, String queryId, List<ClickHouseResponse.ClickHouseConsume> consumes)
    {
        String sql = String.format("SELECT\n" +
                "  query_duration_ms AS elapsed,\n" +
                "  memory_usage AS memoryUsage\n" +
                "FROM\n" +
                "  system.query_log\n" +
                "WHERE\n" +
                "  query_id = '%s'" +
                "AND query_duration_ms > 0", queryId);
        String response = HttpUtils.runExecuteToString(server, sql);
        if (StringUtils.isNotEmpty(response)) {
            Arrays.asList(response.split("\n")).forEach(v -> {
                ClickHouseResponse.ClickHouseConsume consume = new ClickHouseResponse.ClickHouseConsume();
                String[] strs = v.split("\t");
                consume.setElapsed(strs[0]);
                consume.setMemoryUsage(strs[1]);
                consumes.add(consume);
            });
        }
    }
}

package com.inke.compass.common;

import java.net.InetAddress;

public class NetWorkUtils
{
    private NetWorkUtils()
    {}

    /**
     * 获取本机主机名称
     *
     * @return 本机主机名
     */
    public static String getHostName()
    {
        try {
            InetAddress ia = InetAddress.getLocalHost();
            String host = ia.getHostName();
            if (host.equalsIgnoreCase("bogon")) {
                return "localhost";
            }
            return host;
        }
        catch (Exception var2) {
            var2.printStackTrace();
            return "";
        }
    }
}

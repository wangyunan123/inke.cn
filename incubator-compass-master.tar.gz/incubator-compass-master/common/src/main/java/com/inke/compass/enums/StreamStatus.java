package com.inke.compass.enums;

public enum StreamStatus
{
    RUNNING,
    ERROR,
    SUCCESS
}

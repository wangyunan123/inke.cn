package com.inke.compass.common;

import junit.framework.TestCase;
import org.junit.Test;

public class TestDateUtils
        extends TestCase
{

    @Test
    public void testGetTimeList()
    {
        System.out.println(DateUtils.getTimeList("2021-08-23", "2021-09-01"));
    }
}
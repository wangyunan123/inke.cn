package com.inke.compass.common;

import org.junit.Test;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

public class TestFileUtils
{
    String source = "http://fastdfs.dsj.inkept.cn:9324/dataworks/M00/0E/80/CgoAWmFtGqOAalRyCHTgTdU7O6o1903629";

    @Test
    public void downloadByNetwork()
    {
        System.out.println(FileUtils.downloadByNetwork(source, "/Users/shicheng/Desktop/aaa.txt"));
    }

    @Test
    public void read()
            throws IOException
    {
        AtomicReference<Integer> index = new AtomicReference<>(0);
        StringBuffer buffer = new StringBuffer();
        String header = Files.lines(Paths.get("/Users/shicheng/Desktop/aaa.txt"), StandardCharsets.UTF_8).findFirst().get();
        buffer.append(String.format("INSERT INTO %s.%s(%s) VALUES ", "inke",
                "ddd",
                String.join(",", header.split("\t"))));
        List<String> sqlValues = new ArrayList<>();
        Files.lines(Paths.get("/Users/shicheng/Desktop/aaa.txt"), StandardCharsets.UTF_8)
                        .forEach(line -> {
                            if (index.get() != 0) {
                                String[] columns = line.split("\t");
                                StringBuffer valueBuffer = new StringBuffer();
                                valueBuffer.append(String.format("\n(%s)", String.join(", ", Arrays.asList(columns).stream().map(v -> String.format("'%s'", v)).collect(Collectors.toList()))));
                                sqlValues.add(valueBuffer.toString());
                            }
                            index.set(index.get() + 1);
                        });
        buffer.append(String.join(",", sqlValues));
        System.out.println(buffer.toString());
    }
}
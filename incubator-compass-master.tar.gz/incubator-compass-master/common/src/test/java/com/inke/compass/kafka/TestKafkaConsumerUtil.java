package com.inke.compass.kafka;

import org.junit.Before;
import org.junit.Test;

public class TestKafkaConsumerUtil
{
    private String broker;
    private String topicName;
    private Integer maxSize;

    @Before
    public void setUp()
    {
        this.broker = "c1-dsj-druid091.bj:9092,c1-dsj-druid092.bj:9092,c1-dsj-druid093.bj:9092";
        this.topicName = "olap_sms_log";
        this.maxSize = 100;
    }

    @Test
    public void getRecord()
    {
        new KafkaConsumerUtil(broker, topicName, maxSize).getRecord().forEach(System.out::println);
    }
}
package com.inke.compass.common;

import com.google.gson.Gson;
import junit.framework.TestCase;
import org.junit.Test;

public class TestHttpUtils
        extends TestCase
{
    public void testRunExecuteToString()
    {
        System.out.println(HttpUtils.runExecuteToString("10.100.46.11", "SELECT 1 = 1"));
        System.out.println(HttpUtils.runExecuteToString("10.100.46.11", null));
        System.out.println(HttpUtils.runExecuteToString(null, "SELECT 1 = 1"));
    }

    public void testRunExecuteToStringFull()
    {
        System.out.println(new Gson().toJson(HttpUtils.runExecuteToStringFull("10.100.46.2", "SELECT\n" +
                "\tcount(1), ymd\n" +
                "FROM\n" +
                "inke.olap_active_app_local\n" +
                "group by ymd \n" +
                "order by ymd DESC \n" +
                "limit 10")));
    }

    public void testRunExecute()
    {
        System.out.println(HttpUtils.runExecute("http://emr.api.dataworks.inkept.cn/api/v1/query/info/HIVE3-20210811130335223-104444"));
    }
}
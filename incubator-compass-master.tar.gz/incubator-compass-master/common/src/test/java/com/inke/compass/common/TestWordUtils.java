package com.inke.compass.common;

import junit.framework.TestCase;

public class TestWordUtils
        extends TestCase
{

    public void testIsChinese()
    {
        System.out.println(WordUtils.containsChinese("你好"));
        System.out.println(WordUtils.containsChinese("Hello"));
        System.out.println(WordUtils.containsChinese("123"));
        System.out.println(WordUtils.containsChinese("你好123"));
        System.out.println(WordUtils.containsChinese("Hello你好"));
    }

    public void testGetPinyin()
    {
        System.out.println(WordUtils.getPinyin("你好", "_"));
        System.out.println(WordUtils.getPinyin("Hello", "_"));
        System.out.println(WordUtils.getPinyin("123", "_"));
        System.out.println(WordUtils.getPinyin("你好123", "_"));
        System.out.println(WordUtils.getPinyin("Hello你好", "_"));
    }
}
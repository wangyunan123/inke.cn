package com.inke.compass.common;

import junit.framework.TestCase;

public class TestNetWorkUtils extends TestCase {

    public void testGetHostName() {
        System.out.println(NetWorkUtils.getHostName());
    }
}
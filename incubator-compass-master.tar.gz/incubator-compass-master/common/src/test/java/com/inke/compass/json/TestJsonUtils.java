package com.inke.compass.json;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class TestJsonUtils
{
    private String json;

    @Before
    public void before()
    {
        json = "{\"md_chk\":\"02769e0683d9bde08f1d017e281717d5\",\"md_eid\":\"hall_headlines_show\",\"md_einfo\":{\"id\":\"1550\",\"title\":\"妮莫遭小摩羯偷塔反超 PK失败秒变“可爱小猪”\"},\"md_logid\":\"281,282,197,198,3006,210,226,243,200901,1082502,50404,206507,1117702,50302,60201,90001,200407,1146202,10209,1100901,1198902,80303,40201,1038100,1062702,30207,1158701,50203,1178002,100205,1139002,100301,1023602,80108,200202,1074001,100101,1078802,10002,100002,80202,70010\",\"md_mod\":\"1\",\"md_path\":\"InKeWebActivity-InKeWebActivity-HomeHallFragment(1C2076736E3D02B6)-InKeWebActivity-InKeWebActivity\",\"seq\":\"52\",\"md_session\":\"676691295b8dcbc164bca6272dd6db7c\",\"md_etype\":\"action\",\"md_userid\":\"1801821565\",\"md_etime\":\"1625124278894\",\"vv\":\"202103231054\",\"oaid\":\"110b9272013a9335\",\"ndid\":\"20210224075017fe482846fe68b393d36fa897af2aae930186c351daaa729a\",\"conn\":\"wifi\",\"xid\":\"120\",\"mtid\":\"d9c471b76710fca876003681b785db87\",\"devi\":\"0fc887eef226a7ba8a24c166138f9d52\",\"ram\":\"7984590848\",\"sign_from\":\"android\",\"aid\":\"6b93b0eda26f3b23\",\"uid\":\"1801821565\",\"cv\":\"IL8.2.20_Android\",\"proto\":\"8\",\"cpu\":\"[Adreno_(TM)_650][ARMv8_638_Qualcomm_Technologies,_Inc_SM8250]\",\"msid\":\"\",\"remote_port\":\"39044\",\"smid\":\"Duv1h7bl1mh42RbfUeLxwdH3W94WeB4XIxdlUI1d8m48iKBODE9yAKeZJRBvcQzgbQwAf4uTuet9ClE+djpkAmYg\",\"ast\":\"1\",\"dev_name\":\"Xiaomi\",\"evid\":\"3235643966383331363631633432613861623761363232666565373838636630\",\"code1006261001\":\"1625124290126\",\"logid\":\"281,282,197,198,3006,210,226,243,200901,1082502,50404,206507,1117702,50302,60201,90001,200407,1146202,10209,1100901,1198902,80303,40201,1038100,1062702,30207,1158701,50203,1178002,100205,1139002,100301,1023602,80108,200202,1074001,100101,1078802,10002,100002,80202,70010\",\"meid\":\"\",\"lc\":\"3ca6d77d5d774c84\",\"mtxid\":\"020000000000\",\"osversion\":\"android_30\",\"ua\":\"XiaomiM2007J3SC\",\"cc\":\"TG83048\",\"source_info\":\"eyJhcHBpZCI6IjI2MDAxNyIsInVpZCI6IjE4MDE4MjE1NjUiLCJwYWdlIjoiY29tLm1lZWxpdmUuaW5na2VlLndlYmtpdC51aS5JbktlV2ViQWN0aXZpdHkiLCJ0aW1lIjoiMTYyNTEyNDI3NDAzMyJ9\",\"record_time\":\"1625124291432\",\"client_ip\":\"120.83.191.78\"}";
    }

    @Test
    public void getJSONKeys()
    {
        JsonUtils.getJSONKeys(json).forEach(System.out::println);
    }
}
package com.inke.compass.metadata.mapper;

import com.inke.compass.metadata.model.CpFunction;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * @author wangyunan
 */
public interface CpFunctionsMapper
{
    /**
     * <font color="yellow">findAll</font>
     *
     * @Author: Mfrain
     * @Date: 2021/7/15 3:11 下午
     * @return: java.util.List<com.inke.compass.metadata.model.CpFunction>
     */
    @Select(value = "SELECT * FROM cp_functions where active = 1")
    @Results(id = "find_all_func", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "name", column = "name"),
            @Result(property = "type", column = "type"),
            @Result(property = "labelEn", column = "label_en"),
            @Result(property = "labelZh", column = "label_zh"),
            @Result(property = "description", column = "description"),
            @Result(property = "version", column = "version"),
            @Result(property = "lastVersion", column = "last_version"),
            @Result(property = "check", column = "check"),
            @Result(property = "mock", column = "mock"),
            @Result(property = "createTime", column = "create_time"),
            @Result(property = "lastTime", column = "last_time"),
            @Result(property = "createUser", column = "create_user"),
            @Result(property = "active", column = "active"),
            @Result(property = "functionsType", column = "functions_type"),
            @Result(property = "config", column = "config"),
    })
    List<CpFunction> findAll();
}


package com.inke.compass.metadata.mapper;

import com.inke.compass.metadata.model.DataSetExternalOneData;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

public interface DataSetExternalOneDataMapper
{
    @Insert(value = "<script>" +
            "INSERT INTO data_set_external_one_data (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"eod.taskId != null\" >`task_id`,</if>" +
            "   <if test=\"eod.schedulerId != null\" >`scheduler_id`,</if>" +
            "   <if test=\"eod.taskName != null\" >`task_name`,</if>" +
            "   <if test=\"eod.taskChineseName != null\" >`task_chinese_name`,</if>" +
            "   <if test=\"eod.schedulerName != null\" >`scheduler_name`,</if>" +
            "   <if test=\"eod.schedulerChineseName != null\" >`scheduler_chinese_name`,</if>" +
            "   <if test=\"eod.taskVersion != null\" >`task_version`,</if>" +
            "   <if test=\"eod.tableId != null\" >`table_id`,</if>" +
            "   <if test=\"eod.databaseName != null\" >`database_name`,</if>" +
            "   <if test=\"eod.databaseId != null\" >`database_id`,</if>" +
            "   <if test=\"eod.parallel != null\" >`parallel`,</if>" +
            "   <if test=\"eod.parallelThreadNum != null\" >`parallel_thread_num`,</if>" +
            "</trim>) " +
            "VALUES (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"eod.taskId != null\" >#{eod.taskId},</if>" +
            "   <if test=\"eod.schedulerId != null\" >#{eod.schedulerId},</if>" +
            "   <if test=\"eod.taskName != null\" >#{eod.taskName},</if>" +
            "   <if test=\"eod.taskChineseName != null\" >#{eod.taskChineseName},</if>" +
            "   <if test=\"eod.schedulerName != null\" >#{eod.schedulerName},</if>" +
            "   <if test=\"eod.schedulerChineseName != null\" >#{eod.schedulerChineseName},</if>" +
            "   <if test=\"eod.taskVersion != null\" >#{eod.taskVersion},</if>" +
            "   <if test=\"eod.tableId != null\" >#{eod.tableId},</if>" +
            "   <if test=\"eod.databaseName != null\" >#{eod.databaseName},</if>" +
            "   <if test=\"eod.databaseId != null\" >#{eod.databaseId},</if>" +
            "   <if test=\"eod.parallel != null\" >#{eod.parallel},</if>" +
            "   <if test=\"eod.parallelThreadNum != null\" >#{eod.parallelThreadNum},</if>" +
            "</trim>)" +
            "</script>")
    @Options(useGeneratedKeys = true, keyProperty = "eod.id", keyColumn = "id")
    void save(@Param(value = "eod") DataSetExternalOneData externalOneData);

    @Update("<script>" +
            "update data_set_external_one_data" +
            "    <set >" +
            "      <if test=\"eod.taskId != null\" >" +
            "        task_id = #{eod.taskId}," +
            "      </if>" +
            "      <if test=\"eod.schedulerId != null\" >" +
            "        scheduler_id = #{eod.schedulerId}," +
            "      </if>" +
            "      <if test=\"eod.taskName != null\" >" +
            "        task_name = #{eod.taskName}," +
            "      </if>" +
            "      <if test=\"eod.taskChineseName != null\" >" +
            "        task_chinese_name = #{eod.taskChineseName}," +
            "      </if>" +
            "      <if test=\"eod.schedulerName != null\" >" +
            "        scheduler_name = #{eod.schedulerName}," +
            "      </if>" +
            "      <if test=\"eod.schedulerChineseName != null\" >" +
            "        scheduler_chinese_name = #{eod.schedulerChineseName}," +
            "      </if>" +
            "      <if test=\"eod.taskVersion != null\" >" +
            "        task_version = #{eod.taskVersion}," +
            "      </if>" +
            "      <if test=\"eod.tableId != null\" >" +
            "        table_id = #{eod.tableId}," +
            "      </if>" +
            "      <if test=\"eod.databaseName != null\" >" +
            "        database_name = #{eod.database_name}," +
            "      </if>" +
            "      <if test=\"eod.databaseId != null\" >" +
            "        database_id = #{eod.database_id}," +
            "      </if>" +
            "      <if test=\"eod.parallel != null\" >" +
            "        parallel = #{eod.parallel}," +
            "      </if>" +
            "      <if test=\"eod.parallelThreadNum != null\" >" +
            "        parallel_thread_num = #{eod.parallelThreadNum}," +
            "      </if>" +
            "    </set>" +
            "    where id = #{eod.id}" +
            "</script>")
    void updateById(@Param(value = "eod") DataSetExternalOneData externalOneData);

    @Select(value = "SELECT * FROM data_set_external_one_data WHERE id = #{id}")
    @Results(id = "find_external_onedata_by_id", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "taskId", column = "task_id"),
            @Result(property = "schedulerId", column = "scheduler_id"),
            @Result(property = "taskName", column = "task_name"),
            @Result(property = "taskChineseName", column = "task_chinese_name"),
            @Result(property = "schedulerName", column = "scheduler_name"),
            @Result(property = "schedulerChineseName", column = "scheduler_chinese_name"),
            @Result(property = "taskVersion", column = "task_version"),
            @Result(property = "tableId", column = "table_id"),
            @Result(property = "databaseName", column = "database_name"),
            @Result(property = "databaseId", column = "database_id"),
            @Result(property = "parallel", column = "parallel"),
            @Result(property = "parallelThreadNum", column = "parallel_thread_num"),
            @Result(property = "createTime", column = "create_time"),
            @Result(property = "updateTime", column = "update_time")
    })
    DataSetExternalOneData findById(@Param(value = "id") Long id);

    @Select(value = "SELECT * FROM data_set_external_one_data WHERE task_name = #{taskName}")
    @Results(id = "find_external_onedata_by_task_name", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "taskId", column = "task_id"),
            @Result(property = "schedulerId", column = "scheduler_id"),
            @Result(property = "taskName", column = "task_name"),
            @Result(property = "taskChineseName", column = "task_chinese_name"),
            @Result(property = "schedulerName", column = "scheduler_name"),
            @Result(property = "schedulerChineseName", column = "scheduler_chinese_name"),
            @Result(property = "taskVersion", column = "task_version"),
            @Result(property = "tableId", column = "table_id"),
            @Result(property = "databaseName", column = "database_name"),
            @Result(property = "databaseId", column = "database_id"),
            @Result(property = "parallel", column = "parallel"),
            @Result(property = "parallelThreadNum", column = "parallel_thread_num"),
            @Result(property = "createTime", column = "create_time"),
            @Result(property = "updateTime", column = "update_time")
    })
    DataSetExternalOneData findByTaskName(@Param(value = "taskName") String taskName);

    @Select(value = "SELECT * FROM data_set_external_one_data WHERE scheduler_name = #{schedulerName}")
    @Results(id = "find_external_onedata_by_scheduler_name", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "taskId", column = "task_id"),
            @Result(property = "schedulerId", column = "scheduler_id"),
            @Result(property = "taskName", column = "task_name"),
            @Result(property = "taskChineseName", column = "task_chinese_name"),
            @Result(property = "schedulerName", column = "scheduler_name"),
            @Result(property = "schedulerChineseName", column = "scheduler_chinese_name"),
            @Result(property = "taskVersion", column = "task_version"),
            @Result(property = "tableId", column = "table_id"),
            @Result(property = "databaseName", column = "database_name"),
            @Result(property = "databaseId", column = "database_id"),
            @Result(property = "parallel", column = "parallel"),
            @Result(property = "parallelThreadNum", column = "parallel_thread_num"),
            @Result(property = "createTime", column = "create_time"),
            @Result(property = "updateTime", column = "update_time")
    })
    DataSetExternalOneData findBySchedulerName(@Param(value = "schedulerName") String schedulerName);
}

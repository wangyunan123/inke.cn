package com.inke.compass.metadata.mapper;

import com.inke.compass.metadata.model.CpEvent;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

/**
 * <p> @Description : 事件mapper </p>
 * <p> @incubator-compass </p>
 * <p> @Author : Mfrain </p>
 * <p> @Create Time : 2021/1/5 4:58 下午 </p>
 * <p> @Author Email: <a href="mailTo:mfr1339941169@qq.com">Mfrain</a> </p>
 * <p> @Version : 1.0 </p>
 */
public interface CpEventMapper
{
    /**
     * save
     *
     * @param event:
     * @Author: Mfrain
     * @Date: 2021/1/6 2:47 下午
     * @return: void
     */
    @Insert(value = "<script>" +
            "INSERT INTO cp_event (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"event.name != null\" >`name`,</if>" +
            "   <if test=\"event.label != null\" >`label`,</if>" +
            "   <if test=\"event.description != null\" >`description`,</if>" +
            "   <if test=\"event.type != null\" >`type`,</if>" +
            "   <if test=\"event.appId != null\" >`appid`,</if>" +
            "   <if test=\"event.editor != null\" >`editor`,</if>" +
            "   <if test=\"event.visible != null\" >`visible`,</if>" +
            "   <if test=\"event.defaulted != null\" >`defaulted`,</if>" +
            "   <if test=\"event.deleted != null\" >`deleted`,</if>" +
            "   <if test=\"event.prefix != null\" >`prefix`,</if>" +
            "</trim>) " +
            "VALUES (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"event.name != null\" >#{event.name},</if>" +
            "   <if test=\"event.label != null\" >#{event.label},</if>" +
            "   <if test=\"event.description != null\" >#{event.description},</if>" +
            "   <if test=\"event.type != null\" >#{event.type},</if>" +
            "   <if test=\"event.appId != null\" >#{event.appId},</if>" +
            "   <if test=\"event.editor != null\" >#{event.editor},</if>" +
            "   <if test=\"event.visible != null\" >#{event.visible},</if>" +
            "   <if test=\"event.defaulted != null\" >#{event.defaulted},</if>" +
            "   <if test=\"event.deleted != null\" >#{event.deleted},</if>" +
            "   <if test=\"event.prefix != null\" >#{event.prefix},</if>" +
            "</trim>)" +
            "</script>")
    @Options(useGeneratedKeys = true, keyProperty = "event.id", keyColumn = "id")
    void save(@Param(value = "event") CpEvent event);

    /**
     * update
     *
     * @param event:
     * @Author: Mfrain
     * @Date: 2021/1/6 2:47 下午
     * @return: void
     */
    @Update("<script>" +
            "update cp_event" +
            "    <set >" +
            "      <if test=\"event.name != null\" >" +
            "        name = #{event.name},    " +
            "      </if>" +
            "      <if test=\"event.label != null\" >" +
            "        label = #{event.label}," +
            "      </if>" +
            "      <if test=\"event.description != null\" >" +
            "        description = #{event.description},    " +
            "      </if>" +
            "      <if test=\"event.type != null\" >" +
            "        type = #{event.type}," +
            "      </if>" +
            "      <if test=\"event.appId != null\" >" +
            "        appId = #{event.appId}," +
            "      </if>" +
            "      <if test=\"event.editor != null\" >" +
            "        editor = #{event.editor}," +
            "      </if>" +
            "      <if test=\"event.visible != null\" >" +
            "        visible = #{event.visible}," +
            "      </if>" +
            "      <if test=\"event.defaulted != null\" >" +
            "        defaulted = #{event.defaulted}," +
            "      </if>" +
            "      <if test=\"event.deleted != null\" >" +
            "        deleted = #{event.deleted}," +
            "      </if>" +
            "      <if test=\"event.prefix != null\" >" +
            "        prefix = #{event.prefix}," +
            "      </if>" +
            "    </set>" +
            "    where id = #{event.id}" +
            "</script>")
    void update(@Param(value = "event") CpEvent event);

    /**
     * findAll
     *
     * @Author: Mfrain
     * @Date: 2021/1/6 2:47 下午
     * @return: java.util.List<com.inke.compass.metadata.model.EventInfo>
     */
    @Select(value = "SELECT * FROM cp_event ")
    @Results(id = "cp_event_all", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "name", column = "name"),
            @Result(property = "label", column = "label"),
            @Result(property = "description", column = "description"),
            @Result(property = "type", column = "type"),
            @Result(property = "appId", column = "appid"),
            @Result(property = "editor", column = "editor"),
            @Result(property = "visible", column = "visible"),
            @Result(property = "defaulted", column = "defaulted"),
            @Result(property = "deleted", column = "deleted"),
            @Result(property = "prefix", column = "prefix")
    })
    List<CpEvent> findAll();

    /**
     * 通过Id 删除事件
     *
     * @param eventId: 事件Id
     * @Author: Mfrain
     * @Date: 2021/1/7 10:38 上午
     * @return: void
     */
    @Delete("<script>" +
            "delete from cp_event " +
            " where id = #{eventId}" +
            "</script>")
    void deleteById(@Param(value = "eventId") long eventId);

    /**
     * findEventNameByTableNameAndAppId
     *
     * @param tName:
     * @param appId:
     * @Author: Mfrain
     * @Date: 2021/2/2 6:41 下午
     * @return: java.lang.String
     */
    @Select(value = "select label from cp_event where name = #{tName} limit 1 ")
    String findEventNameByTableNameAndAppId(@Param(value = "tName") String tName, @Param(value = "appId") long appId);

    /**
     * 获取Event
     *
     * @param eventId:
     * @Author: Mfrain
     * @Date: 2021/1/8 10:15 上午
     * @return: java.util.List<com.inke.compass.metadata.model.CpEvent>
     */
    @Select(value = "SELECT * FROM cp_event  where id = #{eventId}")
    @Results(id = "get_event_info", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "name", column = "name"),
            @Result(property = "label", column = "label"),
            @Result(property = "description", column = "description"),
            @Result(property = "type", column = "type"),
            @Result(property = "appId", column = "appid"),
            @Result(property = "editor", column = "editor"),
            @Result(property = "visible", column = "visible"),
            @Result(property = "defaulted", column = "defaulted"),
            @Result(property = "deleted", column = "deleted"),
            @Result(property = "prefix", column = "prefix")
    })
    List<CpEvent> getEventById(@Param(value = "eventId") long eventId);

    @Select(value = "SELECT * FROM cp_event WHERE id = #{id}")
    @Results(id = "eventInfo", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "name", column = "name"),
            @Result(property = "label", column = "label"),
            @Result(property = "description", column = "description"),
            @Result(property = "type", column = "type"),
            @Result(property = "appId", column = "appid"),
            @Result(property = "editor", column = "editor"),
            @Result(property = "visible", column = "visible"),
            @Result(property = "defaulted", column = "defaulted"),
            @Result(property = "deleted", column = "deleted"),
            @Result(property = "prefix", column = "prefix")
    })
    CpEvent findById(@Param(value = "id") Long id);

    /**
     * getEventByAppId
     *
     * @param appId:
     * @Author: Mfrain
     * @Date: 2021/1/18 1:27 上午
     * @return: java.util.List<com.inke.compass.metadata.model.CpEvent>
     */
    @Select(value = "SELECT * FROM cp_event  where appid = #{appId}")
    @Results(id = "get_eventId_info", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "name", column = "name"),
            @Result(property = "label", column = "label"),
            @Result(property = "description", column = "description"),
            @Result(property = "type", column = "type"),
            @Result(property = "appId", column = "appid"),
            @Result(property = "editor", column = "editor"),
            @Result(property = "visible", column = "visible"),
            @Result(property = "defaulted", column = "defaulted"),
            @Result(property = "deleted", column = "deleted"),
            @Result(property = "prefix", column = "prefix")
    })
    List<CpEvent> getEventByAppId(@Param(value = "appId") long appId);
}

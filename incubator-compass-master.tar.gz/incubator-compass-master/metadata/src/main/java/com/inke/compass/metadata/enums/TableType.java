package com.inke.compass.metadata.enums;

public enum TableType
{
    hive,
    onedata,
    kafka,
    presto,
    clickhouse,
}

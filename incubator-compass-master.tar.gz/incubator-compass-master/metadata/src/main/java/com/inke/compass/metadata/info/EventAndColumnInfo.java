package com.inke.compass.metadata.info;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class EventAndColumnInfo
{
    private String metricDirId;
    private String rootEvent;
    private Long eventId;
    private String eventName;
    private String eventLabel;
    private String eventType;
    private Long columnId;
    private String columnName;
    private String columnLabel;
    private String columnType;
    private String columnColumn;
    private String columnTable;
    private Long inputModelId;
}

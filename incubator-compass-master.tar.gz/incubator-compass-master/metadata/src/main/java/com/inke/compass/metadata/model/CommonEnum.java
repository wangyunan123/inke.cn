package com.inke.compass.metadata.model; /**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.util.Arrays;

/**
 * <p> CommonEnum </p>
 * <p> Description : CommonEnum </p>
 * <p> Author : qianmoQ </p>
 * <p> Version : 1.0 </p>
 * <p> Create Time : 2019-10-22 10:52 </p>
 * <p> Author Eamil: <a href="mailTo:shichengoooo@163.com">qianmoQ</a> </p>
 */
public enum CommonEnum
{
    QUERY_FAILED_ERROR(4000, "查询失败"),
    QUERY_REMOTE_NOT_SUPPORT_MULIT(4001, "远程API接口暂时不支持多条查询"),
    QUERY_FAILED_ABORTED_BY_USER(4002, "用户终止当前查询"),
    QUERY_FAILED_GONE(4003, "当前查询消失(服务器是否重启,请联系管理员)"),
    QUERY_FAILED_COLUMNS_ERROR(4004, "查询失败,未找到查询的数据行"),
    QUERY_FAILED_INTERNAL_ERROR(4005, "查询失败,内部连接错误"),
    QUERY_FAILED_TIMEOUT_ERROR(4006, "查询失败,超过了最大时间限制"),
    QUERY_FAILED_ID_ERROR(4007, "查询失败,无法获取查询ID"),
    QUERY_FAILED_EMPTY_ERROR(4008, "查询失败,查询语句不能为空"),
    QUERY_FAILED_LOGGER_ERROR(4009, "查询失败,无法获取查询ID相关日志"),
    QUERY_FAILED_DATA_ERROR(4010, "查询失败,无法获取查询ID相关结果"),
    QUERY_ON_RUNNING(4011, "当前任务正在执行中，请稍候查询"),

    QUERY_CONFIGURATION_MUST_NOT_EMPTY(4100, "请设置当前查询配置信息"),
    QUERY_CONFIGURATION_CONNECT_ERROR(4101, "当前查询配置信息连接出现问题,请检查"),

    QUERY_FAILED_ENGINE_NOT_SUPPORT(4200, "尚未支持该查询引擎"),
    QUERY_FAILED_RUNNING(4201, "查询失败,当前任务正在运行中"),
    QUERY_FAILED_CONSTAT(4202, "查询失败, 请联系管理员查询失败原因"),

    QUERY_FORMAT_NOT_SUPPORT(4300, "尚未支持该格式化模式"),

    CONVERT_PARAM_ERROR(4400, "无法转换为有效的查询参数"),

    NOT_SUPPORT(4500, "尚未支持该操作模式"),
    NOT_IMPLEMENT_FUNCTION(4502, String.format("尚未支持该方法函数")),
    NOT_FOUND_PATH(4503, "无效的访问路径"),
    NOT_SUPPORT_PATH(4504, "无法识别请求方法"),
    NOT_GET_PATH_TIMEOUT_PATH(4505, "网关超时或服务器故障、程序进程不够,请联系管理员"),
    NOT_USAGE_SERVICE_PATH(4506, "网关超时或服务器故障、程序进程不够,请联系管理员"),
    NOT_UNEXPECTED_PATH(4507, "不支持的错误信息,请联系管理员"),
    NOT_SERVICE_PATH(4508, "服务器内部错误(或检查传递参数),请联系管理员"),
    NOT_ACTIVE_SESSION_LIST(4509, "未发现Spark Session列表,请联系管理员"),
    NOT_ACTIVE_SESSION(4510, "未发现存活Spark Session,请联系管理员"),
    NOT_FOUND_USER(4511, "无效的用户,请联系管理员"),
    NOT_SUPPORT_ON_SLAVE(4512, "Slave节点不支持此操作"),
    NOT_ONLINE_NODE(4513, "当前没有可使用的存活节点"),

    HDFS_OUT_NOT_EMPTY(4600, "HDFS的输出路径不能为空"),

    DINGDING_NOT_HAS_KEYWORDS(4702, String.format("钉钉内容尚未包含安全关键字,支持如下关键字:%s", "")),
    DINGDING_TOKEN_HAS_ERROR(4703, String.format("无效的钉钉授权密钥,请检查或重置密钥")),
    DINGDING_URI_HAS_ERROR(4704, String.format("无效的钉钉URI地址,请检查")),
    DINGDING_SEND_HAS_ERROR(4705, String.format("发送的钉钉频率过快,请稍后再试")),
    DINGDING_PARAM_ERROR(4706, "缺少access_token参数,请检查"),
    DINGDING_API_HAS_ERROR(4707, String.format("新版API需要支持关键字,请设置后再试")),

    MONGO_NOT_SUPPORT_MODEL(4801, "尚未支持的Mongo数据模型"),

    SQL_VALIDATION(4900, "SQL校验失败,请检查"),
    SQL_NO_PERMISSION(4901, "当前执行用户没有执行该SQL权限，请去OneData平台申请，或者查看传递的platform是否有权限，可能是Presto语法导致该问题"),

    SERVER_INTERNAL_ERROR(4100, "服务内部出现错误,请联系管理员");

    private final Integer code;
    private final String value;

    CommonEnum(Integer code, String value)
    {
        this.code = code;
        this.value = value;
    }

    public String getValue()
    {
        return value;
    }

    public Integer getCode()
    {
        return code;
    }
}

package com.inke.compass.metadata.form;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <p> @Description : excel 转column参数 </p>
 * <p> @incubator-compass </p>
 * <p> @Author : <a href="mailTo:mfr1339941169@qq.com">Mfrain</a>  </p>
 * <p> @Create Time : 2021/3/30 11:21 上午 </p>
 * <p> @Version : 1.0 </p>
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ColumnExcelParameter
{
    private long eventId;
    private String name;
    private String column;
    private String label;
    private String dataType;
    private String description;
    private String express;
    private Boolean visible;
    private Boolean defaulted;
    private Boolean deleted;
    private String inputModel;
    private String type;
    private String content;
    private String tables;
    private String filter;
}

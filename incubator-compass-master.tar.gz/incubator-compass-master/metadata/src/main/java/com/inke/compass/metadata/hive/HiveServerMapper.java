package com.inke.compass.metadata.hive;

import io.edurt.gcm.hive.annotation.HiveSource;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

/**
 * <p> @Description : hiveServer2  链接接口  </p>
 * <p> @incubator-compass </p>
 * <p> @Author : Mfrain </p>
 * <p> @Create Time : 2021/6/30 6:47 下午 </p>
 * <p> @Author Email: <a href="mailTo:mfr1339941169@qq.com">Mfrain</a> </p>
 * <p> @Version : 1.0 </p>
 */
@HiveSource
public interface HiveServerMapper
{
    /**
     * <font color="yellow">hive 查询</font>
     *
     * @param sql SQL
     * @Author: Mfrain
     * @Date: 2021/6/30 6:54 下午
     * @return: java.lang.String
     */
    @Select("<script>" + "${sql}" + "</script>")
    List<Map<String, String>> query(@Param(value = "sql") String sql);
}

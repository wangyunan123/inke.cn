package com.inke.compass.metadata.mapper;

import com.inke.compass.metadata.model.CpAllHiveTable;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface CpAllHiveTableMapper
{


    //查询当前库下的所有hive表，标注是否完成导入的状态

    @Select(value = "select app,dbName,tbName,isImport from(SELECT b.app,b.db_name as dbName,b.tb_name as tbName,a.isImport FROM cp_hive_metadata as a left join hive_exist_table as b on a.appName=b.app and a.dbName=b.db_name and a.tbName=b.tb_name union SELECT b.app,b.db_name,b.tb_name,a.isImport FROM cp_hive_metadata as a right join hive_exist_table as b on a.appName=b.app and a.dbName=b.db_name and a.tbName=b.tb_name)q where app = #{appName}\n ")
    @Results(id = "allhivetable", value = {
            @Result(property = "id", column = "id"),
            @Result(property = "app", column = "app"),
            @Result(property = "dbName", column = "dbName"),
            @Result(property = "tbName", column = "tbName"),
            @Result(property = "isImport", column = "isImport")
    })
    List<CpAllHiveTable> findAllHiveTable(@Param(value = "appName") String appName);




}

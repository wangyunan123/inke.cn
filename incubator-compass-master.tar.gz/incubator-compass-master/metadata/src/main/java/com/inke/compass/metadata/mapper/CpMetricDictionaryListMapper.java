package com.inke.compass.metadata.mapper;

import com.inke.compass.metadata.info.MetricInfo;
import com.inke.compass.metadata.model.CpMetricDictionaryList;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

/**
 * <p> @Description : 指标字典目录操作mapper </p>
 * <p> @incubator-compass </p>
 * <p> @Author : Mfrain </p>
 * <p> @Create Time : 2021/4/15 4:01 下午 </p>
 * <p> @Author Email: <a href="mailTo:mfr1339941169@qq.com">Mfrain</a> </p>
 * <p> @Version : 1.0 </p>
 */
public interface CpMetricDictionaryListMapper
{
    /**
     * insert
     *
     * @param cmdl: nodeInfo
     * @Author: Mfrain
     * @Date: 2021/4/15 4:04 下午
     * @return: void
     */
    @Insert(value = "<script>" +
            "INSERT INTO cp_metric_dictionary_list (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"cmdl.appId != null\" >`appId`,</if>" +
            "   <if test=\"cmdl.name != null\" >`name`,</if>" +
            "   <if test=\"cmdl.label != null\" >`label`,</if>" +
            "   <if test=\"cmdl.description != null\" >`description`,</if>" +
            "   <if test=\"cmdl.type != null\" >`type`,</if>" +
            "   <if test=\"cmdl.owner != null\" >`owner`,</if>" +
            "   <if test=\"cmdl.rootNode != null\" >`rootNode`,</if>" +
            "   <if test=\"cmdl.visible != null\" >`visible`,</if>" +
            "   <if test=\"cmdl.adminNode != null\" >`adminNode`,</if>" +
            "</trim>) " +
            "VALUES (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"cmdl.appId != null\" >#{cmdl.appId},</if>" +
            "   <if test=\"cmdl.name != null\" >#{cmdl.name},</if>" +
            "   <if test=\"cmdl.label != null\" >#{cmdl.label},</if>" +
            "   <if test=\"cmdl.description != null\" >#{cmdl.description},</if>" +
            "   <if test=\"cmdl.type != null\" >#{cmdl.type},</if>" +
            "   <if test=\"cmdl.owner != null\" >#{cmdl.owner},</if>" +
            "   <if test=\"cmdl.rootNode != null\" >#{cmdl.rootNode},</if>" +
            "   <if test=\"cmdl.visible != null\" >#{cmdl.visible},</if>" +
            "   <if test=\"cmdl.adminNode != null\" >#{cmdl.adminNode},</if>" +
            "</trim>)" +
            "</script>")
    @Options(useGeneratedKeys = true, keyProperty = "cmdl.id", keyColumn = "id")
    void save(@Param(value = "cmdl") CpMetricDictionaryList cmdl);

    /**
     * update
     *
     * @param cmdl:
     * @Author: Mfrain
     * @Date: 2021/4/15 4:23 下午
     * @return: void
     */
    @Update("<script>" +
            "update cp_metric_dictionary_list" +
            "    <set >" +
            "      <if test=\"cmdl.appId != null\" >" +
            "        appId = #{cmdl.appId},    " +
            "      </if>" +
            "      <if test=\"cmdl.name != null\" >" +
            "        name = #{cmdl.name}," +
            "      </if>" +
            "      <if test=\"cmdl.label != null\" >" +
            "        label = #{cmdl.label}," +
            "      </if>" +
            "      <if test=\"cmdl.description != null\" >" +
            "        description = #{cmdl.description}," +
            "      </if>" +
            "      <if test=\"cmdl.type != null\" >" +
            "        type = #{cmdl.type}," +
            "      </if>" +
            "      <if test=\"cmdl.owner != null\" >" +
            "        owner = #{cmdl.owner}," +
            "      </if>" +
            "      <if test=\"cmdl.visible != null\" >" +
            "        visible = #{cmdl.visible}," +
            "      </if>" +
            "      <if test=\"cmdl.rootNode != null\" >" +
            "        rootNode = #{cmdl.rootNode}," +
            "      </if>" +
            "      <if test=\"cmdl.visible != null\" >" +
            "        visible = #{cmdl.visible}," +
            "      </if>" +
            "      <if test=\"cmdl.adminNode != null\" >" +
            "        adminNode = #{cmdl.adminNode}," +
            "      </if>" +
            "    </set>" +
            "    where id = #{cmdl.id} and adminNode = 0" +
            "</script>")
    void update(@Param(value = "cmdl") CpMetricDictionaryList cmdl);

    /**
     * 查询对应App下的所有节点
     *
     * @param appId: appId
     * @Author: Mfrain
     * @Date: 2021/4/15 4:28 下午
     * @return: java.util.List<com.inke.compass.metadata.model.CpAppInfo>
     */
    @Select(value = "SELECT * FROM cp_metric_dictionary_list where appId in( #{appId} , 0) ")
    @Results(id = "cp_metric_dictionary_list_app_all", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "appId", column = "appId"),
            @Result(property = "name", column = "name"),
            @Result(property = "label", column = "label"),
            @Result(property = "description", column = "description"),
            @Result(property = "type", column = "type"),
            @Result(property = "owner", column = "owner"),
            @Result(property = "createTime", column = "create_time"),
            @Result(property = "updateTime", column = "update_time"),
            @Result(property = "rootNode", column = "rootNode"),
            @Result(property = "visible", column = "visible"),
            @Result(property = "server", column = "server"),
            @Result(property = "adminNode", column = "adminNode")
    })
    List<CpMetricDictionaryList> findAll(@Param(value = "appId") long appId);

    /**
     * 删除目录 以及目录下的所有级联节点
     *
     * @param id:
     * @Author: Mfrain
     * @Date: 2021/4/15 4:34 下午
     * @return: void
     */
    @Delete("<script>" +
            "delete from cp_metric_dictionary_list " +
            " where adminNode = 0 and ( id = #{id}" +
            " or rootNode = #{id} )" +
            "</script>")
    void deleteById(@Param(value = "id") long id);

    /**
     * 查找App下同级目录
     *
     * @param rootNode:
     * @param appId:
     * @Author: Mfrain
     * @Date: 2021/4/15 4:39 下午
     * @return: java.util.List<com.inke.compass.metadata.model.CpMetricDictionaryList>
     */
    @Select(value = "SELECT * FROM cp_metric_dictionary_list where appid in( #{appId},0) and rootNode = #{rootNode}")
    @Results(id = "get_cmdl_info_1", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "appId", column = "appId"),
            @Result(property = "name", column = "name"),
            @Result(property = "label", column = "label"),
            @Result(property = "description", column = "description"),
            @Result(property = "type", column = "type"),
            @Result(property = "owner", column = "owner"),
            @Result(property = "createTime", column = "create_time"),
            @Result(property = "updateTime", column = "update_time"),
            @Result(property = "rootNode", column = "rootNode"),
            @Result(property = "visible", column = "visible"),
            @Result(property = "server", column = "server"),
            @Result(property = "adminNode", column = "adminNode")
    })
    List<CpMetricDictionaryList> findCmdlByAppIdAndRootNode(@Param(value = "rootNode") long rootNode, @Param(value = "appId") long appId);

    @Select(value = "SELECT id, label, type " +
            "FROM cp_metric_dictionary_list " +
            "WHERE appid IN( #{appId},0) " +
            "   AND rootNode = #{rootNode}" +
            "   AND visible = true")
    @Results(id = "metric_info", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "label", column = "label"),
            @Result(property = "type", column = "type")
    })
    List<MetricInfo> findAllByAppAndNotAndVisible(@Param(value = "rootNode") long rootNode, @Param(value = "appId") long appId);

    @Select(value = "SELECT id, label, type " +
            "FROM cp_metric_dictionary_list " +
            "WHERE appid = #{appId} " +
            "   AND rootNode = 0")
    @ResultMap(value = "metric_info")
    List<MetricInfo> findAllByApp(@Param(value = "appId") long appId);

    @Select(value = "SELECT id, label, type " +
            "FROM cp_metric_dictionary_list " +
            "WHERE type = 'METRIC' " +
            "   AND appId IN(0, #{appId}) " +
            "   AND visible = 1")
    @ResultMap(value = "metric_info")
    List<MetricInfo> findAllMetricByApp(@Param(value = "appId") Long appId);

    /**
     * 查找根目录
     *
     * @param appId:
     * @Author: Mfrain
     * @Date: 2021/4/15 4:39 下午
     * @return: java.util.List<com.inke.compass.metadata.model.CpMetricDictionaryList>
     */
    @Select(value = "SELECT * FROM cp_metric_dictionary_list where appid = #{appId} and rootNode = 0")
    @Results(id = "get_cmdl_info_3", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "appId", column = "appId"),
            @Result(property = "name", column = "name"),
            @Result(property = "label", column = "label"),
            @Result(property = "description", column = "description"),
            @Result(property = "type", column = "type"),
            @Result(property = "owner", column = "owner"),
            @Result(property = "createTime", column = "create_time"),
            @Result(property = "updateTime", column = "update_time"),
            @Result(property = "rootNode", column = "rootNode"),
            @Result(property = "visible", column = "visible"),
            @Result(property = "server", column = "server"),
            @Result(property = "adminNode", column = "adminNode")
    })
    List<CpMetricDictionaryList> getRootNodeList(@Param(value = "appId") long appId);

    /**
     * 获取指标字典 节点信息
     *
     * @param id:
     * @Author: Mfrain
     * @Date: 2021/4/15 4:45 下午
     * @return: java.util.List<com.inke.compass.metadata.model.CpEvent>
     */
    @Select(value = "SELECT * FROM cp_metric_dictionary_list  where id = #{id}")
    @Results(id = "get_cmdl_info_by_id", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "appId", column = "appId"),
            @Result(property = "name", column = "name"),
            @Result(property = "label", column = "label"),
            @Result(property = "description", column = "description"),
            @Result(property = "type", column = "type"),
            @Result(property = "owner", column = "owner"),
            @Result(property = "createTime", column = "create_time"),
            @Result(property = "updateTime", column = "update_time"),
            @Result(property = "rootNode", column = "rootNode"),
            @Result(property = "visible", column = "visible"),
            @Result(property = "server", column = "server"),
            @Result(property = "adminNode", column = "adminNode")
    })
    CpMetricDictionaryList getCmdlById(@Param(value = "id") long id);

    /**
     * <font color="yellow">getCmdlByName</font>
     *
     * @param name
     * @Author: Mfrain
     * @Date: 2021/4/29 2:46 下午
     * @return: java.util.List<com.inke.compass.metadata.model.CpMetricDictionaryList>
     */
    @Select(value = "SELECT * FROM cp_metric_dictionary_list  where name = #{name}")
    @Results(id = "get_cmdl_info_by_name", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "appId", column = "appId"),
            @Result(property = "name", column = "name"),
            @Result(property = "label", column = "label"),
            @Result(property = "description", column = "description"),
            @Result(property = "type", column = "type"),
            @Result(property = "owner", column = "owner"),
            @Result(property = "createTime", column = "create_time"),
            @Result(property = "updateTime", column = "update_time"),
            @Result(property = "rootNode", column = "rootNode"),
            @Result(property = "visible", column = "visible"),
            @Result(property = "server", column = "server"),
            @Result(property = "adminNode", column = "adminNode")
    })
    List<CpMetricDictionaryList> getCmdlByName(@Param(value = "name") String name);

    /**
     * <font color="yellow"></font>
     *
     * @param
     * @Author: Mfrain
     * @Date: 2021/5/8 7:24 下午
     * @return: java.util.List<com.inke.compass.metadata.model.CpMetricDictionaryList>
     */
    @Select(value = "SELECT * FROM cp_metric_dictionary_list  where type = 'METRIC'")
    @Results(id = "get_cmdl_info_metric_all", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "appId", column = "appId"),
            @Result(property = "name", column = "name"),
            @Result(property = "label", column = "label"),
            @Result(property = "description", column = "description"),
            @Result(property = "type", column = "type"),
            @Result(property = "owner", column = "owner"),
            @Result(property = "createTime", column = "create_time"),
            @Result(property = "updateTime", column = "update_time"),
            @Result(property = "rootNode", column = "rootNode"),
            @Result(property = "visible", column = "visible"),
            @Result(property = "server", column = "server"),
            @Result(property = "adminNode", column = "adminNode")
    })
    List<CpMetricDictionaryList> getMetricNode();
}

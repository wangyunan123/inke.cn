package com.inke.compass.metadata.form;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * <p> @Description : 指标字典操作 接口参数  </p>
 * <p> @incubator-compass </p>
 * <p> @Author : <a href="mailTo:mfr1339941169@qq.com">Mfrain</a>  </p>
 * <p> @Create Time : 2021/4/15 6:46 下午 </p>
 * <p> @Version : 1.0 </p>
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CpMetricDictionaryForm
        implements Serializable
{
    private static final long serialVersionUID = -5694328129879380197L;
    private String operation;
    private Long nodeId;
    private Long appId;
    private String nodeLabel;
    private String nodeName;
    private Boolean visible;
    private Boolean deleted;
    private Long rootNode;
    private String operator;

    public CpMetricDictionaryForm(Long nodeId)
    {
        this.nodeId = nodeId;
    }
}

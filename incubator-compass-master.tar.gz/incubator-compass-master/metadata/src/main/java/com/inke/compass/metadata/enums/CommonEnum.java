package com.inke.compass.metadata.enums;

public enum CommonEnum
{
    QUERY_FAILED_ERROR(9000, "查询失败"),
    QUERY_REMOTE_NOT_SUPPORT_MULIT(9001, "远程API接口暂时不支持多条查询"),
    NOT_FOUND_USER(9002, "无效的用户,请联系管理员"),
    QUERY_FAILED_DATA_ERROR(9003, "查询失败,无法获取查询ID相关结果"),
    UNVALID_ACTIONS(9003, "无效的action"),
    UNVALID_DATASOURCE(9004, "无效的数据源"),
    TABLE_NOT_FOUND(9004, "表未找到"),
    UNVALID_OPERATION(9004, "无效的操作"),
    UNVALID_METRIC(9004, "无效的指标");

    private final Integer code;
    private final String value;

    CommonEnum(Integer code, String value)
    {
        this.code = code;
        this.value = value;
    }

    public String getValue()
    {
        return value;
    }

    public Integer getCode()
    {
        return code;
    }
}

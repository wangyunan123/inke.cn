package com.inke.compass.metadata.enums;

public enum DataSource
{
    HTTP,
    HTTPS
}

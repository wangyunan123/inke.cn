package com.inke.compass.metadata.enums;

/**
 * @author cxg
 */

public enum MetadataSyncStatus
{
    //
    WAITING,
    SYNCING,
    SUCCESS,
    FAILED
}

/**
 * Copyright 2021 json.cn
 */
package com.inke.compass.metadata.form;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * Auto-generated: 2021-07-08 4:53:40
 *
 * @author json.cn (i@json.cn)
 * @website http://www.json.cn/java2pojo/
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class History
{
    private Long id;
    private String label;
    private String status;
    private String startTime;
    private String endTime;
}
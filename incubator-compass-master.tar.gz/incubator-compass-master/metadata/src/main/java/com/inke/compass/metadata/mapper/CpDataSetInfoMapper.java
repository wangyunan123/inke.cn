package com.inke.compass.metadata.mapper;

import com.inke.compass.metadata.info.DatasetInfo;
import com.inke.compass.metadata.model.CpDataSetInfo;
import org.apache.ibatis.annotations.*;

import java.util.List;

/**
 * <p> @Description : 事件mapper </p>
 * <p> @incubator-compass </p>
 * <p> @Author : Mfrain </p>
 * <p> @Create Time : 2021/1/5 4:58 下午 </p>
 * <p> @Author Email: <a href="mailTo:mfr1339941169@qq.com">Mfrain</a> </p>
 * <p> @Version : 1.0 </p>
 */
public interface CpDataSetInfoMapper {
    /**
     * save
     *
     * @param ds:
     * @Author: Mfrain
     * @Date: 2021/1/6 2:47 下午
     * @return: void
     */
    @Insert(value = "<script>" +
            "INSERT INTO cp_dataset_info (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"ds.type != null\" >`type`,</if>" +
            "   <if test=\"ds.app != null\" >`app`,</if>" +
            "   <if test=\"ds.label != null\" >`label`,</if>" +
            "   <if test=\"ds.dbname != null\" >`dbname`,</if>" +
            "   <if test=\"ds.tbname != null\" >`tbname`,</if>" +
            "   <if test=\"ds.createtime != null\" >`createtime`,</if>" +
            "   <if test=\"ds.updatetime != null\" >`updatetime`,</if>" +
            "   <if test=\"ds.creator != null\" >`creator`,</if>" +
            "   <if test=\"ds.updater != null\" >`updater`,</if>" +
//            "   <if test=\"ds.complementStartDay != null\" >`complementStartDay`,</if>" +
//            "   <if test=\"ds.complementEndDay != null\" >`complementEndDay`,</if>" +
            "   <if test=\"ds.cycle != null\" >`cycle`,</if>" +
            "   <if test=\"ds.syncDay != null\" >`sync_day`,</if>" +
            "   <if test=\"ds.syncHour != null\" >`sync_hour`,</if>" +
            "   <if test=\"ds.syncMinute != null\" >`sync_minute`,</if>" +
            "   <if test=\"ds.size != null\" >`size`,</if>" +
            "   <if test=\"ds.desc != null\" >`desc`,</if>" +
            "   <if test=\"ds.info != null\" >`info`,</if>" +
            "   <if test=\"ds.rootdir != null\" >`rootdir`,</if>" +
            "   <if test=\"ds.tabletype != null\" >`tabletype`,</if>" +
            "   <if test=\"ds.active != null\" >`active`,</if>" +
            "   <if test=\"ds.query != null\" >`query`,</if>" +
            "   <if test=\"ds.dataTableLife != null\" >`data_life`,</if>" +
            "   <if test=\"ds.dataSetLife != null\" >`life`,</if>" +
            "   <if test=\"ds.basicTable != null\" >`basic_table`,</if>" +
            "   <if test=\"ds.structureVersion != null\" >`structure_version`,</if>" +
            "   <if test=\"ds.isRealtime != null\" >`is_realtime`,</if>" +
            "</trim>) " +
            "VALUES (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"ds.type != null\" >#{ds.type},</if>" +
            "   <if test=\"ds.app != null\" >#{ds.app},</if>" +
            "   <if test=\"ds.label != null\" >#{ds.label},</if>" +
            "   <if test=\"ds.dbname != null\" >#{ds.dbname},</if>" +
            "   <if test=\"ds.tbname != null\" >#{ds.tbname},</if>" +
            "   <if test=\"ds.createtime != null\" >#{ds.createtime},</if>" +
            "   <if test=\"ds.updatetime != null\" >#{ds.updatetime},</if>" +
            "   <if test=\"ds.creator != null\" >#{ds.creator},</if>" +
            "   <if test=\"ds.updater != null\" >#{ds.updater},</if>" +
//            "   <if test=\"ds.complementStartDay != null\" >#{ds.complementStartDay},</if>" +
//            "   <if test=\"ds.complementEndDay != null\" >#{ds.complementEndDay},</if>" +
            "   <if test=\"ds.cycle != null\" >#{ds.cycle},</if>" +
            "   <if test=\"ds.syncDay != null\" >#{ds.syncDay},</if>" +
            "   <if test=\"ds.syncHour != null\" >#{ds.syncHour},</if>" +
            "   <if test=\"ds.syncMinute != null\" >#{ds.syncMinute},</if>" +
            "   <if test=\"ds.size != null\" >#{ds.size},</if>" +
            "   <if test=\"ds.desc != null\" >#{ds.desc},</if>" +
            "   <if test=\"ds.info != null\" >#{ds.info},</if>" +
            "   <if test=\"ds.rootdir != null\" >#{ds.rootdir},</if>" +
            "   <if test=\"ds.tabletype != null\" >#{ds.tabletype},</if>" +
            "   <if test=\"ds.active != null\" >#{ds.active},</if>" +
            "   <if test=\"ds.query != null\" >#{ds.query},</if>" +
            "   <if test=\"ds.dataTableLife != null\" >#{ds.dataTableLife},</if>" +
            "   <if test=\"ds.dataSetLife != null\" >#{ds.dataSetLife},</if>" +
            "   <if test=\"ds.basicTable != null\" >#{ds.basicTable},</if>" +
            "   <if test=\"ds.structureVersion != null\" >#{ds.structureVersion},</if>" +
            "   <if test=\"ds.isRealtime != null\" >#{ds.isRealtime},</if>" +
            "</trim>)" +
            "</script>")
    @Options(useGeneratedKeys = true, keyProperty = "ds.id", keyColumn = "id")
    void save(@Param(value = "ds") CpDataSetInfo ds);

    /**
     * update
     *
     * @param ds:
     * @Author: Mfrain
     * @Date: 2021/1/6 2:47 下午
     * @return: void
     */
    @Update("<script>" +
            "update cp_dataset_info" +
            "    <set >" +
            "      <if test=\"ds.type != null\" >" +
            "        type = #{ds.type},    " +
            "      </if>" +
            "      <if test=\"ds.app != null\" >" +
            "        app = #{ds.app}," +
            "      </if>"
            + "      <if test=\"ds.label != null\" >" +
            "        label = #{ds.label}," +
            "      </if>" +
            "      <if test=\"ds.dbname != null\" >" +
            "        dbname = #{ds.dbname},    " +
            "      </if>" +
            "      <if test=\"ds.tbname != null\" >" +
            "        tbname = #{ds.tbname}," +
            "      </if>" +
            "      <if test=\"ds.creator != null\" >" +
            "        creator = #{ds.creator}," +
            "      </if>" +
            "      <if test=\"ds.updater != null\" >" +
            "        updater = #{ds.updater}," +
            "      </if>" +
//            "      <if test=\"ds.complementStartDay != null\" >" +
//            "        creator = #{ds.complementStartDay}," +
//            "      </if>" +
//            "      <if test=\"ds.complementEndDay != null\" >" +
//            "        creator = #{ds.complementEndDay}," +
//            "      </if>" +
            "      <if test=\"ds.cycle != null\" >" +
            "        cycle = #{ds.cycle}," +
            "      </if>" +
            "      <if test=\"ds.syncDay != null\" >" +
            "        sync_day = #{ds.syncDay}," +
            "      </if>" +
            "      <if test=\"ds.syncHour != null\" >" +
            "        sync_hour = #{ds.syncHour}," +
            "      </if>" +
            "      <if test=\"ds.syncMinute != null\" >" +
            "        sync_minute = #{ds.syncMinute}," +
            "      </if>" +
            "      <if test=\"ds.size != null\" >" +
            "        size = #{ds.size}," +
            "      </if>" +
            "      <if test=\"ds.desc != null\" >" +
            "        `desc` = #{ds.desc}," +
            "      </if>" +
            "      <if test=\"ds.info != null\" >" +
            "        info = #{ds.info}," +
            "      </if>" +
            "      <if test=\"ds.rootdir != null\" >" +
            "        rootdir = #{ds.rootdir}," +
            "      </if>" +
            "      <if test=\"ds.tabletype != null\" >" +
            "        tabletype = #{ds.tabletype}," +
            "      </if>" +
            "      <if test=\"ds.active != null\" >" +
            "        active = #{ds.active}," +
            "      </if>" +
            "      <if test=\"ds.query != null\" >" +
            "        query = #{ds.query}," +
            "      </if>" +
            "      <if test=\"ds.dataTableLife != null\" >" +
            "        data_life = #{ds.dataTableLife}," +
            "      </if>" +
            "      <if test=\"ds.dataSetLife != null\" >" +
            "        life = #{ds.dataSetLife}," +
            "      </if>" +
            "      <if test=\"ds.basicTable != null\" >" +
            "        basic_table = #{ds.basicTable}," +
            "      </if>" +
            "      <if test=\"ds.structureVersion != null\" >" +
            "        structure_version = #{ds.structureVersion}," +
            "      </if>" +
            "    </set>" +
            "    where id = #{ds.id}" +
            "</script>")
    void update(@Param(value = "ds") CpDataSetInfo ds);

    /**
     * findAll
     *
     * @Author: Mfrain
     * @Date: 2021/1/6 2:47 下午
     * @return: java.util.List<com.inke.compass.metadata.model.EventInfo>
     */
    @Select(value = "SELECT * FROM cp_dataset_info ")
    @Results(id = "cp_dataset_info_all", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "type", column = "type"),
            @Result(property = "app", column = "app"),
            @Result(property = "label", column = "label"),
            @Result(property = "dbname", column = "dbname"),
            @Result(property = "tbname", column = "tbname"),
            @Result(property = "createtime", column = "create_time"),
            @Result(property = "updatetime", column = "update_time"),
            @Result(property = "creator", column = "creator"),
//            @Result(property = "complementStartDay", column = "complementStartDay"),
//            @Result(property = "complementEndDay", column = "complementEndDay"),
            @Result(property = "cycle", column = "cycle"),
            @Result(property = "syncDay", column = "sync_day"),
            @Result(property = "syncHour", column = "sync_hour"),
            @Result(property = "syncMinute", column = "sync_minute"),
            @Result(property = "size", column = "size"),
            @Result(property = "desc", column = "desc"),
            @Result(property = "info", column = "info"),
            @Result(property = "rootdir", column = "rootdir"),
            @Result(property = "tabletype", column = "tabletype"),
            @Result(property = "active", column = "active"),
            @Result(property = "dataTableLife", column = "data_life"),
            @Result(property = "dataSetLife", column = "life"),
            @Result(property = "basicTable", column = "basic_table"),
            @Result(property = "structureVersion", column = "structure_version")
    })
    List<CpDataSetInfo> findAll();

    /**
     * <font color="yellow">查询所有数据集</font>
     *
     * @Author: Mfrain
     * @Date: 2021/7/23 3:55 下午
     * @return: java.util.List<com.inke.compass.metadata.model.CpDataSetInfo>
     */
    @Select(value = "SELECT * FROM cp_dataset_info where `type` = 'TABLE' and tabletype = 'hive' ")
    @Results(id = "cp_dataset_info_all_table", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "type", column = "type"),
            @Result(property = "app", column = "app"),
            @Result(property = "label", column = "label"),
            @Result(property = "dbname", column = "dbname"),
            @Result(property = "tbname", column = "tbname"),
            @Result(property = "createtime", column = "createtime"),
            @Result(property = "updatetime", column = "updatetime"),
            @Result(property = "creator", column = "creator"),
//            @Result(property = "complementStartDay", column = "complementStartDay"),
//            @Result(property = "complementEndDay", column = "complementEndDay"),
            @Result(property = "cycle", column = "cycle"),
            @Result(property = "syncDay", column = "sync_day"),
            @Result(property = "syncHour", column = "sync_hour"),
            @Result(property = "syncMinute", column = "sync_minute"),
            @Result(property = "size", column = "size"),
            @Result(property = "desc", column = "desc"),
            @Result(property = "info", column = "info"),
            @Result(property = "rootdir", column = "rootdir"),
            @Result(property = "tabletype", column = "tabletype"),
            @Result(property = "active", column = "active"),
            @Result(property = "structureVersion", column = "structure_version")
    })
    List<CpDataSetInfo> findAllTable();

    /**
     * findByAppAndRootId
     *
     * @param rootNode:
     * @param app:
     * @Author: Mfrain
     * @Date: 2021/7/8 5:43 上午
     * @return: java.util.List<com.inke.compass.metadata.model.CpDataSetInfo>
     */
    @Select(value = "SELECT * FROM cp_dataset_info where app = #{app} and rootdir = #{rootNode}")
    @Results(id = "cp_dataset_info_all_by_app_root_id", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "type", column = "type"),
            @Result(property = "app", column = "app"),
            @Result(property = "label", column = "label"),
            @Result(property = "dbname", column = "dbname"),
            @Result(property = "tbname", column = "tbname"),
            @Result(property = "createtime", column = "createtime"),
            @Result(property = "updatetime", column = "updatetime"),
            @Result(property = "creator", column = "creator"),
//            @Result(property = "complementStartDay", column = "complementStartDay"),
//            @Result(property = "complementEndDay", column = "complementEndDay"),
            @Result(property = "cycle", column = "cycle"),
            @Result(property = "syncDay", column = "sync_day"),
            @Result(property = "syncHour", column = "sync_hour"),
            @Result(property = "syncMinute", column = "sync_minute"),
            @Result(property = "size", column = "size"),
            @Result(property = "desc", column = "desc"),
            @Result(property = "rootdir", column = "rootdir"),
            @Result(property = "tabletype", column = "tabletype"),
            @Result(property = "active", column = "active"),
            @Result(property = "dataTableLife", column = "data_life"),
            @Result(property = "dataSetLife", column = "life"),
            @Result(property = "structureVersion", column = "structure_version")
    })
    List<CpDataSetInfo> findByAppAndRootId(@Param(value = "rootNode") long rootNode, @Param(value = "app") String app);

    @Select(value = "<script>" +
            "SELECT * FROM cp_dataset_info where 1=1" +
            "<if test=\"app != null\">" +
            "   AND app = #{app} " +
            "</if>" +
            "<if test=\"rootNode != null\">" +
            "   AND rootdir = #{rootNode} " +
            "</if>" +
            "<if test=\"type != null\">" +
            "   AND `type` = #{type} " +
            "</if>" +
            "<if test=\"labelLike != null\">" +
            "   AND `label` LIKE CONCAT('%', #{labelLike}, '%')" +
            "</if>" +
            "   ORDER BY id DESC LIMIT #{offset}, #{size}" +
            "</script>")
    @Results(id = "cp_dataset_info_all_by_conditions", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "type", column = "type"),
            @Result(property = "app", column = "app"),
            @Result(property = "label", column = "label"),
            @Result(property = "dbname", column = "dbname"),
            @Result(property = "tbname", column = "tbname"),
            @Result(property = "createtime", column = "createtime"),
            @Result(property = "updatetime", column = "updatetime"),
            @Result(property = "creator", column = "creator"),
            @Result(property = "cycle", column = "cycle"),
            @Result(property = "syncDay", column = "sync_day"),
            @Result(property = "syncHour", column = "sync_hour"),
            @Result(property = "syncMinute", column = "sync_minute"),
            @Result(property = "size", column = "size"),
            @Result(property = "desc", column = "desc"),
            @Result(property = "rootdir", column = "rootdir"),
            @Result(property = "tabletype", column = "tabletype"),
            @Result(property = "active", column = "active"),
            @Result(property = "dataTableLife", column = "data_life"),
            @Result(property = "dataSetLife", column = "life"),
            @Result(property = "structureVersion", column = "structure_version")
    })
    List<CpDataSetInfo> findByConditions(
            @Param(value = "rootNode") Long rootNode,
            @Param(value = "app") String app,
            @Param(value = "labelLike") String labelLike,
            @Param(value = "type") String type,
            @Param(value = "offset") int offset,
            @Param(value = "size") int size);

    @Select(value = "<script>" +
            "SELECT COUNT(1) FROM cp_dataset_info where 1=1" +
            "<if test=\"app != null\">" +
            "   AND app = #{app} " +
            "</if>" +
            "<if test=\"type != null\">" +
            "   AND `type` = #{type} " +
            "</if>" +
            "<if test=\"rootNode != null\">" +
            "   AND rootdir = #{rootNode} " +
            "</if>" +
            "<if test=\"labelLike != null\">" +
            "   AND `label` LIKE CONCAT('%', #{labelLike}, '%')" +
            "</if>" +
            "</script>")
    @ResultType(value = Integer.class)
    Integer countByConditions(
            @Param(value = "rootNode") Long rootNode,
            @Param(value = "type") String type,
            @Param(value = "app") String app,
            @Param(value = "labelLike") String labelLike);

    /**
     * <font color="yellow">获取拥有着所有数据集</font>
     *
     * @param creator creator
     * @param app     app
     * @Author: Mfrain
     * @Date: 2021/7/14 7:11 上午
     * @return: java.util.List<com.inke.compass.metadata.model.CpDataSetInfo>
     */
    @Select(value = "SELECT * FROM cp_dataset_info where app = #{app} and creator = #{creator} and type = 'TABLE' and active = 1 ")
    @Results(id = "cp_dataset_info_all_by_app_root_id_dataSets", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "type", column = "type"),
            @Result(property = "app", column = "app"),
            @Result(property = "label", column = "label"),
            @Result(property = "dbname", column = "dbname"),
            @Result(property = "tbname", column = "tbname"),
            @Result(property = "createtime", column = "createtime"),
            @Result(property = "updatetime", column = "updatetime"),
            @Result(property = "creator", column = "creator"),
//            @Result(property = "complementStartDay", column = "complementStartDay"),
//            @Result(property = "complementEndDay", column = "complementEndDay"),
            @Result(property = "cycle", column = "cycle"),
            @Result(property = "syncDay", column = "sync_day"),
            @Result(property = "syncHour", column = "sync_hour"),
            @Result(property = "syncMinute", column = "sync_minute"),
            @Result(property = "size", column = "size"),
            @Result(property = "desc", column = "desc"),
            @Result(property = "rootdir", column = "rootdir"),
            @Result(property = "tabletype", column = "tabletype"),
            @Result(property = "active", column = "active"),
            @Result(property = "dataTableLife", column = "data_life"),
            @Result(property = "dataSetLife", column = "life"),
            @Result(property = "structureVersion", column = "structure_version")
    })
    List<CpDataSetInfo> findOwnerDataSets(@Param(value = "creator") String creator, @Param(value = "app") String app);

    @Select(value = "SELECT a.id AS id, COALESCE(b.status, 'NONE') AS status, tbname, a.app AS app, a.tbname AS tbname, label, tabletype, creator, a.size AS size, cycle, create_time " +
            "FROM cp_dataset_info a " +
            "LEFT JOIN cp_dataset_sync_history b ON b.dataset_id = a.id " +
            "AND b.id = (SELECT MAX(c.id) FROM cp_dataset_sync_history c WHERE c.dataset_id = a.id) " +
            "WHERE a.app = #{app} AND a.creator = #{creator} AND a.type = 'TABLE' AND a.active = 1 ")
    @Results(id = "datasetInfo", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "name", column = "tbname"),
            @Result(property = "label", column = "label"),
            @Result(property = "type", column = "tabletype"),
            @Result(property = "owner", column = "creator"),
            @Result(property = "size", column = "size"),
//            @Result(property = "complementStartDay", column = "complementStartDay"),
//            @Result(property = "complementEndDay", column = "complementEndDay"),
            @Result(property = "cycle", column = "cycle"),
            @Result(property = "status", column = "status"),
            @Result(property = "tbname", column = "tbname"),
            @Result(property = "app", column = "app"),
            @Result(property = "createTime", column = "create_time")
    })
    List<DatasetInfo> findByUserAndApp(@Param(value = "creator") String user, @Param(value = "app") String app);

    /**
     * 通过Id 删除数据集
     *
     * @param ds: ds
     * @Author: Mfrain
     * @Date: 2021/1/7 10:38 上午
     * @return: void
     */
    @Delete("<script>" +
            "delete FROM cp_dataset_info " +
            " where id = #{ds}" +
            "</script>")
    void deleteById(@Param(value = "ds") long ds);

    /**
     * <font color="yellow"></font>
     *
     * @param id
     * @Author: Mfrain
     * @Date: 2021/7/9 4:50 下午
     * @return: java.util.List<com.inke.compass.metadata.model.CpDataSetInfo>
     */
    @Select(value = "SELECT * FROM cp_dataset_info where id = #{id}")
    @Results(id = "cp_dataset_info_by_select_id", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "type", column = "type"),
            @Result(property = "app", column = "app"),
            @Result(property = "label", column = "label"),
            @Result(property = "dbname", column = "dbname"),
            @Result(property = "tbname", column = "tbname"),
            @Result(property = "createtime", column = "create_time"),
            @Result(property = "updatetime", column = "update_time"),
            @Result(property = "creator", column = "creator"),
//            @Result(property = "complementStartDay", column = "complementStartDay"),
//            @Result(property = "complementEndDay", column = "complementEndDay"),
            @Result(property = "cycle", column = "cycle"),
            @Result(property = "syncDay", column = "sync_day"),
            @Result(property = "syncHour", column = "sync_hour"),
            @Result(property = "syncMinute", column = "sync_minute"),
            @Result(property = "size", column = "size"),
            @Result(property = "desc", column = "desc"),
            @Result(property = "rootdir", column = "rootdir"),
            @Result(property = "tabletype", column = "tabletype"),
            @Result(property = "active", column = "active"),
            @Result(property = "dataTableLife", column = "data_life"),
            @Result(property = "structureVersion", column = "structure_version"),
            @Result(property = "dataSetLife", column = "life")
    })
    CpDataSetInfo getDataSetById(@Param(value = "id") long id);

    //根据dataset的落库数据，判断是否是非分区表
    @Select(value = "SELECT query FROM cp_dataset_info where where id = #{id}")
    String queryBody(@Param(value = "id") long id);

    @Select(value = "SELECT tabletype FROM cp_dataset_info where where id = #{id}")
    String tableTypeBody(@Param(value = "id") long id);



////数据集补数的mapper
//    @Select(value = "SELECT * FROM cp_dataset_info where id = #{id}")
//    @Results(id = "cp_dataset_info_by_id", value = {
//            @Result(property = "id", column = "id", id = true),
//            @Result(property = "type", column = "type"),
//            @Result(property = "app", column = "app"),
//            @Result(property = "label", column = "label"),
//            @Result(property = "dbname", column = "dbname"),
//            @Result(property = "tbname", column = "tbname"),
//            @Result(property = "createtime", column = "create_time"),
//            @Result(property = "updatetime", column = "update_time"),
//            @Result(property = "creator", column = "creator"),
////            @Result(property = "complementStartDay", column = "complementStartDay"),
////            @Result(property = "complementEndDay", column = "complementEndDay"),
//            @Result(property = "cycle", column = "cycle"),
//            @Result(property = "syncDay", column = "sync_day"),
//            @Result(property = "syncHour", column = "sync_hour"),
//            @Result(property = "syncMinute", column = "sync_minute"),
//            @Result(property = "size", column = "size"),
//            @Result(property = "desc", column = "desc"),
//            @Result(property = "rootdir", column = "rootdir"),
//            @Result(property = "tabletype", column = "tabletype"),
//            @Result(property = "active", column = "active")
//    })
//    CpDataSetInfo complementDataSetById(@Param(value = "id") long id,@Param(value = "complementStartDay") String complementStartDay,@Param(value = "complementEndDay") String complementEndDay);

    /**
     * <font color="yellow"></font>
     *
     * @param rootdir
     * @param label
     * @Author: Mfrain
     * @Date: 2021/7/13 7:52 下午
     * @return: long
     */
    @Select(value = "SELECT count(1) FROM cp_dataset_info where rootdir = #{rootdir} and label =#{label} ")
    long existInDir(@Param(value = "rootdir") long rootdir, @Param(value = "label") String label);

    @Select(value = "SELECT id FROM cp_dataset_info where rootdir = #{rootdir} and label =#{label}")
    long findDataSetAfterBuild(@Param(value = "rootdir") long rootdir, @Param(value = "label") String label);


    @Select(value = "SELECT id FROM cp_dataset_info where label = #{label} and rootdir =#{dirId}")
    long findDataSetAfterBuildv1(@Param(value = "label") String desc, @Param(value = "dirId") Long dirId);

    /**
     * @param label
     */
    @Select(value = "SELECT * FROM cp_dataset_info where `label` = #{label}")
    @Results(id = "cp_dataset_info_by_name", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "type", column = "type"),
            @Result(property = "app", column = "app"),
            @Result(property = "label", column = "label"),
            @Result(property = "dbname", column = "dbname"),
            @Result(property = "tbname", column = "tbname"),
            @Result(property = "createtime", column = "create_time"),
            @Result(property = "updatetime", column = "update_time"),
            @Result(property = "creator", column = "creator"),
            @Result(property = "cycle", column = "cycle"),
            @Result(property = "syncDay", column = "sync_day"),
            @Result(property = "syncHour", column = "sync_hour"),
            @Result(property = "syncMinute", column = "sync_minute"),
            @Result(property = "size", column = "size"),
            @Result(property = "desc", column = "desc"),
            @Result(property = "rootdir", column = "rootdir"),
            @Result(property = "tabletype", column = "tabletype"),
            @Result(property = "active", column = "active"),
            @Result(property = "dataTableLife", column = "data_life"),
            @Result(property = "dataSetLife", column = "life"),
            @Result(property = "structureVersion", column = "structure_version")
    })
    CpDataSetInfo getDataSetByLabel(@Param(value = "label") String label);
    
    /**
     *
     * @param app
     * @param ids
     * @return
     */
    @Select("<script>"+
        "SELECT * FROM cp_dataset_info WHERE 1=1  AND `app` = #{app} " +
        "AND id IN  " +
        "   <foreach item='item' index='index' collection='ids' open='(' separator=',' close=')'>" +
        "       #{item}" +
        "   </foreach>" +
        "</script>"
    )
    List<CpDataSetInfo> getDataSetByIdsApp(@Param(value = "app") String app,@Param(value = "ids") List<Long>ids);
    
    @Select("<script>"+
        "SELECT * FROM cp_dataset_info WHERE 1=1  AND `app` = #{app} " +
        "AND tbname IN  " +
        "   <foreach item='item' index='index' collection='tbnames' open='(' separator=',' close=')'>" +
        "       #{item}" +
        "   </foreach>" +
        "</script>"
    )
    List<CpDataSetInfo> getDataSetBytbnameApp(@Param(value = "app") String app,@Param(value = "tbnames") List<String> tbnames);
}

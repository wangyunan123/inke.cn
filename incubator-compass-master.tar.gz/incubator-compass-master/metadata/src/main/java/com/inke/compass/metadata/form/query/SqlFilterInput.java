package com.inke.compass.metadata.form.query;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * <p> incubator-compass</p>
 * <p> Description :  </p>
 * <p> Author : 24k-xiao-shan </p>
 * <p> Version :  </p>
 * <p> Create Time :  2021-01-19 11:05:29 </p>
 * <p> Author Email: <a href="mailTo:1912079423@qq.com">gaojunshan</a> </p>
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SqlFilterInput
        implements Serializable
{
    private List<ConditionInput> conditions;
    private String relation;
}

package com.inke.compass.metadata.mapper;

import com.inke.compass.metadata.model.CpInputModel;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

public interface CpInputModelMapper
{
    @Select(value = "SELECT DISTINCT\n" +
            "\tcd.`id` AS `id`,\n" +
            "\t`name`,\n" +
            "\t`label`,\n" +
            "\t`create_time`,\n" +
            "\t`active` \n" +
            "FROM\n" +
            "\tcp_input_model AS cd\n" +
            "\tLEFT JOIN cp_cem_relation AS ccr ON cd.id = ccr.module_id\n" +
            "WHERE\n" +
            "\tccr.column_id =  #{columnId}")
    @Results(
            id = "full",
            value = {
                    @Result(property = "id", column = "id", id = true),
                    @Result(property = "name", column = "name"),
                    @Result(property = "label", column = "label"),
                    @Result(property = "express", column = "express"),
                    @Result(property = "active", column = "active"),
                    @Result(property = "createTime", column = "create_time")
            })
    CpInputModel findByColumnId(@Param(value = "columnId") Long columnId);

    @Select(value = "SELECT * FROM cp_input_model WHERE id = #{id}")
    CpInputModel findById(@Param(value = "id") Long id);
}

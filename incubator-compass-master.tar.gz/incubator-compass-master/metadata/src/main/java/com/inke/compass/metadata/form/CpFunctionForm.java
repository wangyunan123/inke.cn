package com.inke.compass.metadata.form;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * <p> @Description : 函数实体 </p>
 * <p> @incubator-compass </p>
 * <p> @Author : <a href="mailTo:mfr1339941169@qq.com">Mfrain</a>  </p>
 * <p> @Create Time : 2021/7/15 2:37 下午 </p>
 * <p> @Version : 1.0 </p>
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class CpFunctionForm
{
    private List<CpFunctionArgs> args;
    private long fcId;
    private String usage;
    private String name;
    private String desc;
}

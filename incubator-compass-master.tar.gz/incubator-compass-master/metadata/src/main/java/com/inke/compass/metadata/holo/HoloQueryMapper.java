package com.inke.compass.metadata.holo;

import io.edurt.gcm.postgresql.hikari.annotation.PostgresSource;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

/**
 * <p> incubator-compass</p>
 * <p> Description :  </p>
 * <p> @Author : 24k-xiao-shan </p>
 * <p> Version :  </p>
 * <p> Create Time :  2021-01-19 11:13:49 </p>
 * <p> Author Email: <a href="mailTo:1912079423@qq.com">gaojunshan</a> </p>
 */
@PostgresSource
public interface HoloQueryMapper
{
    /**
     * 测试用例
     *
     * @Author: Mfrain
     * @Date: 2021/3/9 7:40 下午
     * @return: java.util.List<java.util.Map < java.lang.String, java.lang.String>>
     */
    @Select(value = "SELECT * FROM kafka ")
    List<Map<String, String>> holoFindAll();

    /**
     * hologres通用查询
     * 传入sql即可返回结果
     *
     * @param sql
     * @return
     */
    @Select("<script>" + "${sql}" + "</script>")
    List<Map<String, String>> query(@Param(value = "sql") String sql);
}

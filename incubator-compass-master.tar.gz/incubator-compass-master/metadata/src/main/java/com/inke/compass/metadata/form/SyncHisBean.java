/**
 * Copyright 2021 json.cn
 */
package com.inke.compass.metadata.form;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Auto-generated: 2021-07-08 4:53:40
 *
 * @author json.cn (i@json.cn)
 * @website http://www.json.cn/java2pojo/
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SyncHisBean
{

    private Long allSize;
    private Long ownerSize;
    private List<HisList> hisList;
}
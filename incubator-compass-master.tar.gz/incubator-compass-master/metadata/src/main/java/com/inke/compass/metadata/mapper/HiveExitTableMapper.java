package com.inke.compass.metadata.mapper;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
 * <p> @Description : app信息mapper </p>
 * <p> @incubator-compass </p>
 * <p> @Author : Mfrain </p>
 * <p> @Create Time : 2021/1/5 4:58 下午 </p>
 * <p> @Author Email: <a href="mailTo:mfr1339941169@qq.com">Mfrain</a> </p>
 * <p> @Version : 1.0 </p>
 */
public interface HiveExitTableMapper
{

    @Select(value = "SELECT is_partition FROM hive_exist_table WHERE db_name = #{db_name} and tb_name = #{tb_name}")
    String hiveExitTable(@Param(value = "tb_name") String tb_name,@Param(value = "db_name") String db_name);


}
/**
 * Copyright 2021 json.cn
 */
package com.inke.compass.metadata.form;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Auto-generated: 2021-07-08 4:53:40
 *
 * @author json.cn (i@json.cn)
 * @website http://www.json.cn/java2pojo/
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class HistoryV1
{
    private String name;
    private String status;
    private String owner;
    private String size;
    private String cycel;
    private String updateTime;
}
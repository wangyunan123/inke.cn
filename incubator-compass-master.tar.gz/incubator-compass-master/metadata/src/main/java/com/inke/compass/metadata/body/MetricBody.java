package com.inke.compass.metadata.body;

import com.inke.compass.metadata.info.InputModelInfo;
import com.inke.compass.metadata.info.UnionInfo;
import com.inke.compass.metadata.model.CpMetric;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.List;

@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class MetricBody
{
    private List<CpMetric> conditions;
    private String metricName;
    private Long eventId;
    //    private DataTypeInfo dataType;
//    private List<FilterInfo> filter;
//    private List<ExpressInfo> express;
    private UnionInfo dataType;
    private List<UnionInfo> filter;
    private List<UnionInfo> express;
    private String dict;
    private Long metricId;
    private InputModelInfo inputModel;
    private String table;
}

package com.inke.compass.metadata.databusi;

import com.google.gson.Gson;
import com.google.inject.Inject;
import okhttp3.*;
import org.apache.http.HttpStatus;
import org.apache.http.client.utils.URIBuilder;
import org.apache.parquet.Preconditions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Named;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.security.InvalidParameterException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class DatabusiService {
    private static final Logger LOGGER = LoggerFactory.getLogger(DatabusiService.class);
    // http client
    private final OkHttpClient httpClient;
    @Inject
    @Named(value = "databusi.scheme")
    private String scheme;
    @Inject
    @Named(value = "databusi.host")
    private String host;

    public DatabusiService() {
        this.httpClient = new OkHttpClient()
                .newBuilder()
                .retryOnConnectionFailure(true)
                .connectTimeout(800, TimeUnit.SECONDS)
                .readTimeout(600, TimeUnit.SECONDS)
                .writeTimeout(600, TimeUnit.SECONDS)
                .build();
    }

    // 创建调度任务
    public CreateSchedulerResponse createScheduler(CreateSchedulerRequest request) {
        Request.Builder reqBuild = new Request.Builder();
        okhttp3.RequestBody body = okhttp3.RequestBody
                .create(MediaType.parse("application/json"), request.toJson());
        Request httpRequest = reqBuild
                .url(formatURL(scheme, host, "/admin/internal/scheduler/create", null))
                .post(body)
                .build();
        Call call = this.httpClient.newCall(httpRequest);
        // TODO: add monitoring
        Response response = this.callWithoutException(call);
        String result = this.readJsonBody(response);
        Preconditions.checkArgument(response.code() == HttpStatus.SC_OK, String.format("请求databusi失败, http code: '%d', body: '%s'", response.code(), result));
        CreateSchedulerResponse responseBody = CreateSchedulerResponse.fromJson(result);
        Preconditions.checkArgument(responseBody.getCode() == 0, String.format("请求databusi失败, code: '%d', message: '%s'", responseBody.getCode(), responseBody.getMessage()));
        return responseBody;
    }

    /**
     * 删除调度任务
     *
     * @param schedulerId 调度id
     */
    public void deleteScheduler(long schedulerId) {
        Request.Builder reqBuild = new Request.Builder();
        Map<String, Object> body = new HashMap<>();
        body.put("scheduler_id", schedulerId);
        Request httpRequest = reqBuild
                .url(formatURL(scheme, host,"/admin/internal/scheduler/delete", null))
                .post(this.buildJsonBodyMap(body))
                .build();
        Call call = this.httpClient.newCall(httpRequest);
        // TODO: add monitoring
        Response response = this.callWithoutException(call);
        String result = this.readJsonBody(response);
        Preconditions.checkArgument(response.code() == HttpStatus.SC_OK, String.format("请求databusi失败, http code: '%d', body: '%s'", response.code(), result));
        EmptyDataResponse responseBody = EmptyDataResponse.fromJson(result);
        Preconditions.checkArgument(responseBody.getCode() == 0, String.format("请求databusi失败, code: '%d', message: '%s'", responseBody.getCode(), responseBody.getMessage()));
    }

    /**
     * 重跑调度任务
     *
     * @param schedulerId 调度id
     */
    public void rerunScheduler(long schedulerId, String startDateBatch, String endDateBatch) {
        Request.Builder reqBuild = new Request.Builder();
        Map<String, Object> body = new HashMap<>();
        body.put("scheduler_id", schedulerId);
        body.put("start_date", startDateBatch);
        body.put("end_date", endDateBatch);
        Request httpRequest = reqBuild
                .url(formatURL(scheme, host, "/admin/internal/scheduler/rerun", null))
                .post(this.buildJsonBodyMap(body))
                .build();
        Call call = this.httpClient.newCall(httpRequest);
        // TODO: add monitoring
        Response response = this.callWithoutException(call);
        String result = this.readJsonBody(response);
        Preconditions.checkArgument(response.code() == HttpStatus.SC_OK, String.format("请求databusi失败, http code: '%d', body: '%s'", response.code(), result));
        EmptyDataResponse responseBody = EmptyDataResponse.fromJson(result);
        Preconditions.checkArgument(responseBody.getCode() == 0, String.format("请求databusi失败, code: '%d', message: '%s'", responseBody.getCode(), responseBody.getMessage()));
    }

    private Response callWithoutException(Call call) {
        try {
            Response response = call.execute();
            return response;
        } catch (Exception e) {
            Preconditions.checkArgument(false, String.format("请求databusi失败: exception msg: %s", e.getMessage()));
            return null;
        }
    }

    private String readJsonBody(Response resp) {
        try {
            return resp.body().string();
        } catch (Exception e) {
            Preconditions.checkArgument(false, String.format("请求databusi失败: exception msg: %s", e.getMessage()));
            return null;
        }
    }

    private okhttp3.RequestBody buildJsonBodyMap(Map m) {
        return okhttp3.RequestBody
                .create(MediaType.parse("application/json"), new Gson().toJson(m));
    }

    private URL formatURL(String scheme, String host, String path, Map<String, String> queryParameters)
    {
        try {
            URIBuilder builder = new URIBuilder();
            builder.setScheme(scheme);
            builder.setHost(host);
            builder.setPath(path);
            if (queryParameters != null) {
                queryParameters.forEach((k, v) -> {
                    builder.addParameter(k, v);
                });
            }
            URL url = builder.build().toURL();
            return url;
        }
        catch (URISyntaxException e) {
            Preconditions.checkArgument(false, "构建请求参数失败");
        }
        catch (MalformedURLException e) {
            Preconditions.checkArgument(false, "构建请求参数失败");
        }
        return null;
    }
}

package com.inke.compass.metadata.info;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.List;

@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class MetricInfo
{
    private Long id;
    private String label;
    private String description;
    private String type;
    private List<MetricInfo> children;
}

package com.inke.compass.metadata.body;

import com.inke.compass.metadata.info.DatasetInfo;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.List;

@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class DatasetRealtimeBody
{
    private Long allSize;
    private Long ownerSize;
    List<DatasetInfo> datasets;
}

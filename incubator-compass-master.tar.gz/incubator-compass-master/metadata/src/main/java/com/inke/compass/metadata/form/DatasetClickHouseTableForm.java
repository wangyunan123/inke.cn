package com.inke.compass.metadata.form;

import com.inke.compass.metadata.model.CpDataSetInfo;
import io.edurt.gcm.common.jdk.ObjectBuilder;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DatasetClickHouseTableForm {
    private Long datasetId; // 节点名
    private Long eventId; // 节点名
    private String type; // 节点类型
    private String app; // app名
    private String label;
    private String dbname; // 库名
    private String tbname; // 表名
    private String creator; // 创建人
    private String cycle; // 同步周期
    private Integer syncDay; // 定时同步的天：如果cycle为周：则该值从0（周日）～6（周六）、如果cycle为月：则该值为第n号
    private Integer syncHour; // 定时同步的小时设置
    private Integer syncMinute; // 定时同步的分钟设置
    private Long size;
    private String desc; // 描述
    private String info; // 数据集构建详细信息
    private Long rootdir; // 上级目录id   根目录为0
    private String tabletype; // 表类型   HIVE、CLICKHOUSE、KAFKA
    private Boolean active;
    private Integer dataTableLife; // 数据保留时间
    private Integer dataSetLife; // 数据集保留时间
    private String basicTable;

    static public DatasetClickHouseTableForm fromCpDataSetInfo(CpDataSetInfo datasetInfo) {
        return ObjectBuilder.of(DatasetClickHouseTableForm::new)
                .with(DatasetClickHouseTableForm::setDatasetId, datasetInfo.getId())
                .with(DatasetClickHouseTableForm::setType, datasetInfo.getType())
                .with(DatasetClickHouseTableForm::setApp, datasetInfo.getApp())
                .with(DatasetClickHouseTableForm::setLabel, datasetInfo.getLabel())
                .with(DatasetClickHouseTableForm::setDbname, datasetInfo.getDbname())
                .with(DatasetClickHouseTableForm::setTbname, datasetInfo.getTbname())
                .with(DatasetClickHouseTableForm::setCreator, datasetInfo.getCreator())
                .with(DatasetClickHouseTableForm::setCycle, datasetInfo.getCycle())
                .with(DatasetClickHouseTableForm::setSyncDay, datasetInfo.getSyncDay())
                .with(DatasetClickHouseTableForm::setSyncHour, datasetInfo.getSyncHour())
                .with(DatasetClickHouseTableForm::setSyncMinute, datasetInfo.getSyncMinute())
                .with(DatasetClickHouseTableForm::setSize, datasetInfo.getSize())
                .with(DatasetClickHouseTableForm::setDesc, datasetInfo.getDesc())
                .with(DatasetClickHouseTableForm::setInfo, datasetInfo.getInfo())
                .with(DatasetClickHouseTableForm::setRootdir, datasetInfo.getRootdir())
                .with(DatasetClickHouseTableForm::setTabletype, datasetInfo.getTabletype())
                .with(DatasetClickHouseTableForm::setActive, datasetInfo.getActive())
                .with(DatasetClickHouseTableForm::setDataTableLife, datasetInfo.getDataTableLife())
                .with(DatasetClickHouseTableForm::setDataSetLife, datasetInfo.getDataSetLife())
                .with(DatasetClickHouseTableForm::setBasicTable, datasetInfo.getBasicTable())
                .build();
    }
}

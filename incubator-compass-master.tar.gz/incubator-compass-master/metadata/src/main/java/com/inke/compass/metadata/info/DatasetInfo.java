package com.inke.compass.metadata.info;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class DatasetInfo
{
    private Long id;
    private String cycle;
    private String label;
    private String name;
    private String owner;
    private String size;
    private String status;
    private String type;
    private String createTime;
    private String app;
    private String tbname;
}

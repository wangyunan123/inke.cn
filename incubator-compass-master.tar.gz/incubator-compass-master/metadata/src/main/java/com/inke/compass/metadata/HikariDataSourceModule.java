package com.inke.compass.metadata;

import org.apache.ibatis.transaction.jdbc.JdbcTransactionFactory;
import org.mybatis.guice.MyBatisModule;
import org.mybatis.guice.datasource.helper.JdbcHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HikariDataSourceModule
        extends MyBatisModule
{
    private static final Logger LOGGER = LoggerFactory.getLogger(HikariDataSourceModule.class);

    @Override
    protected void initialize()
    {
        LOGGER.info("初始化MySQL数据源");
        install(JdbcHelper.MySQL);
        bindDataSourceProviderType(HikariDataSourceProvider.class);
        bindTransactionFactoryType(JdbcTransactionFactory.class);
        addMapperClasses("com.inke.compass.metadata.mapper");
    }
}

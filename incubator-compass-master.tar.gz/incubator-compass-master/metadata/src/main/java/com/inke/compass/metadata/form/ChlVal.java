package com.inke.compass.metadata.form;

import lombok.Data;

/**
 * <p> incubator-compass</p>
 * <p> Description :  </p>
 * <p> Author : 24k-xiao-shan </p>
 * <p> Version :  </p>
 * <p> Create Time :  2021-01-18 20:26:21 </p>
 * <p> Author Email: <a href="mailTo:1912079423@qq.com">gaojunshan</a> </p>
 */
@Data
public class ChlVal
{
    private String name;
    private String val;
}

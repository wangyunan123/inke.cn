package com.inke.compass.metadata.mapper;

import com.inke.compass.metadata.model.CpMetadataSyncHistory;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

/**
 * @author mfrain
 */
public interface CpMetadataSyncHistoryMapper
{
    @Insert(value = "<script>" +
            "INSERT INTO cp_metadata_sync_history(<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"mdsh.name != null\">`name`,</if>" +
            "   <if test=\"mdsh.hiveMetadataId != null\">`htid`,</if>" +
            "   <if test=\"mdsh.lastDate != null\">`last_date`,</if>" +
            "   <if test=\"mdsh.createUser != null\">`create_user`,</if>" +
            "   <if test=\"mdsh.status != null\">`status`,</if>" +
            "   <if test=\"mdsh.size != null\">`size`,</if>" +
            "   <if test=\"mdsh.total != null\">`total`,</if>" +
            "   <if test=\"mdsh.syncMode != null\">`sync_mode`,</if>" +
            "   <if test=\"mdsh.tableType != null\">`tableType`,</if>" +
            "   <if test=\"mdsh.cycle != null\">`cycle`,</if>" +
            "   <if test=\"mdsh.tableName != null\">`table_name`,</if>" +
            "   <if test=\"mdsh.dbName != null\">`db_name`,</if>" +
            "</trim>) " +
            "VALUES (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"mdsh.name != null\">#{mdsh.name},</if>" +
            "   <if test=\"mdsh.hiveMetadataId != null\">#{mdsh.hiveMetadataId},</if>" +
            "   <if test=\"mdsh.lastDate != null\">#{mdsh.lastDate},</if>" +
            "   <if test=\"mdsh.createUser != null\">#{mdsh.createUser},</if>" +
            "   <if test=\"mdsh.status != null\">#{mdsh.status},</if>" +
            "   <if test=\"mdsh.size != null\">#{mdsh.size},</if>" +
            "   <if test=\"mdsh.total != null\">#{mdsh.total},</if>" +
            "   <if test=\"mdsh.syncMode != null\">#{mdsh.syncMode},</if>" +
            "   <if test=\"mdsh.tableType != null\">#{mdsh.tableType},</if>" +
            "   <if test=\"mdsh.cycle != null\">#{mdsh.cycle},</if>" +
            "   <if test=\"mdsh.tableName != null\">#{mdsh.tableName},</if>" +
            "   <if test=\"mdsh.dbName != null\">#{mdsh.dbName},</if>" +
            "</trim>)" +
            "</script>")
    @Options(useGeneratedKeys = true, keyProperty = "mdsh.id", keyColumn = "id")
    void save(@Param(value = "mdsh") CpMetadataSyncHistory mdsh);

    @Update(value = "<script>" +
            "UPDATE cp_metadata_sync_history " +
            "<set>" +
            "   <if test=\"mdsh.name != null\">" +
            "       name = #{mdsh.name}," +
            "   </if>" +
            "   <if test=\"mdsh.hiveMetadataId != null\">" +
            "       htid = #{mdsh.hiveMetadataId}," +
            "   </if>" +
            "   <if test=\"mdsh.lastDate != null\">" +
            "       last_date = #{mdsh.lastDate}," +
            "   </if>" +
            "   <if test=\"mdsh.startTime != null\">" +
            "       start_time = #{mdsh.startTime}," +
            "   </if>" +
            "   <if test=\"mdsh.endTime != null\">" +
            "       end_time = #{mdsh.endTime}," +
            "   </if>" +
            "   <if test=\"mdsh.createUser != null\">" +
            "       create_user = #{mdsh.createUser}," +
            "   </if>" +
            "   <if test=\"mdsh.status != null\">" +
            "       status = #{mdsh.status}," +
            "   </if>" +
            "   <if test=\"mdsh.size != null\">" +
            "       size = #{mdsh.size}," +
            "   </if>" +
            "   <if test=\"mdsh.total != null\">" +
            "       total = #{mdsh.total}," +
            "   </if>" +
            "   <if test=\"mdsh.syncMode != null\">" +
            "       sync_mode = #{mdsh.syncMode}," +
            "   </if>" +
            "   <if test=\"mdsh.tableType != null\">" +
            "       tableType = #{mdsh.tableType}," +
            "   </if>" +
            "   <if test=\"mdsh.cycle != null\">" +
            "       cycle = #{mdsh.cycle}," +
            "   </if>" +
            "   <if test=\"mdsh.message != null\">" +
            "       message = #{mdsh.message}," +
            "   </if>" +
            "</set> " +
            "WHERE id = #{mdsh.id}" +
            "</script>")
    void update(@Param(value = "mdsh") CpMetadataSyncHistory mdsh);

    @Select(value = "SELECT * FROM cp_metadata_sync_history ")
    @Results(id = "get_mdsh_all", value = {
            @Result(property = "id", column = "id"),
            @Result(property = "name", column = "name"),
            @Result(property = "hiveMetadataId", column = "htid"),
            @Result(property = "lastDate", column = "last_date"),
            @Result(property = "startTime", column = "start_time"),
            @Result(property = "endTime", column = "end_time"),
            @Result(property = "createUser", column = "create_user"),
            @Result(property = "status", column = "status"),
            @Result(property = "size", column = "size"),
            @Result(property = "total", column = "total"),
            @Result(property = "syncMode", column = "sync_mode"),
            @Result(property = "tableType", column = "tableType"),
            @Result(property = "cycle", column = "cycle"),
    })
    List<CpMetadataSyncHistory> findAll();

    @Select(value = "SELECT distinct name FROM cp_metadata_sync_history ")
    List<String> getNames();

    @Select(value = "SELECT * FROM cp_metadata_sync_history WHERE id = #{id}")
    @Results(id = "get_mdsh_by_id", value = {
            @Result(property = "id", column = "id"),
            @Result(property = "name", column = "name"),
            @Result(property = "hiveMetadataId", column = "htid"),
            @Result(property = "lastDate", column = "last_date"),
            @Result(property = "startTime", column = "start_time"),
            @Result(property = "endTime", column = "end_time"),
            @Result(property = "createUser", column = "create_user"),
            @Result(property = "status", column = "status"),
            @Result(property = "size", column = "size"),
            @Result(property = "total", column = "total"),
            @Result(property = "syncMode", column = "sync_mode"),
            @Result(property = "tableType", column = "tableType"),
            @Result(property = "cycle", column = "cycle"),
    })
    CpMetadataSyncHistory getById(@Param(value = "id") long id);

    @Select(value = "SELECT * FROM cp_metadata_sync_history WHERE name = #{name} and create_user = #{createUser} order by `start_time` desc")
    @Results(id = "get_mdsh_by_name_createUser", value = {
            @Result(property = "id", column = "id"),
            @Result(property = "name", column = "name"),
            @Result(property = "hiveMetadataId", column = "htid"),
            @Result(property = "lastDate", column = "last_date"),
            @Result(property = "startTime", column = "start_time"),
            @Result(property = "endTime", column = "end_time"),
            @Result(property = "createUser", column = "create_user"),
            @Result(property = "status", column = "status"),
            @Result(property = "size", column = "size"),
            @Result(property = "total", column = "total"),
            @Result(property = "syncMode", column = "sync_mode"),
            @Result(property = "tableType", column = "tableType"),
            @Result(property = "cycle", column = "cycle"),
    })
    List<CpMetadataSyncHistory> getOwnerMdsh(@Param(value = "name") String name, @Param(value = "createUser") String createUser);

    @Select(value = "SELECT * FROM cp_metadata_sync_history WHERE htid = #{htid}  order by `start_time` desc")
    @Results(id = "get_mdsh_by_name1", value = {
            @Result(property = "id", column = "id"),
            @Result(property = "name", column = "name"),
            @Result(property = "hiveMetadataId", column = "htid"),
            @Result(property = "lastDate", column = "last_date"),
            @Result(property = "startTime", column = "start_time"),
            @Result(property = "endTime", column = "end_time"),
            @Result(property = "createUser", column = "create_user"),
            @Result(property = "status", column = "status"),
            @Result(property = "size", column = "size"),
            @Result(property = "total", column = "total"),
            @Result(property = "syncMode", column = "sync_mode"),
            @Result(property = "tableType", column = "tableType"),
            @Result(property = "cycle", column = "cycle"),
    })
    List<CpMetadataSyncHistory> getMdsh(@Param(value = "htid") long htid);

    @Select(value = "SELECT sum(size) FROM cp_metadata_sync_history")
    Long getAllSize();

    @Select(value = "SELECT sum(size) FROM cp_metadata_sync_history  where ")
    Long getOwnerSize(@Param(value = "createUser") String createUser);

    @Delete("<script>" +
            "DELETE FROM cp_metadata_sync_history " +
            "WHERE id = #{ds}" +
            "</script>")
    void deleteById(@Param(value = "ds") long ds);
}

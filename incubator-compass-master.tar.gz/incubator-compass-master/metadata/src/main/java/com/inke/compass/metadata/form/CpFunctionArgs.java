package com.inke.compass.metadata.form;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <p> @Description :  </p>
 * <p> @incubator-compass </p>
 * <p> @Author : <a href="mailTo:mfr1339941169@qq.com">Mfrain</a>  </p>
 * <p> @Create Time : 2021/7/15 2:38 下午 </p>
 * <p> @Version : 1.0 </p>
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class CpFunctionArgs
{
    private String name;
    private String type;
}

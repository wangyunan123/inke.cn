package com.inke.compass.metadata.form.query;

import com.inke.compass.metadata.enums.Mode;
import com.inke.compass.sqlbuilder.model.OrderInput;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * <p> incubator-compass</p>
 * <p> Description :  </p>
 * <p> @Author : 24k-xiao-shan </p>
 * <p> Version :  </p>
 * <p> Create Time :  2021-01-19 10:45:15 </p>
 * <p> Author Email: <a href="mailTo:1912079423@qq.com">gaojunshan</a> </p>
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SqlBuilderInput
{
    private String dataSource;
    private TimeSlotInput time;
    private List<ActionInput> actions;
    private AffiliateInput affiliate;
    private Mode mode;
    private DeveloperBuilderInput developer;
    private String unit;
    private List<OrderInput> orders;
    private Integer top;
    private Integer limit;
    private String type = "metric"; // 是否明细表
    private String queryType = "";
    private Boolean showLabel = false;
}

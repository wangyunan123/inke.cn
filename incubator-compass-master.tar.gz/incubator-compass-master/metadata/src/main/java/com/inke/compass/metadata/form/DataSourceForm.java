package com.inke.compass.metadata.form;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * <p> @Description : 构建数据源参数  </p>
 * <p> @incubator-compass </p>
 * <p> @Author : <a href="mailTo:mfr1339941169@qq.com">Mfrain</a>  </p>
 * <p> @Create Time : 2021/4/23 2:29 下午 </p>
 * <p> @Version : 1.0 </p>
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DataSourceForm
        implements Serializable
{
    private static final long serialVersionUID = -2934437950547812152L;
    private Long appId;
    private String querySql;
    private Long saveDirId;
    private List<ColumnForm> metrics;
    private List<ColumnForm> dimensions;
    private String operator;
    private String eventInfo;
    private Long metricDirId;
    private String cacheData;
}


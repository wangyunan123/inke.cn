package com.inke.compass.metadata.mapper;

import com.inke.compass.metadata.model.CpColumn;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;
import java.util.Map;

/**
 * <p> incubator-compass</p>
 * <p> @Description : 指标mapper类 </p>
 * <p> @Author : 24k-xiao-shan </p>
 * <p> @Version : 1.0 </p>
 * <p> @Create Time :  2021-01-05 10:19:33 </p>
 * <p> @Author Email: <a href="mailTo:1912079423@qq.com">gaojunshan</a> </p>
 */
public interface CpColumnMapper
{
    @Insert(value = "<script>" +
            "INSERT INTO cp_column (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"model.name != null\" >name,</if>" +
            "   <if test=\"model.column != null\" >`column`,</if>" +
            "   <if test=\"model.label != null\" >`label`,</if>" +
            "   <if test=\"model.description != null\" >`description`,</if>" +
            "   <if test=\"model.visible != null\" >`visible`,</if>" +
            "   <if test=\"model.defaulted != null\" >`defaulted`,</if>" +
            "   <if test=\"model.deleted != null\" >`deleted`,</if>" +
            "   <if test=\"model.type != null\" >`type`,</if>" +
            "   <if test=\"model.inputModelId != null\" >`input_model_id`,</if>" +
            "   <if test=\"model.tables != null\" >`tables`,</if>" +
            "   <if test=\"model.dict != null\" >`dict`,</if>" +
            "   <if test=\"model.condition != null\" >`condition`,</if>" +
            "   <if test=\"model.originColumn != null\" >`origin_column`,</if>" +
            "   <if test=\"model.partition != null\" >`partition`,</if>" +
            "</trim>) " +
            "VALUES (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"model.name != null\" >#{model.name},</if>" +
            "   <if test=\"model.column != null\" >#{model.column},</if>" +
            "   <if test=\"model.label != null\" >#{model.label},</if>" +
            "   <if test=\"model.description != null\" >#{model.description},</if>" +
            "   <if test=\"model.visible != null\" >#{model.visible},</if>" +
            "   <if test=\"model.defaulted != null\" >#{model.defaulted},</if>" +
            "   <if test=\"model.deleted != null\" >#{model.deleted},</if>" +
            "   <if test=\"model.type != null\" >#{model.type},</if>" +
            "   <if test=\"model.inputModelId != null\" >#{model.inputModelId},</if>" +
            "   <if test=\"model.tables != null\" >#{model.tables},</if>" +
            "   <if test=\"model.dict != null\" >#{model.dict},</if>" +
            "   <if test=\"model.condition != null\" >#{model.condition},</if>" +
            "   <if test=\"model.originColumn != null\" >#{model.originColumn},</if>" +
            "   <if test=\"model.partition != null\" >#{model.partition},</if>" +
            "</trim>)" +
            "</script>")
    @Options(useGeneratedKeys = true, keyProperty = "model.id", keyColumn = "id")
    void save(@Param(value = "model") CpColumn model);

    @Update("<script>" +
            "update cp_column" +
            "    <set >" +
            "      <if test=\"model.name != null\" >" +
            "        name = #{model.name},    " +
            "      </if>" +
            "      <if test=\"model.column != null\" >" +
            "        `column` = #{model.column}," +
            "      </if>" +
            "      <if test=\"model.label != null\" >" +
            "        label = #{model.label},    " +
            "      </if>" +
            "      <if test=\"model.description != null\" >" +
            "        description = #{model.description}," +
            "      </if>" +
            "      <if test=\"model.visible != null\" >" +
            "        visible = #{model.visible}," +
            "      </if>" +
            "      <if test=\"model.defaulted != null\" >" +
            "        defaulted = #{model.defaulted}," +
            "      </if>" +
            "      <if test=\"model.deleted != null\" >" +
            "        deleted = #{model.deleted}," +
            "      </if>" +
            "      <if test=\"model.tables != null\" >" +
            "        tables = #{model.tables}," +
            "      </if>" +
            "      <if test=\"model.dict != null\" >" +
            "        dict = #{model.dict}," +
            "      </if>" +
            "      <if test=\"model.condition != null\" >" +
            "        condition = #{model.condition}," +
            "      </if>" +
            "      <if test=\"model.partition != null\" >" +
            "        `partition` = #{model.partition}," +
            "      </if>" +
            "      <if test=\"model.originColumn != null\" >" +
            "        origin_column = #{model.originColumn}," +
            "      </if>" +
            "    </set>" +
            "    where id = #{model.id}" +
            "</script>")
    void update(@Param(value = "model") CpColumn model);

    @Select(value = "SELECT * FROM cp_column ")
    @Results(id = "cp_column_all", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "name", column = "name"),
            @Result(property = "column", column = "column"),
            @Result(property = "label", column = "label"),
            @Result(property = "description", column = "description"),
            @Result(property = "visible", column = "visible"),
            @Result(property = "defaulted", column = "defaulted"),
            @Result(property = "partition", column = "partition"),
            @Result(property = "deleted", column = "deleted"),
            @Result(property = "tables", column = "tables"),
            @Result(property = "dict", column = "dict"),
            @Result(property = "condition", column = "condition")
    })
    List<CpColumn> findAll();

    @Select(
            value =
                    "<script>"
                            + "select * "
                            + "FROM cp_column "
                            + "WHERE 1 = 1 "
                            + "<if test=\"model.id != null\" >"
                            + " and id = #{model.id}"
                            + "</if>"
                            + "<if test=\"model.name != null\" > "
                            + " or name = #{model.name}"
                            + "</if>"
                            + "<if test=\"model.column != null\" > "
                            + " or `column` = #{model.column}"
                            + "</if>"
                            + "<if test=\"model.label != null\" > "
                            + " or label = #{model.label}"
                            + "</if>"
                            + "<if test=\"model.type != null\" > "
                            + " or type = #{model.type}"
                            + "</if>"
                            + "<if test=\"model.content != null\" > "
                            + " or content = #{model.content}"
                            + "</if>"
                            + "<if test=\"model.inputModelId != null\" > "
                            + " or input_model_id = #{model.inputModelId}"
                            + "</if>"
                            + "<if test=\"model.tables != null\" > "
                            + " or tables = #{model.tables}"
                            + "</if>"
                            + "<if test=\"model.dict != null\" > "
                            + " or dict = #{model.dict}"
                            + "</if>"
                            + "<if test=\"model.condition != null\" > "
                            + " or condition = #{model.condition}"
                            + "</if>"
                            + "</script>")
    @Results(
            id = "cp_column_get",
            value = {
                    @Result(property = "id", column = "id", id = true),
                    @Result(property = "name", column = "name"),
                    @Result(property = "column", column = "column"),
                    @Result(property = "label", column = "label"),
                    @Result(property = "description", column = "description"),
                    @Result(property = "visible", column = "visible"),
                    @Result(property = "defaulted", column = "defaulted"),
                    @Result(property = "deleted", column = "deleted"),
                    @Result(property = "type", column = "type"),
                    @Result(property = "content", column = "content"),
                    @Result(property = "inputModelId", column = "input_model_id"),
                    @Result(property = "tables", column = "tables"),
                    @Result(property = "dict", column = "dict"),
                    @Result(property = "condition", column = "condition")
            })
    List<CpColumn> get(@Param(value = "model") CpColumn model);

    @Select(value = "SELECT * FROM cp_column WHERE tables = #{tableName} ")
    @ResultMap(value = "cp_column_get")
    List<CpColumn> findByTableName(@Param(value = "tableName") String tableName);

    @Select(value = "SELECT id,`column`,`name`,label,description,visible,defaulted,partition,deleted,create_time,input_model_id,type,content,filter,`tables`,dict,`condition` FROM cp_column WHERE TABLES=#{tableName} AND `column` NOT LIKE '%,%' GROUP BY `column`")
    @ResultMap(value = "cp_column_get")
    List<CpColumn> findByTableNameDistinct(@Param(value = "tableName") String tableName);

    @Select(value = "select * FROM cp_column WHERE id = #{id}")
    @ResultMap(value = "cp_column_get")
    CpColumn findById(@Param(value = "id") Long id);

    @Delete("<script>" +
            "delete from cp_column " +
            " where id = #{model.id}" +
            "</script>")
    void delete(@Param(value = "model") CpColumn model);

    /**
     * deleteByTableName
     *
     * @param table:
     * @Author: Mfrain
     * @Date: 2021/4/28 2:05 上午
     * @return: void
     */
    @Delete("<script>" +
            "delete from cp_column " +
            " where tables = #{table}" +
            "</script>")
    void deleteByTableName(@Param(value = "table") String table);

    @Select("<script>" +
            "select distinct CONCAT(`tables`, '-', `column`, '-', `id`) as `column`, label from cp_column " +
            "</script>")
    List<Map<String, String>> allColumns();

    /**
     * <font color="yellow">获取表下所有指标</font>
     *
     * @param tableName
     * @Author: Mfrain
     * @Date: 2021/5/13 2:51 下午
     * @return: java.util.List<com.inke.compass.metadata.model.CpColumn>
     */
    @Select(value = "SELECT * FROM cp_column  where type = 'metric' and tables = #{tableName}")
    @Results(
            id = "cp_column_get_metric_tables",
            value = {
                    @Result(property = "id", column = "id", id = true),
                    @Result(property = "name", column = "name"),
                    @Result(property = "column", column = "column"),
                    @Result(property = "label", column = "label"),
                    @Result(property = "description", column = "description"),
                    @Result(property = "visible", column = "visible"),
                    @Result(property = "defaulted", column = "defaulted"),
                    @Result(property = "deleted", column = "deleted"),
                    @Result(property = "partition", column = "partition"),
                    @Result(property = "type", column = "type"),
                    @Result(property = "content", column = "content"),
                    @Result(property = "inputModelId", column = "input_model_id"),
                    @Result(property = "tables", column = "tables"),
                    @Result(property = "dict", column = "dict"),
                    @Result(property = "condition", column = "condition")
            })
    List<CpColumn> getMetricInTable(@Param(value = "tableName") String tableName);

    @Select(value = "SELECT DISTINCT\n" +
            "\tcc.`id` AS id,\n" +
            "\tcc.`name` AS `name`,\n" +
            "\t`column`,\n" +
            "\tcc.`label` AS `label`,\n" +
            "\tcc.`description` AS `description`,\n" +
            "\tcc.`visible` AS `visible`,\n" +
            "\tcc.`defaulted` AS `defaulted`,\n" +
            "\tcc.`deleted` AS `deleted`,\n" +
            "\tcc.`partition` AS `partition`,\n" +
            "\t`create_time`,\n" +
            "\t`input_model_id`,\n" +
            "\tcc.`type` AS `type`,\n" +
            "\t`content`,\n" +
            "\t`filter`,\n" +
            "\t`tables`,\n" +
            "\t`dict`,\n" +
            "\tcc.`condition` AS `condition` \n" +
            "FROM\n" +
            "\tcp_column AS cc\n" +
            "\tLEFT JOIN cp_cem_relation AS ccr ON cc.id = ccr.column_id\n" +
            "\tLEFT JOIN cp_event AS ce ON ce.id = ccr.event_id \n" +
            "WHERE\n" +
            "\tevent_id = #{eventId}")
    @ResultMap(value = "cp_column_get_metric_tables")
    List<CpColumn> findByEventId(@Param(value = "eventId") Long eventId);
}

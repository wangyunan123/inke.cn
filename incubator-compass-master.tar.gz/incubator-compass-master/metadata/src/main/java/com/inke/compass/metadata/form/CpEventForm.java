package com.inke.compass.metadata.form;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * <p> @Description : 事件接口传入对象 </p>
 * <p> @incubator-compass </p>
 * <p> @Author : <a href="mailTo:mfr1339941169@qq.com">Mfrain</a>  </p>
 * <p> @Create Time : 2021/1/17 2:03 上午 </p>
 * <p> @Version : 1.0 </p>
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CpEventForm
        implements Serializable
{
    private static final long serialVersionUID = -9168522638113307265L;
    private long id;
    private String name;
    private String label;
    private String description;
    private String type;
    private Long appId;
    private Boolean editor;
    private Boolean visible;
    private Boolean defaulted;
    private Boolean deleted;
    private String prefix;
    private Long moduleId;
}

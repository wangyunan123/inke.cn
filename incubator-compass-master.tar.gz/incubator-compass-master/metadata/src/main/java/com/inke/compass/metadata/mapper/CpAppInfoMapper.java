package com.inke.compass.metadata.mapper;

import com.inke.compass.metadata.model.CpAppInfo;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

/**
 * <p> @Description : app信息mapper </p>
 * <p> @incubator-compass </p>
 * <p> @Author : Mfrain </p>
 * <p> @Create Time : 2021/1/5 4:58 下午 </p>
 * <p> @Author Email: <a href="mailTo:mfr1339941169@qq.com">Mfrain</a> </p>
 * <p> @Version : 1.0 </p>
 */
public interface CpAppInfoMapper
{
    /**
     * save
     *
     * @param app:
     * @Author: Mfrain
     * @Date: 2021/1/6 2:47 下午
     * @return: void
     */
    @Insert(value = "<script>" +
            "INSERT INTO cp_app_info (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"app.appKey != null\" >`appkey`,</if>" +
            "   <if test=\"app.appName != null\" >`appname`,</if>" +
            "   <if test=\"app.visible != null\" >`visible`,</if>" +
            "   <if test=\"app.module != null\" >`module`,</if>" +
            "   <if test=\"app.server != null\" >`server`,</if>" +
            "   <if test=\"app.location != null\" >`location`,</if>" +
            "   <if test=\"app.type != null\" >`type`,</if>" +
            "</trim>) " +
            "VALUES (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"app.appKey != null\" >#{app.appKey},</if>" +
            "   <if test=\"app.appName != null\" >#{app.appName},</if>" +
            "   <if test=\"app.visible != null\" >#{app.visible},</if>" +
            "   <if test=\"app.module != null\" >#{app.module},</if>" +
            "   <if test=\"app.server != null\" >#{app.server},</if>" +
            "   <if test=\"app.location != null\" >#{app.location},</if>" +
            "   <if test=\"app.type != null\" >#{app.type},</if>" +
            "</trim>)" +
            "</script>")
    @Options(useGeneratedKeys = true, keyProperty = "app.id", keyColumn = "id")
    void save(@Param(value = "app") CpAppInfo app);

    /**
     * update
     *
     * @param app:
     * @Author: Mfrain
     * @Date: 2021/1/6 2:47 下午
     * @return: void
     */
    @Update("<script>" +
            "update cp_app_info" +
            "    <set >" +
            "      <if test=\"app.appKey != null\" >" +
            "        appkey = #{app.appKey},    " +
            "      </if>" +
            "      <if test=\"app.appName != null\" >" +
            "        appname = #{app.appName}," +
            "      </if>" +
            "      <if test=\"app.visible != null\" >" +
            "        visible = #{app.visible}," +
            "      </if>" +
            "    </set>" +
            "    where id = #{app.id}" +
            "</script>")
    void update(@Param(value = "app") CpAppInfo app);

    /**
     * findAll
     *
     * @Author: Mfrain
     * @Date: 2021/1/6 2:47 下午
     * @return: java.util.List<com.inke.compass.metadata.model.EventInfo>
     */
    @Select(value = "SELECT * FROM cp_app_info ")
    @Results(id = "cp_app_info_all", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "appKey", column = "appkey"),
            @Result(property = "appName", column = "appname"),
            @Result(property = "visible", column = "visible"),
            @Result(property = "module", column = "module"),
            @Result(property = "server", column = "server"),
            @Result(property = "location", column = "location"),
            @Result(property = "type", column = "type")
    })
    List<CpAppInfo> findAll();

    /**
     * 获取 App信息
     *
     * @param appkey:
     * @Author: Mfrain
     * @Date: 2021/4/7 3:04 下午
     * @return: com.inke.compass.metadata.model.CpAppInfo
     */
    @Select(value = "SELECT * FROM cp_app_info  where appkey = #{appkey}")
    @Results(id = "cp_app_info_all_1", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "appKey", column = "appkey"),
            @Result(property = "appName", column = "appname"),
            @Result(property = "visible", column = "visible"),
            @Result(property = "module", column = "module"),
            @Result(property = "server", column = "server"),
            @Result(property = "location", column = "location"),
            @Result(property = "type", column = "type")
    })
    CpAppInfo getAppInfo(@Param(value = "appkey") String appkey);

    /**
     * <font color="yellow">AppInfo</font>
     *
     * @param id
     * @Author: Mfrain
     * @Date: 2021/4/26 3:03 下午
     * @return: com.inke.compass.metadata.model.CpAppInfo
     */
    @Select(value = "SELECT * FROM cp_app_info  where id = #{id}")
    @Results(id = "cp_app_info_all_2", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "appKey", column = "appkey"),
            @Result(property = "appName", column = "appname"),
            @Result(property = "visible", column = "visible"),
            @Result(property = "module", column = "module"),
            @Result(property = "server", column = "server"),
            @Result(property = "location", column = "location"),
            @Result(property = "type", column = "type")
    })
    CpAppInfo getAppInfoById(@Param(value = "id") Long id);

    @Select(value = "SELECT * FROM cp_app_info WHERE appkey = #{appKey}")
    @ResultMap(value = "cp_app_info_all_2")
    CpAppInfo getAppInfoByAppKey(@Param(value = "appKey") String appKey);

    /**
     * <font color="yellow">查询是否存在</font>
     *
     * @param appKey appKey
     * @Author: Mfrain
     * @Date: 2021/6/3 10:56 上午
     * @return: int
     */
    @Select(value = "SELECT count(1) FROM cp_app_info  where appKey = #{appKey}")
    int existAppByKey(@Param(value = "appKey") String appKey);

    /**
     * <font color="yellow">获取对应type的app</font>
     *
     * @param type APP/MODEL
     * @Author: Mfrain
     * @Date: 2021/5/18 3:37 下午
     * @return: java.util.List<com.inke.compass.metadata.model.CpAppInfo>
     */
    @Select(value = "SELECT * FROM cp_app_info  where type = #{type}")
    @Results(id = "cp_app_info_all_3", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "appKey", column = "appkey"),
            @Result(property = "appName", column = "appname"),
            @Result(property = "visible", column = "visible"),
            @Result(property = "module", column = "module"),
            @Result(property = "server", column = "server"),
            @Result(property = "location", column = "location"),
            @Result(property = "type", column = "type")
    })
    List<CpAppInfo> getAppInfoByType(@Param(value = "type") String type);
}

/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.inke.compass.metadata.clickhouse;

import com.inke.compass.metadata.model.MetricDisk;
import io.edurt.gcm.clickhouse.annotation.ClickHouseSource;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

/**
 * @author mfrain
 */
@ClickHouseSource
public interface ClickHouseMapper
{
    /**
     * <font size=5 color="yellow">clickhouse开发者模式</font>
     *
     * @param sql sql
     * @Author: Mfrain
     * @Date: 2021/4/26 9:12 下午
     * @return: java.util.List<java.util.Map < java.lang.String, java.lang.String>>
     */
    @Select("<script>" + "${sql}" + "</script>")
    List<Map<String, String>> query(@Param(value = "sql") String sql);

    MetricDisk findSize(@Param(value = "database") String database,
            @Param(value = "table") String table,
            @Param(value = "partition") String parFtition);
}

package com.inke.compass.metadata.config;

public class ConfigurationDefault
{
    /**
     * 服务端口
     */
    public static final Integer SERVER_PORT = 8080;

    private ConfigurationDefault()
    {}
}

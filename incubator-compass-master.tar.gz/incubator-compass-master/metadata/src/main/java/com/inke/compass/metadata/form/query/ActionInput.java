package com.inke.compass.metadata.form.query;

import com.inke.compass.metadata.model.vo.CpEventVo;
import com.inke.compass.sqlbuilder.common.SqlJoin;
import com.inke.compass.sqlbuilder.model.Condition;
import com.inke.compass.sqlbuilder.model.OrderInput;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * <p> incubator-compass</p>
 * <p> Description :  </p>
 * <p> Author : 24k-xiao-shan </p>
 * <p> Version :  </p>
 * <p> Create Time :  2021-01-19 10:46:19 </p>
 * <p> Author Email: <a href="mailTo:1912079423@qq.com">gaojunshan</a> </p>
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ActionInput
{
    private String table;
    private String operation;
    private List<String> metric;
    private String relation;
    private List<Condition> conditions;
    private OrderInput order;
    private Integer top;
    /**
     * 数据预览所用字段
     * event 使用list保证顺序
     */
    private List<CpEventVo> event;
    private SqlJoin sqlJoin;

}

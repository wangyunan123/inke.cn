package com.inke.compass.metadata.form.query;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * <p> @Description : 数据集构建参数 </p>
 * <p> @incubator-compass </p>
 * <p> @Author : <a href="mailTo:mfr1339941169@qq.com">Mfrain</a>  </p>
 * <p> @Create Time : 2021/7/1 2:44 下午 </p>
 * <p> @Version : 1.0 </p>
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DataSetSqlBuilderInput
{
    private String appKey;
    private List<ActionInput> actions;
    private AffiliateInput affiliate;
    /**
     * 空闲时同步   FreeSync
     * 定时同步    TimerSync
     * 一次性同步  FinalSync
     * 暂停同步   StopSync
     */
    private String syncType;
    private String cycle;
    // 定时同步的天：如果cycle为周：则该值从0（周日）～6（周六）、如果cycle为月：则该值为第n号
    private Integer syncDay;
    // 定时同步的小时设置：6
    private Integer syncHour;
    // 定时同步的分钟设置：59
    private Integer syncMinute;
    private List<ColumnInfo> columns;
    private Long dirId;
    private String desc;
    private String type;
    private Long kafkaLinkId;
    private String topic;
    private String name;
    private String extraInfo;
    private Long dataSetId;
    private String creator;
    private List<Long> hiveTableId;
    private String query;
    private List<String> partitions;
    private Integer dataSourceLife;
    private Integer dataTableLife; // 保留周期
    //增加数据同步策略后的补数操作
    private Boolean isPartFillData;
    private String partSyncStartTime;
    private String partSyncEndTime;
    private Boolean replenish = false;
    private String userName;
    //是否是非分区表
    private Boolean isNonPartitioned;


}

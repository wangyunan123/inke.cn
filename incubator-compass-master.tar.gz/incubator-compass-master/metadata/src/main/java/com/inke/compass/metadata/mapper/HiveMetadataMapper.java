package com.inke.compass.metadata.mapper;

import com.inke.compass.metadata.model.CpHiveMetadata;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

/**
 * <p> @Description : hive 元数据  mappNameer </p>
 * <p> @incubator-compass </p>
 * <p> @Author : Mfrain </p>
 * <p> @Create Time : 2021/7/15 4:52 下午 </p>
 * <p> @Author Email: <a href="mailTo:mfr1339941169@qq.com">Mfrain</a> </p>
 * <p> @Version : 1.0 </p>
 */

public interface HiveMetadataMapper {

    /**
     * <font color="yellow">save</font>
     *
     * @param hiveMetadata hiveMetadata
     * @Author: Mfrain
     * @Date: 2021/7/15 5:00 下午
     * @return: void
     */
    @Insert(value = "<script>" +
            "INSERT INTO cp_hive_metadata (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"hm.id != null\" >`id`,</if>" +
            "   <if test=\"hm.appName != null\" >`appName`,</if>" +
            "   <if test=\"hm.dbName != null\" >`dbName`,</if>" +
            "   <if test=\"hm.tbName != null\" >`tbName`,</if>" +
            "   <if test=\"hm.DatasetId != null\" >`DatasetId`,</if>" +
            "   <if test=\"hm.location != null\" >`location`,</if>" +
            "   <if test=\"hm.formatType != null\" >`formatType`,</if>" +
            "   <if test=\"hm.partition != null\" >`partition`,</if>" +
            "   <if test=\"hm.cycle != null\" >`cycle`,</if>" +
            "   <if test=\"hm.syncDay != null\" >`sync_day`,</if>" +
            "   <if test=\"hm.syncHour != null\" >`sync_hour`,</if>" +
            "   <if test=\"hm.syncMinute != null\" >`sync_minute`,</if>" +
            "   <if test=\"hm.active != null\" >`active`,</if>" +
            "   <if test=\"hm.isImport != null\" >`isImport`,</if>" +
            "</trim>) " +
            "VALUES (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"hm.id != null\" >#{hm.id},</if>" +
            "   <if test=\"hm.appName != null\" >#{hm.appName},</if>" +
            "   <if test=\"hm.dbName != null\" >#{hm.dbName},</if>" +
            "   <if test=\"hm.tbName != null\" >#{hm.tbName},</if>" +
            "   <if test=\"hm.DatasetId != null\" >#{hm.DatasetId},</if>" +
            "   <if test=\"hm.location != null\" >#{hm.location},</if>" +
            "   <if test=\"hm.formatType != null\" >#{hm.formatType},</if>" +
            "   <if test=\"hm.partition != null\" >#{hm.partition},</if>" +
//            "   <if test=\"hm.complementStartDay != null\" >#{hm.complementStartDay},</if>" +
//            "   <if test=\"hm.complementEndDay != null\" >#{hm.complementEndDay},</if>" +
            "   <if test=\"hm.cycle != null\" >#{hm.cycle},</if>" +
            "   <if test=\"hm.syncDay != null\" >#{hm.syncDay},</if>" +
            "   <if test=\"hm.syncHour != null\" >#{hm.syncHour},</if>" +
            "   <if test=\"hm.syncMinute != null\" >#{hm.syncMinute},</if>" +
            "   <if test=\"hm.active != null\" >#{hm.active},</if>" +
            "   <if test=\"hm.isImport != null\" >#{hm.isImport},</if>" +
            "</trim>)" +
            "</script>")
    @Options(useGeneratedKeys = true, keyProperty = "hm.id", keyColumn = "id")
    void save(@Param(value = "hm") CpHiveMetadata hiveMetadata);

    /**
     * <font color="yellow">update</font>
     *
     * @param hiveMetadata hiveMetadata
     * @Author: Mfrain
     * @Date: 2021/7/15 5:04 下午
     * @return: void
     */
    @Update("<script>" +
            "update cp_hive_metadata" +
            "    <set >" +
            "      <if test=\"hm.id != null\" >" +
            "        id = #{hm.id},    " +
            "      </if>" +
            "      <if test=\"hm.appName != null\" >" +
            "        appName = #{hm.appName}," +
            "      </if>" +
            "      <if test=\"hm.dbName != null\" >" +
            "        dbName = #{hm.dbName},    " +
            "      </if>" +
            "      <if test=\"hm.tbName != null\" >" +
            "        tbName = #{hm.tbName}," +
            "      </if>" +
            "      <if test=\"hm.DatasetId != null\" >" +
            "        DatasetId = #{hm.DatasetId}," +
            "      </if>" +
            "      <if test=\"hm.location != null\" >" +
            "        location = #{hm.location}," +
            "      </if>" +
            "      <if test=\"hm.formatType != null\" >" +
            "        formatType = #{hm.formatType}," +
            "      </if>" +
            "      <if test=\"hm.partition != null\" >" +
            "        partition = #{hm.partition}," +
            "      </if>" +
//            "      <if test=\"hm.complementStartDay != null\" >" +
//            "        complementStartDay = #{hm.complementStartDay}," +
//            "      </if>" +
//            "      <if test=\"hm.complementEndDay != null\" >" +
//            "        complementEndDay = #{hm.complementEndDay}," +
//            "      </if>" +
            "      <if test=\"hm.cycle != null\" >" +
            "        cycle = #{hm.cycle}," +
            "      </if>" +
            "      <if test=\"hm.syncDay != null\" >" +
            "        sync_day = #{hm.syncDay}," +
            "      </if>" +
            "      <if test=\"hm.syncHour != null\" >" +
            "        sync_hour = #{hm.syncHour}," +
            "      </if>" +
            "      <if test=\"hm.syncMinute != null\" >" +
            "        sync_minute = #{hm.syncMinute}," +
            "      </if>" +
            "      <if test=\"hm.active != null\" >" +
            "        active = #{hm.active}," +
            "      </if>" +
            "      <if test=\"hm.isImport != null\" >" +
            "        isImport = #{hm.isImport}," +
            "      </if>" +
            "    </set>" +
            "    where id = #{hm.id}" +
            "</script>")
    void update(@Param(value = "hm") CpHiveMetadata hiveMetadata);

    /**
     * <font color="yellow">设置同步周期</font>
     *
     * @param id
     * @param cycle
     * @Author: Mfrain
     * @Date: 2021/7/21 11:55 上午
     * @return: void
     */
    @Update("update cp_hive_metadata set cycle = #{cycle} where id = #{id}")
    void setCycle(@Param(value = "id") long id, @Param(value = "cycle") String cycle);

    /**
     * <font color="yellow">findall</font>
     *
     * @Author: Mfrain
     * @Date: 2021/7/15 5:04 下午
     * @return: java.util.List<com.inke.compass.metadata.model.CpHiveMetadata>
     */
    @Select(value = "SELECT * FROM cp_hive_metadata ")
    @Results(id = "cp_hive_metadata_all", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "appName", column = "appName"),
            @Result(property = "dbName", column = "dbName"),
            @Result(property = "tbName", column = "tbName"),
            @Result(property = "DatasetId ", column = "DatasetId "),
            @Result(property = "location", column = "location"),
            @Result(property = "formatType", column = "formatType"),
            @Result(property = "partition", column = "partition"),
//            @Result(property = "complementStartDay", column = "complementStartDay"),
//            @Result(property = "complementEndDay", column = "complementEndDay"),
            @Result(property = "cycle", column = "cycle"),
            @Result(property = "syncDay", column = "sync_day"),
            @Result(property = "syncHour", column = "sync_hour"),
            @Result(property = "syncMinute", column = "sync_minute"),
            @Result(property = "active", column = "active"),
            @Result(property = "isImport", column = "isImport"),

    })
    List<CpHiveMetadata> findAll();

    /**
     * <font color="yellow"></font>
     *
     * @param
     * @Author: Mfrain
     * @Date: 2021/7/23 4:09 下午
     * @return: java.util.List<com.inke.compass.metadata.model.CpHiveMetadata>
     */
    @Select(value = "SELECT * FROM cp_hive_metadata where  active = 1")
    @Results(id = "cp_hive_metadata_all_active", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "appName", column = "appName"),
            @Result(property = "dbName", column = "dbName"),
            @Result(property = "tbName", column = "tbName"),
            @Result(property = "DatasetId", column = "DatasetId"),
            @Result(property = "location", column = "location"),
            @Result(property = "formatType", column = "formatType"),
            @Result(property = "partition", column = "partition"),
//            @Result(property = "complementStartDay", column = "complementStartDay"),
//            @Result(property = "complementEndDay", column = "complementEndDay"),
            @Result(property = "cycle", column = "cycle"),
            @Result(property = "syncDay", column = "sync_day"),
            @Result(property = "syncHour", column = "sync_hour"),
            @Result(property = "syncMinute", column = "sync_minute"),
            @Result(property = "active", column = "active"),
            @Result(property = "isImport", column = "isImport"),

    })
    List<CpHiveMetadata> findActive();

    /**
     * <font color="yellow">获取appName下所有表</font>
     *
     * @param appName appName
     * @Author: Mfrain
     * @Date: 2021/7/15 5:14 下午
     * @return: java.util.List<com.inke.compass.metadata.model.CpHiveMetadata>
     */
    @Select(value = "SELECT * FROM cp_hive_metadata where appName = #{appName} ")
    @Results(id = "cp_hive_metadata_all_app", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "appName", column = "appName"),
            @Result(property = "dbName", column = "dbName"),
            @Result(property = "tbName", column = "tbName"),
            @Result(property = "DatasetId", column = "DatasetId"),
            @Result(property = "location", column = "location"),
            @Result(property = "formatType", column = "formatType"),
            @Result(property = "partition", column = "partition"),
//            @Result(property = "complementStartDay", column = "complementStartDay"),
//            @Result(property = "complementEndDay", column = "complementEndDay"),
            @Result(property = "cycle", column = "cycle"),
            @Result(property = "syncDay", column = "sync_day"),
            @Result(property = "syncHour", column = "sync_hour"),
            @Result(property = "syncMinute", column = "sync_minute"),
            @Result(property = "active", column = "active"),
            @Result(property = "isImport", column = "isImport"),

    })
    List<CpHiveMetadata> findAllByApp(@Param(value = "appName") String appName);


    @Select(value = "SELECT * FROM cp_hive_metadata where appName = #{appName} " +
            "AND isImport = 1")
    @ResultMap(value = "cp_hive_metadata_all_app")
    List<CpHiveMetadata> findAllByAppAndImport(@Param(value = "appName") String appName);

    @Select(value = "SELECT * FROM cp_hive_metadata where tbName = #{tableName} ")
    @ResultMap(value = "cp_hive_metadata_by_id")
    CpHiveMetadata findByTableName(@Param(value = "tableName") String tableName);

    @Select(value = "SELECT * FROM cp_hive_metadata where id = #{id} ")
    @ResultMap(value = "cp_hive_metadata_by_id")
    CpHiveMetadata findById(@Param(value = "id") Long id);

    /**
     * <font color="yellow">获取单个表信息</font>
     *
     * @param id id
     * @Author: Mfrain
     * @Date: 2021/7/15 9:19 下午
     * @return: com.inke.compass.metadata.model.CpHiveMetadata
     */
    @Select(value = "SELECT * FROM cp_hive_metadata where id = #{id} ")
    @Results(id = "cp_hive_metadata_by_id", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "appName", column = "appName"),
            @Result(property = "dbName", column = "dbName"),
            @Result(property = "tbName", column = "tbName"),
            @Result(property = "DatasetId", column = "DatasetId"),
            @Result(property = "location", column = "location"),
            @Result(property = "formatType", column = "formatType"),
            @Result(property = "partition", column = "partition"),
//            @Result(property = "complementStartDay", column = "complementStartDay"),
//            @Result(property = "complementEndDay", column = "complementEndDay"),
            @Result(property = "cycle", column = "cycle"),
            @Result(property = "syncDay", column = "sync_day"),
            @Result(property = "syncHour", column = "sync_hour"),
            @Result(property = "syncMinute", column = "sync_minute"),
            @Result(property = "active", column = "active"),
            @Result(property = "isImport", column = "isImport"),

    })
    CpHiveMetadata getTableById(@Param(value = "id") long id);


    //查询当前库下的所有hive表，标注是否完成导入的状态

    @Select(value = "SELECT * FROM cp_hive_metadata where appName = #{appName} ")
    @Results(id = "cp_hive_metadata_by_appname", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "appName", column = "appName"),
            @Result(property = "dbName", column = "dbName"),
            @Result(property = "tbName", column = "tbName"),
            @Result(property = "DatasetId", column = "DatasetId"),
            @Result(property = "location", column = "location"),
            @Result(property = "formatType", column = "formatType"),
            @Result(property = "partition", column = "partition"),
//            @Result(property = "complementStartDay", column = "complementStartDay"),
//            @Result(property = "complementEndDay", column = "complementEndDay"),
            @Result(property = "cycle", column = "cycle"),
            @Result(property = "syncDay", column = "sync_day"),
            @Result(property = "syncHour", column = "sync_hour"),
            @Result(property = "syncMinute", column = "sync_minute"),
            @Result(property = "active", column = "active"),
            @Result(property = "isImport", column = "isImport"),

    })
    List<CpHiveMetadata> findAllHiveTable(@Param(value = "appName") String appName);

    //点击未导入过的hive表，将该表落库
    @Update("update cp_hive_metadata set isImport = 1 where appName = #{app} AND dbName = #{db} AND tbName = #{tb}")
    Integer  setImport(@Param(value = "db") String db,@Param(value = "app") String app, @Param(value = "tb") String tb);
}
package com.inke.compass.metadata.mapper;

import com.inke.compass.metadata.model.CpDataSource;
import com.inke.compass.metadata.monitor.ddbean.Text;
import org.apache.ibatis.annotations.*;
import com.inke.compass.metadata.model.CpCemRelation;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;


import java.sql.Timestamp;
import java.util.List;

public interface CpDataSourceMapper
{
    @Insert(value = "<script>" +
            "INSERT INTO cp_data_source(<trim prefix=\"\" suffixOverrides=\",\">" +
            "<if test=\"md.name != null\">`name`,</if>" +
            "<if test=\"md.description != null\">`description`,</if>" +
            "<if test=\"md.type != null\">`type`,</if>" +
            "<if test=\"md.proto != null\">`proto`,</if>" +
            "<if test=\"md.url != null\">`url`,</if>" +
            "<if test=\"md.username != null\">`username`,</if>" +
            "<if test=\"md.password != null\">`password`,</if>" +
            "<if test=\"md.cycle != null\">`cycle`,</if>" +
            "<if test=\"md.check != null\">`check`,</if>" +
            "<if test=\"md.custom != null\">`custom`,</if>" +
            "<if test=\"md.active != null\">`active`,</if>" +
            "<if test=\"md.create_user != null\">`create_user`,</if>" +
            "<if test=\"md.create_time != null\">`create_time`,</if>" +
            "<if test=\"md.update_time != null\">`update_time`,</if>" +
            "</trim>) " +
            "VALUES (<trim prefix=\"\" suffixOverride=\",\">" +
            "<if test=\"md.name != null\">#{md.name},</if>" +
            "<if test=\"md.description != null\">#{md.description},</if>" +
            "<if test=\"md.type != null\">#{md.type},</if>" +
            "<if test=\"md.proto != null\">#{md.proto},</if>" +
            "<if test=\"md.url != null\">#{md.url},</if>" +
            "<if test=\"md.username != null\">#{md.username},</if>" +
            "<if test=\"md.password != null\">#{md.password},</if>" +
            "<if test=\"md.cycle != null\">#{md.cycle},</if>" +
            "<if test=\"md.check != null\">#{md.check},</if>" +
            "<if test=\"md.custom != null\">#{md.custom},</if>" +
            "<if test=\"md.active != null\">#{md.active},</if>" +
            "<if test=\"md.create_user != null\">#{md.create_user},</if>" +
            "<if test=\"md.create_time != null\">#{md.create_time},</if>" +
            "<if test=\"md.update_time != null\">#{md.update_time},</if>" +
            "</trim>)" +
            "</script>")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    void save(@Param(value = "md") CpDataSource md);

    @Update(value = "<script>" +
            "UPDATE cp_data_source" +
            "<set>" +
            "   <if test=\"md.name != null\">" +
            "       name = #{md.name}," +
            "   </if>" +
            "   <if test=\"md.description != null\">" +
            "       description = #{md.description}," +
            "   </if>" +
            "   <if test=\"md.type != null\">" +
            "       type = #{md.type}," +
            "   </if>" +
            "   <if test=\"md.proto != null\">" +
            "       proto = #{md.proto}," +
            "   </if>" +
            "   <if test=\"md.url != null\">" +
            "       url = #{md.url}," +
            "   </if>" +
            "   <if test=\"md.username != null\">" +
            "       username = #{md.username}," +
            "   </if>" +
            "   <if test=\"md.password != null\">" +
            "       password = #{md.password}," +
            "   </if>" +
            "   <if test=\"md.cycle != null\">" +
            "       cycle = #{md.cycle}," +
            "   </if>" +
            "   <if test=\"md.check != null\">" +
            "       check = #{md.check}," +
            "   </if>" +
            "   <if test=\"md.custom != null\">" +
            "       custom = #{md.custom}," +
            "   </if>" +
            "   <if test=\"md.active != null\">" +
            "       active = #{md.active}," +
            "   </if>" +
            "   <if test=\"md.create_user != null\">" +
            "       create_user = #{md.create_user}," +
            "   </if>" +
            "   <if test=\"md.create_time != null\">" +
            "       create_time = #{md.create_time}," +
            "   </if>" +
            "   <if test=\"md.update_time != null\">" +
            "       update_time = #{md.update_time}," +
            "   </if>" +
            "</set>)" +
            "WHERE id = #{md.id}" +
            "</script>")
    void update(@Param(value = "md") CpDataSource md);

    @Select(value = "SELECT * FROM cp_data_source WHERE id = #{id}")
    @Results(id = "get_md_by_id", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "name", column = "name"),
            @Result(property = "description", column = "description"),
            @Result(property = "type", column = "type"),
            @Result(property = "proto", column = "proto"),
            @Result(property = "url", column = "url"),
            @Result(property = "username", column = "username"),
            @Result(property = "password", column = "password"),
            @Result(property = "cycle", column = "cycle"),
            @Result(property = "check", column = "check"),
            @Result(property = "custom", column = "custom"),
            @Result(property = "active", column = "active"),
            @Result(property = "create_user", column = "create_user"),
            @Result(property = "create_time", column = "create_time"),
            @Result(property = "update_time", column = "update_time"),
    })
    List<CpDataSource> findAllById();

    @Select(value = "SELECT * FROM cp_data_source")
    List<CpDataSource> findAll();
}

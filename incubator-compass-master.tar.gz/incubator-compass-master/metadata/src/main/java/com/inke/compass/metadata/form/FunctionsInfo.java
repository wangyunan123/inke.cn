package com.inke.compass.metadata.form;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * <p> @Description : 函数信息 </p>
 * <p> @incubator-compass </p>
 * <p> @Create Time : 2021/7/9 2:49 下午 </p>
 * <p> @Version : 3.0 </p>
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class FunctionsInfo
        implements Serializable
{
    private static final long serialVersionUID = 6609526191584556794L;
    private Long functionsId;
    private String functionstype;
    private String functionsname;
    private Integer functionsactive;


}




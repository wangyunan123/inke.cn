package com.inke.compass.metadata.mapper;

import com.inke.compass.metadata.model.CpTableColumn;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * <p> @Description : 事件mapper </p>
 * <p> @incubator-compass </p>
 * <p> @Author : Mfrain </p>
 * <p> @Create Time : 2021/1/5 4:58 下午 </p>
 * <p> @Author Email: <a href="mailTo:mfr1339941169@qq.com">Mfrain</a> </p>
 * <p> @Version : 1.0 </p>
 */
public interface CpTableColumnMapper
{
    /**
     * save
     *
     * @param event:
     * @Author: Mfrain
     * @Date: 2021/1/6 2:47 下午
     * @return: void
     */
    @Insert(value = "<script>" +
            "INSERT INTO cp_table_column (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"event.id != null\" >`id`,</if>" +
            "   <if test=\"event.tbId != null\" >`tbid`,</if>" +
            "   <if test=\"event.cname != null\" >`cname`,</if>" +
            "   <if test=\"event.dataType != null\" >`datatype`,</if>" +
            "   <if test=\"event.label != null\" >`label`,</if>" +
            "   <if test=\"event.type != null\" >`type`,</if>" +
            "   <if test=\"event.desc != null\" >`desc`,</if>" +
            "   <if test=\"event.express != null\" >`express`,</if>" +
            "   <if test=\"event.originColumn != null\" >`origin_column`,</if>" +
            "</trim>) " +
            "VALUES (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"event.id != null\" >#{event.id},</if>" +
            "   <if test=\"event.tbId != null\" >#{event.tbId},</if>" +
            "   <if test=\"event.cname != null\" >#{event.cname},</if>" +
            "   <if test=\"event.dataType != null\" >#{event.dataType},</if>" +
            "   <if test=\"event.label != null\" >#{event.label},</if>" +
            "   <if test=\"event.type != null\" >#{event.type},</if>" +
            "   <if test=\"event.desc != null\" >#{event.desc},</if>" +
            "   <if test=\"event.express != null\" >#{event.express},</if>" +
            "   <if test=\"event.originColumn != null\" >#{event.originColumn},</if>" +
            "</trim>)" +
            "</script>")
    @Options(useGeneratedKeys = true, keyProperty = "event.id", keyColumn = "id")
    void save(@Param(value = "event") CpTableColumn event);

    /**
     * findAll
     *
     * @Author: Mfrain
     * @Date: 2021/1/6 2:47 下午
     * @return: java.util.List<com.inke.compass.metadata.model.EventInfo>
     */
    @Select(value = "SELECT * FROM cp_table_column ")
    @Results(id = "cp_event_all", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "tbId", column = "tbid"),
            @Result(property = "cname", column = "cname"),
            @Result(property = "dataType", column = "datatype"),
            @Result(property = "label", column = "label"),
            @Result(property = "type", column = "type"),
            @Result(property = "desc", column = "desc"),
            @Result(property = "express", column = "express")
    })
    List<CpTableColumn> findAll();

    /**
     * 获取Event
     *
     * @param eventId:
     * @Author: Mfrain
     * @Date: 2021/1/8 10:15 上午
     * @return: java.util.List<com.inke.compass.metadata.model.CpEvent>
     */
    @Select(value = "SELECT * FROM cp_table_column  where tbId = #{eventId}")
    @Results(id = "get_event_info", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "tbId", column = "tbid"),
            @Result(property = "cname", column = "cname"),
            @Result(property = "dataType", column = "datatype"),
            @Result(property = "label", column = "label"),
            @Result(property = "type", column = "type"),
            @Result(property = "desc", column = "desc"),
            @Result(property = "express", column = "express")
    })
    List<CpTableColumn> getTableColumnByTbId(@Param(value = "eventId") long eventId);

    @Delete(value = "DELETE FROM cp_table_column WHERE tbid = #{eventId}")
    Integer deleteByEventId(@Param(value = "eventId") Long eventId);
}
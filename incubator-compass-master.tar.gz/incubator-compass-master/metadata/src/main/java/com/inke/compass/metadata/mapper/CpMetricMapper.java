/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.inke.compass.metadata.mapper;

import com.inke.compass.metadata.model.CpMetric;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * @author mfrain
 */
public interface CpMetricMapper
{
    @Select("SELECT * FROM cp_metric_condition " +
            "WHERE metric_name = #{metricName} " +
            "AND event_name = #{eventName} " +
            "AND app_id = #{appId} " +
            "AND column_id = #{columnId}")
    @Results(value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "name", column = "name"),
            @Result(property = "metricName", column = "metric_name"),
            @Result(property = "eventName", column = "event_name"),
            @Result(property = "column", column = "column"),
            @Result(property = "express", column = "express"),
            @Result(property = "value", column = "value")
    })
    List<CpMetric> findAllMetricCondition(@Param(value = "appId") String appId,
            @Param(value = "columnId") String columnId,
            @Param(value = "metricName") String metricName,
            @Param(value = "eventName") String eventName);

    /**
     * 获取指标筛选条件
     *
     * @param appId:
     * @param columnId:
     * @Author: Mfrain
     * @Date: 2021/4/21 4:45 下午
     * @return: java.util.List<com.inke.compass.metadata.model.CpMetric>
     */
    @Select("SELECT * FROM cp_metric_condition " +
            "WHERE app_id = #{appId} " +
            "AND column_id = #{columnId}")
    List<CpMetric> findMetricCondition(@Param(value = "appId") String appId, @Param(value = "columnId") String columnId);

    @Insert(value = "<script>" +
            "INSERT INTO cp_metric_condition (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"ctst.metricName != null\" >`metric_name`,</if>" +
            "   <if test=\"ctst.eventName != null\" >`event_name`,</if>" +
            "   <if test=\"ctst.column != null\" >`column`,</if>" +
            "   <if test=\"ctst.express != null\" >`express`,</if>" +
            "   <if test=\"ctst.value != null\" >`value`,</if>" +
            "   <if test=\"ctst.appId != null\" >`app_id`,</if>" +
            "   <if test=\"ctst.columnId != null\" >`column_id`,</if>" +
            "</trim>) " +
            "VALUES (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"ctst.metricName != null\" >#{ctst.metricName},</if>" +
            "   <if test=\"ctst.eventName != null\" >#{ctst.eventName},</if>" +
            "   <if test=\"ctst.column != null\" >#{ctst.column},</if>" +
            "   <if test=\"ctst.express != null\" >#{ctst.express},</if>" +
            "   <if test=\"ctst.value != null\" >#{ctst.value},</if>" +
            "   <if test=\"ctst.appId != null\" >#{ctst.appId},</if>" +
            "   <if test=\"ctst.columnId != null\" >#{ctst.columnId},</if>" +
            "</trim>)" +
            "</script>")
    @Options(useGeneratedKeys = true, keyProperty = "ctst.id", keyColumn = "id")
    void save(@Param(value = "ctst") CpMetric ctst);
}

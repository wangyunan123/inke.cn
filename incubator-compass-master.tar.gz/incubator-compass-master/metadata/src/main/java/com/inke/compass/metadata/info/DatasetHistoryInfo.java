package com.inke.compass.metadata.info;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.apache.ibatis.annotations.Result;

@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class DatasetHistoryInfo
{
    private Long id;
    private String name;
    private String datasetId;
    private String partition;
    private String startTime;
    private String endTime;
    private String createUser;
    private String status;
    private String size;
    private Integer total;
    private String syncMode;
    private String type;
    private String message;
}

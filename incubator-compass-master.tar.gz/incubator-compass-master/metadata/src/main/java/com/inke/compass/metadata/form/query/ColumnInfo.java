package com.inke.compass.metadata.form.query;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <p> @Description : 字段详情 </p>
 * <p> @incubator-compass </p>
 * <p> @Author : <a href="mailTo:mfr1339941169@qq.com">Mfrain</a>  </p>
 * <p> @Create Time : 2021/7/1 3:37 下午 </p>
 * <p> @Version : 1.0 </p>
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ColumnInfo
{
    private long id;
    private String columnName;
    private String tableName;
    private String name;
    private String dataType;
    private String type;
    private String express;
    private String label;
    private String desc;
}

package com.inke.compass.metadata.mapper;

import com.inke.compass.metadata.model.CpKafkaConnection;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultType;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

public interface CpKafkaConnectionMapper
{
    @Insert(value = "<script>" +
            "INSERT INTO cp_kafka_connection(<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"kc.name != null\">`name`,</if>" +
            "   <if test=\"kc.description != null\">`description`,</if>" +
            "   <if test=\"kc.zkAddr != null\">`zk_addr`,</if>" +
            "   <if test=\"kc.createUser != null\">`create_user`,</if>" +
            "   <if test=\"kc.active != null\">`active`,</if>" +
            "</trim>) " +
            "VALUES (<trim prefix=\"\" suffixOverride=\",\">" +
            "   <if test=\"kc.name != null\">#{kc.name},</if>" +
            "   <if test=\"kc.description != null\">#{kc.description},</if>" +
            "   <if test=\"kc.zkAddr != null\">#{kc.zkAddr},</if>" +
            "   <if test=\"kc.createUser != null\">#{kc.createUser},</if>" +
            "   <if test=\"kc.active != null\">#{kc.active}</if>" +
            "</trim>)" +
            "</script>")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    void save(@Param(value = "kc") CpKafkaConnection kc);

    @Update(value = "<script>" +
            "UPDATE cp_kafka_connection" +
            "<set>" +
            "   <if test=\"kc.name != null\">" +
            "       name = #{kc.name}," +
            "   </if>" +
            "   <if test=\"kc.description != null\">" +
            "       description = #{kc.description}," +
            "   </if>" +
            "   <if test=\"kc.zkAddr != null\">" +
            "       zk_addr = #{kc.zkAddr}," +
            "   </if>" +
            "   <if test=\"kc.active != null\">" +
            "       active = #{kc.active}," +
            "   </if>" +
            "</set>" +
            "WHERE id = #{kc.id}" +
            "</script>")
    void update(@Param(value = "kc") CpKafkaConnection kc);

    @Select(value = "SELECT * FROM cp_kafka_connection WHERE id = #{id}")
    @Results(id = "get_kc_by_id", value = {
            @Result(property = "id", column = "id"),
            @Result(property = "name", column = "name"),
            @Result(property = "description", column = "description"),
            @Result(property = "zkAddr", column = "zk_addr"),
            @Result(property = "createUser", column = "create_user"),
            @Result(property = "createTime", column = "create_time"),
            @Result(property = "updateTime", column = "update_time"),
            @Result(property = "active", column = "active"),
    })
    CpKafkaConnection getById(@Param(value = "id") long id);

    @Select(value = "<script>" +
            "   SELECT * FROM cp_kafka_connection" +
            "       <where>" +
            "           <if test=\"active != null\">" +
            "               `active` = #{active}" +
            "           </if>" +
            "       </where>" +
            "   ORDER BY create_time DESC" +
            "   LIMIT #{offset}, #{limit}" +
            "</script>")
    @Results(id = "list_kcs", value = {
            @Result(property = "id", column = "id"),
            @Result(property = "name", column = "name"),
            @Result(property = "description", column = "description"),
            @Result(property = "zkAddr", column = "zk_addr"),
            @Result(property = "createUser", column = "create_user"),
            @Result(property = "createTime", column = "create_time"),
            @Result(property = "updateTime", column = "update_time"),
            @Result(property = "active", column = "active"),
    })
    List<CpKafkaConnection> listByPage(@Param(value = "offset") int offset, @Param(value = "limit") int limit, @Param(value = "active") Boolean active);

    @Select(value = "<script>" +
            "   SELECT COUNT(1) FROM cp_kafka_connection" +
            "       <where>" +
            "           <if test=\"active != null\">" +
            "               active = #{active}" +
            "           </if>" +
            "       </where>" +
            "</script>")
    @ResultType(value = Integer.class)
    Integer getTotal(@Param(value = "active") Boolean active);
}

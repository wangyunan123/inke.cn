package com.inke.compass.metadata.mapper;

import com.inke.compass.metadata.info.DataTypeInfo;
import com.inke.compass.metadata.info.ExpressInfo;
import com.inke.compass.metadata.info.FilterInfo;
import com.inke.compass.metadata.info.UnionInfo;
import com.inke.compass.metadata.model.CpCemRelation;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;
import java.util.Map;

/**
 * <p> incubator-compass</p>
 * <p> @Description :  </p>
 * <p> @Author : 24k-xiao-shan </p>
 * <p> @Version :  </p>
 * <p> @Create Time :  2021-01-05 18:45:05 </p>
 * <p> @Author Email: <a href="mailTo:1912079423@qq.com">gaojunshan</a> </p>
 */
public interface CpCemRelationMapper
{
    /**
     * save
     *
     * @param model:
     * @Author: Mfrain
     * @Date: 2021/1/7 11:51 &#x4E0A;&#x5348;
     * @return: void
     */
    @Insert(value = "<script>" +
            "INSERT INTO cp_cem_relation (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"model.columnId != null\" >column_id,</if>" +
            "   <if test=\"model.eventId != null\" >event_id,</if>" +
            "   <if test=\"model.moduleId != null\" >module_id,</if>" +
            "   <if test=\"model.datatypeId != null\" >`datatype_id`,</if>" +
            "   <if test=\"model.expressId != null\" >`express_id`,</if>" +
            "   <if test=\"model.filterId != null\" >`filter_id`,</if>" +
            "</trim>) " +
            "VALUES (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"model.columnId != null\" >#{model.columnId},</if>" +
            "   <if test=\"model.eventId != null\" >#{model.eventId},</if>" +
            "   <if test=\"model.moduleId != null\" >#{model.moduleId},</if>" +
            "   <if test=\"model.datatypeId != null\" >#{model.datatypeId},</if>" +
            "   <if test=\"model.expressId != null\" >#{model.expressId},</if>" +
            "   <if test=\"model.filterId != null\" >#{model.filterId},</if>" +
            "</trim>)" +
            "</script>")
    @Options(useGeneratedKeys = true, keyProperty = "model.id")
    void save(@Param(value = "model") CpCemRelation model);

    /**
     * @param id
     * @delete
     */
    @Delete("<script>" +
            "delete from cp_column " +
            " where id = #{id}" +
            "</script>")
    void delete(@Param(value = "id") Long id);

    /**
     * deleteByEventId
     *
     * @param id:
     * @Author: Mfrain
     * @Date: 2021/4/28 2:12 上午
     * @return: void
     */
    @Delete("<script>" +
            "delete from cp_cem_relation " +
            " where event_id = #{id}" +
            "</script>")
    void deleteByEventId(@Param(value = "id") Long id);

    /**
     * update
     *
     * @param model:
     * @Author: Mfrain
     * @Date: 2021/1/7 11:56 上午
     * @return: void
     */
    @Update("<script>" +
            "update cp_cem_relation" +
            "    <set >" +
            "      <if test=\"model.moduleId != null\" >" +
            "        module_id = #{model.moduleId},    " +
            "      </if>" +
            "      <if test=\"model.eventId != null\" >" +
            "        event_id = #{model.eventId},    " +
            "      </if>" +
            "      <if test=\"model.columnId != null\" >" +
            "        column_id = #{model.columnId},    " +
            "      </if>" +
            "      <if test=\"model.datatypeId != null\" >" +
            "        datatype_id = #{model.datatypeId},    " +
            "      </if>" +
            "      <if test=\"model.expressId != null\" >" +
            "        express_id = #{model.expressId}," +
            "      </if>" +
            "      <if test=\"model.filterId != null\" >" +
            "        filter_id = #{model.filterId}," +
            "      </if>" +
            "    </set>" +
            "    where id = #{model.id}" +
            "</script>")
    void update(@Param(value = "model") CpCemRelation model);

    /**
     * find all
     *
     * @Author: Mfrain
     * @Date: 2021/1/7 11:57 上午
     * @return: java.util.List<model.CpCemRelation>
     */
    @Select(value = "SELECT * FROM cp_cem_relation ")
    @Results(id = "cp_cem_relation_all", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "columnId", column = "column_id"),
            @Result(property = "eventId", column = "event_id"),
            @Result(property = "moduleId", column = "module_id"),
            @Result(property = "datatypeId", column = "datatype_id"),
            @Result(property = "expressId", column = "express_id"),
            @Result(property = "filterId", column = "filter_id"),
    })
    List<CpCemRelation> findAll();

    /**
     * 获取模型下所有事件ID
     *
     * @param moduleId:
     * @Author: Mfrain
     * @Date: 2021/1/7 2:12 下午
     * @return: java.util.List<model.CpCemRelation>
     */
    @Select(value = "SELECT distinct event_id FROM cp_cem_relation  where module_id = #{moduleId}")
    List<Long> findEventIdByModuleId(@Param(value = "moduleId") long moduleId);

    /**
     * 获取事件所属的模型
     *
     * @param eventId:
     * @Author: Mfrain
     * @Date: 2021/1/7 2:43 下午
     * @return: java.util.List<java.lang.Long>
     */
    @Select(value = "SELECT distinct module_id FROM cp_cem_relation  where event_id = #{eventId}")
    List<Long> findModuleIdByEventId(@Param(value = "eventId") long eventId);

    /**
     * 查询事件下的对应属性ID
     *
     * @param eventId:
     * @Author: Mfrain
     * @Date: 2021/1/8 3:15 下午
     * @return: java.util.List<java.lang.Long>
     */
    @Select(value = "SELECT distinct column_id FROM cp_cem_relation  where event_id = #{eventId}")
    List<Long> findColumnIdByEventId(@Param(value = "eventId") long eventId);

    /**
     * 根据属性获取cem数据
     *
     * @param columnId:
     * @param eventId:
     * @Author: toni
     * @Date: 2021/1/8 2:38 下午
     * @return: java.util.List<model.CpCemRelation>
     */
    @Select(value = "<script>"
            + "select * FROM cp_cem_relation "
            + "where 1 = 1 "
            + "<if test=\"columnId != null\" >"
            + " and column_id = #{columnId}"
            + "</if>"
            + "<if test=\"eventId != null\" >"
            + " and event_id = #{eventId}"
            + "</if>"
            + "group by datatype_id, express_id, filter_id"
            + "</script>")
    @Results(id = "cp_cem_find", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "columnId", column = "column_id"),
            @Result(property = "eventId", column = "event_id"),
            @Result(property = "moduleId", column = "module_id"),
            @Result(property = "datatypeId", column = "datatype_id"),
            @Result(property = "expressId", column = "express_id"),
            @Result(property = "filterId", column = "filter_id"),
    })
    List<CpCemRelation> findColumnProperties(@Param(value = "columnId") Long columnId, @Param(value = "eventId") Long eventId);

    /**
     * 查询 cem 关系
     *
     * @param eventId:
     * @Author: Mfrain
     * @Date: 2021/2/24 4:40 下午
     * @return: java.util.List<com.inke.compass.metadata.model.CpCemRelation>
     */
    @Select(value = "select * FROM cp_cem_relation where event_id = #{eventId}")
    @Results(id = "cp_cem_find_by_event", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "columnId", column = "column_id"),
            @Result(property = "eventId", column = "event_id"),
            @Result(property = "moduleId", column = "module_id"),
            @Result(property = "datatypeId", column = "datatype_id"),
            @Result(property = "expressId", column = "express_id"),
            @Result(property = "filterId", column = "filter_id"),
    })
    List<CpCemRelation> findCemByEventId(@Param(value = "eventId") Long eventId);

    @Select(value = "SELECT DISTINCT\n" +
            "\tc.id AS columnId ,\n" +
            "\tc.`column` AS `column` ,\n" +
            "\tc.type AS type ,\n" +
            "\te.`name` AS `table` ,\n" +
            "\ta.appkey AS appname ,\n" +
            "\tc.label AS columnName\n" +
            "FROM\n" +
            "\tcp_cem_relation AS cem\n" +
            "LEFT JOIN cp_column AS c ON c.id = cem.column_id\n" +
            "LEFT JOIN cp_event AS e ON e.id = cem.event_id\n" +
            "LEFT JOIN cp_app_info AS a ON a.id = e.appid\n" +
            "WHERE\n" +
            "\ta.appkey IS NOT NULL")
    List<Map<String, String>> findAllColumnAndEventAndApp();

    @Select(value = "SELECT\n" +
            "\t`name`, label, express \n" +
            "FROM\n" +
            "\tcp_cem_relation AS ccr\n" +
            "\tLEFT JOIN cp_express AS ce ON ccr.express_id = ce.id \n" +
            "WHERE\n" +
            "\tevent_id = #{eventId} \n" +
            "\tAND column_id = #{columnId}")
    List<ExpressInfo> findAllByEventAndColumn(@Param(value = "eventId") Long eventId,
            @Param(value = "columnId") Long columnId);

    @Select(value = "SELECT\n" +
            "\tDISTINCT cdt.id AS id, cdt.`name`, cdt.label\n" +
            "FROM\n" +
            "\tcp_cem_relation AS ccr\n" +
            "\tLEFT JOIN cp_datatype AS cdt ON ccr.datatype_id = cdt.id \n" +
            "WHERE\n" +
            "\tevent_id = #{eventId} \n" +
            "\tAND column_id = #{columnId}")
    DataTypeInfo findDataTypeByEventAndColumn(@Param(value = "eventId") Long eventId,
            @Param(value = "columnId") Long columnId);

    @Select(value = "SELECT\n" +
            "\tcf.`name` AS `name`, cf.label AS label, cf.type AS type\n" +
            "FROM\n" +
            "\tcp_cem_relation AS ccr\n" +
            "\tLEFT JOIN cp_filter AS cf ON ccr.filter_id = cf.id \n"+
            "WHERE\n" +
            "\tevent_id = #{eventId} \n" +
            "\tAND column_id = #{columnId}" +
            "\tAND ccr.filter_id != 0")
    List<FilterInfo> findAllFilterByEventAndColumn(@Param(value = "eventId") Long eventId,
            @Param(value = "columnId") Long columnId);

    @Select(value = "SELECT `name` AS `name`, label AS label, express AS type, 'express' AS category\n" +
            "FROM cp_cem_relation AS ccr\n" +
            "LEFT JOIN cp_express AS ce ON ccr.express_id = ce.id\n" +
            "WHERE event_id = #{eventId}\n" +
            "AND column_id = #{columnId}\n" +
            "UNION ALL\n" +
            "SELECT\n" +
            "DISTINCT cdt.`name` AS `name`, cdt.label, '' as type, 'datatype' AS category\n" +
            "FROM cp_cem_relation AS ccr\n" +
            "LEFT JOIN cp_datatype AS cdt ON ccr.datatype_id = cdt.id \n" +
            "WHERE event_id = #{eventId}\n" +
            "AND column_id = #{columnId}\n" +
            "UNION ALL\n" +
            "SELECT cf.`name` AS `name`, cf.label AS label, cf.type AS type, 'filter' AS category\n" +
            "FROM cp_cem_relation AS ccr\n" +
            "LEFT JOIN cp_filter AS cf ON ccr.filter_id = cf.id\n" +
            "WHERE event_id = #{eventId}\n" +
            "AND column_id = #{columnId}\n" +
            "AND ccr.filter_id != 0")
    List<UnionInfo> findAllUnionByEventAndColumn(@Param(value = "eventId") Long eventId,
            @Param(value = "columnId") Long columnId);
}

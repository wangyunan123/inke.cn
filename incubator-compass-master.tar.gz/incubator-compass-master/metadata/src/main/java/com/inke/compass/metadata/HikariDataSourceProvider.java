package com.inke.compass.metadata;

import com.google.inject.Inject;
import com.google.inject.Provider;
import com.zaxxer.hikari.HikariDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Named;
import javax.sql.DataSource;

public class HikariDataSourceProvider
        implements Provider<DataSource>
{
    private static final Logger LOGGER = LoggerFactory.getLogger(HikariDataSourceProvider.class);

    private final HikariDataSource dataSource = new HikariDataSource();

    @Inject
    public void setDriverClassName(@Named("jdbc.mysql.driverClassName") final String driverClassName)
    {
        dataSource.setDriverClassName(driverClassName);
    }

    @Inject
    public void setUrl(@Named("jdbc.mysql.url") final String url)
    {
        dataSource.setJdbcUrl(url);
    }

    @Inject
    public void setUsername(@Named("jdbc.mysql.username") final String username)
    {
        dataSource.setUsername(username);
    }

    @Inject
    public void setPassword(@Named("jdbc.mysql.password") final String password)
    {
        dataSource.setPassword(password);
    }

    @Inject
    public void setMinimumIdle(@Named("jdbc.mysql.minimumIdle") final int minimumIdle)
    {
        dataSource.setMinimumIdle(minimumIdle);
    }

    @Inject
    public void setMaximumPoolSize(@Named("jdbc.mysql.maximumPoolSize") final int maximumPoolSize)
    {
        dataSource.setMaximumPoolSize(maximumPoolSize);
    }

    @Inject
    public void setConnectionTestQuery(@Named("jdbc.mysql.connectionTestQuery") final String connectionTestQuery)
    {
        dataSource.setConnectionTestQuery(connectionTestQuery);
    }

    @Inject
    public void setDataSourceCachePrepStmts(@Named("jdbc.mysql.dataSource.cachePrepStmts") final boolean cachePrepStmts)
    {
        dataSource.addDataSourceProperty("cachePrepStmts", cachePrepStmts);
    }

    @Inject
    public void setDataSourcePrepStmtCacheSize(@Named("jdbc.mysql.dataSource.prepStmtCacheSize") final int prepStmtCacheSize)
    {
        dataSource.addDataSourceProperty("prepStmtCacheSize", prepStmtCacheSize);
    }

    @Inject
    public void setDataPrepStmtCacheSqlLimit(@Named("jdbc.mysql.dataSource.prepStmtCacheSqlLimit") final int prepStmtCacheSqlLimit)
    {
        dataSource.addDataSourceProperty("prepStmtCacheSqlLimit", prepStmtCacheSqlLimit);
    }

    @Inject
    public void setDataUseServerPrepStmts(@Named("jdbc.mysql.dataSource.useServerPrepStmts") final boolean useServerPrepStmts)
    {
        dataSource.addDataSourceProperty("useServerPrepStmts", useServerPrepStmts);
    }

    @Override
    public DataSource get()
    {
        LOGGER.info("init hikari datasource");
        return dataSource;
    }
}

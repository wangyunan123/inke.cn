/**
 * Copyright 2021 json.cn
 */
package com.inke.compass.metadata.form;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

/**
 * Auto-generated: 2021-07-08 4:53:40
 *
 * @author json.cn (i@json.cn)
 * @website http://www.json.cn/java2pojo/
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class HisList
{

    private long id;
    private String name;
    private String label;
    private String status;
    private String tbtype;
    private String owner;
    private Long size;
    private String cycle;
    private String createTime;
    private List<History> history;
}
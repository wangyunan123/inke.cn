package com.inke.compass.metadata.body;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class DatasetFieldBody
{
    private String eventName;
    private String fieldName;
    private String type;
    private String alias;
}

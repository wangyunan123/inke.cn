package com.inke.compass.metadata;

/**
 * <p> incubator-compass</p>
 * <p> Description :  </p>
 * <p> Author : 24k-xiao-shan </p>
 * <p> Version :  </p>
 * <p> Create Time :  2021-01-05 15:33 </p>
 * <p> Author Email: <a href="mailTo:1912079423@qq.com">gaojunshan</a> </p>
 */
public interface DataSourceService<T>
{
    void saveModel(T model);

    void updateModel(T model);

    T findById(Integer id);
}

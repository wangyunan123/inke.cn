package com.inke.compass.metadata.form;

import com.inke.compass.metadata.model.CpColumn;
import com.inke.compass.metadata.model.CpEvent;
import com.inke.compass.metadata.model.CpExpress;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * <p> @Description : 指标参数类 </p>
 * <p> @incubator-compass </p>
 * <p> @Author : <a href="mailTo:mfr1339941169@qq.com">Mfrain</a>  </p>
 * <p> @Create Time : 2021/4/21 10:55 上午 </p>
 * <p> @Version : 1.0 </p>
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CpMetricForm
        implements Serializable
{
    private static final long serialVersionUID = 4884784362655202608L;

    private Long metricId;
    private String metricName;
    private String metricLabel;
    private List<CpExpress> express;
    private String creator;
    private String createTime;
    private String lastEditor;
    private String lastUpdateTime;
    private List<String> sourceTables;
    private String metricDes;
    private List<CpCondition> conditions;
    private List<CpDimension> dimensions;
    private String querySql;
    private String eventInfo;
    private String cacheData;
    private CpEvent oldEventInfo;
    private CpColumn oldMetricInfo;
}


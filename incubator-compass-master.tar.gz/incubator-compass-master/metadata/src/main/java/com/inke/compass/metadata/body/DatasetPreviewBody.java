package com.inke.compass.metadata.body;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.List;

@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class DatasetPreviewBody
{
    private List<DatasetFieldBody> attributes;
    private List<String> data;
}

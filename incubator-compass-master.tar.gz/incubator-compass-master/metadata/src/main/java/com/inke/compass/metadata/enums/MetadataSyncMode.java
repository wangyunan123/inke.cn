package com.inke.compass.metadata.enums;

/**
 * @author cxg
 */

public enum MetadataSyncMode
{
    //
    SYS_AUTO,
    USER_MANUAL
}

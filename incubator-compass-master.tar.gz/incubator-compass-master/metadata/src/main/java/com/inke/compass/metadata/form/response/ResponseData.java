package com.inke.compass.metadata.form.response;

import com.inke.compass.metadata.model.vo.CpColumnVo;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * <p> incubator-compass</p>
 * <p> Description :  </p>
 * <p> Author : 24k-xiao-shan </p>
 * <p> Version :  </p>
 * <p> Create Time :  2021-01-19 21:52:58 </p>
 * <p> Author Email: <a href="mailTo:1912079423@qq.com">gaojunshan</a> </p>
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResponseData
    implements Serializable
{
    private String dataSource;
    private String module;
    private List<String> modules;
    private long start;
    private long end;
    private long expend;
    private String event;
    private List<String> events;
    private List<String> data;
    private List<CpColumnVo> attributes;
    private String querySql;
    private List<Field> fields;
}

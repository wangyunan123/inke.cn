package com.inke.compass.metadata.databusi;

import com.google.gson.GsonBuilder;
import com.google.gson.annotations.SerializedName;
import com.inke.compass.metadata.onedata.CommonResponse;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmptyDataResponse {
    @SerializedName(value = "dm_error")
    private Integer code;
    @SerializedName(value = "error_msg")
    private String message;

    public static EmptyDataResponse fromJson(String json)
    {
        // json builder
        GsonBuilder gb = new GsonBuilder();
        return gb.create().fromJson(json, EmptyDataResponse.class);
    }
}

package com.inke.compass.metadata.enums;

/**
 * <p> @Description : 表数据同步周期 </p>
 * <p> @incubator-compass </p>
 * <p> @Author : Mfrain </p>
 * <p> @Create Time : 2021/7/21 12:00 下午 </p>
 * <p> @Author Email: <a href="mailTo:mfr1339941169@qq.com">Mfrain</a> </p>
 * <p> @Version : 1.0 </p>
 */
public enum CpTableCycle
{
    //同步周期
    NONE(0, "无周期"),
    DAY(1, "天"),
    WEEK(2, "周"),
    MONTH(3, "月"),
    YEAR(4, "年");

    private final Integer code;
    private final String value;

    CpTableCycle(Integer code, String value)
    {
        this.code = code;
        this.value = value;
    }

    public String getValue()
    {
        return value;
    }

    public Integer getCode()
    {
        return code;
    }
}

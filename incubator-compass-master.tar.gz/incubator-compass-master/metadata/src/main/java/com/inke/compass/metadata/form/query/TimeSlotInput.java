package com.inke.compass.metadata.form.query;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * <p> incubator-compass</p>
 * <p> Description :  </p>
 * <p> @Author : 24k-xiao-shan </p>
 * <p> Version :  </p>
 * <p> Create Time :  2021-01-19 11:03:02 </p>
 * <p> Author Email: <a href="mailTo:1912079423@qq.com">gaojunshan</a> </p>
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TimeSlotInput
        implements Serializable
{
    private String start;
    private String end;
}

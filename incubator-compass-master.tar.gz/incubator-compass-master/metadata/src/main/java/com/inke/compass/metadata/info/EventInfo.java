package com.inke.compass.metadata.info;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class EventInfo
{
    private Long id;
    private String appName;
    private String dbName;
    private String tbName;
}

package com.inke.compass.metadata.mapper;

import com.inke.compass.metadata.info.EventAndColumnInfo;
import com.inke.compass.metadata.model.CpMdecaRelation;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

/**
 * <p> @Description : 指标目录相关关系 mapper </p>
 * <p> @incubator-compass </p>
 * <p> @Author : Mfrain </p>
 * <p> @Create Time : 2021/4/21 9:51 下午 </p>
 * <p> @Author Amail: <a href="mailTo:mfr1339941169@qq.com">Mfrain</a> </p>
 * <p> @Version : 1.0 </p>
 */
public interface CpMdecaRelationMapper
{

    /**
     * save
     *
     * @param mdeca:
     * @Author: Mfrain
     * @Date: 2021/4/21 3:19 下午
     * @return: void
     */
    @Insert(value = "<script>" +
            "INSERT INTO cp_mdeca_relation (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"mdeca.metricDirId != null\" >`metricDirId`,</if>" +
            "   <if test=\"mdeca.eventId != null\" >`eventId`,</if>" +
            "   <if test=\"mdeca.columnId != null\" >`columnId`,</if>" +
            "   <if test=\"mdeca.appId != null\" >`appId`,</if>" +
            "   <if test=\"mdeca.rootEvent != null\" >`rootEvent`,</if>" +
            "   <if test=\"mdeca.eventInfo != null\" >`eventInfo`,</if>" +
            "   <if test=\"mdeca.cacheData != null\" >`cacheData`,</if>" +
            "</trim>) " +
            "VALUES (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"mdeca.metricDirId != null\" >#{mdeca.metricDirId},</if>" +
            "   <if test=\"mdeca.eventId != null\" >#{mdeca.eventId},</if>" +
            "   <if test=\"mdeca.columnId != null\" >#{mdeca.columnId},</if>" +
            "   <if test=\"mdeca.appId != null\" >#{mdeca.appId},</if>" +
            "   <if test=\"mdeca.rootEvent != null\" >#{mdeca.rootEvent},</if>" +
            "   <if test=\"mdeca.eventInfo != null\" >#{mdeca.eventInfo},</if>" +
            "   <if test=\"mdeca.cacheData != null\" >#{mdeca.cacheData},</if>" +
            "</trim>)" +
            "</script>")
    @Options(useGeneratedKeys = true, keyProperty = "mdeca.metricDirId", keyColumn = "metricDirId")
    void save(@Param(value = "mdeca") CpMdecaRelation mdeca);

    /**
     * update
     *
     * @param mdeca:
     * @Author: Mfrain
     * @Date: 2021/4/21 3:21 下午
     * @return: void
     */
    @Update("<script>" +
            "update cp_mdeca_relation" +
            "    <set >" +
            "      <if test=\"mdeca.eventId != null\" >" +
            "        eventId = #{mdeca.eventId},    " +
            "      </if>" +
            "      <if test=\"mdeca.columnId != null\" >" +
            "        columnId = #{mdeca.columnId}," +
            "      </if>" +
            "      <if test=\"mdeca.appId != null\" >" +
            "        appId = #{mdeca.appId}," +
            "      </if>" +
            "      <if test=\"mdeca.rootEvent != null\" >" +
            "        rootEvent = #{mdeca.rootEvent}," +
            "      </if>" +
            "      <if test=\"mdeca.eventInfo != null\" >" +
            "        eventInfo = #{mdeca.eventInfo}," +
            "      </if>" +
            "      <if test=\"mdeca.cacheData != null\" >" +
            "        cacheData = #{mdeca.cacheData}," +
            "      </if>" +
            "    </set>" +
            "    where metricDirId = #{mdeca.metricDirId}" +
            "</script>")
    void update(@Param(value = "mdeca") CpMdecaRelation mdeca);

    /**
     * findAll
     *
     * @Author: Mfrain
     * @Date: 2021/4/21 3:22 下午
     * @return: java.util.List<com.inke.compass.metadata.model.CpCudRelation>
     */
    @Select(value = "SELECT * FROM cp_mdeca_relation ")
    @Results(id = "cp_mdeca_relation_all", value = {
            @Result(property = "metricDirId", column = "metricDirId", id = true),
            @Result(property = "eventId", column = "eventId"),
            @Result(property = "columnId", column = "columnId"),
            @Result(property = "rootEvent", column = "rootEvent"),
            @Result(property = "eventInfo", column = "eventInfo"),
            @Result(property = "cacheData", column = "cacheData")
    })
    List<CpMdecaRelation> findAll();

    /**
     * findAll
     *
     * @Author: Mfrain
     * @Date: 2021/4/21 3:22 下午
     * @return: java.util.List<com.inke.compass.metadata.model.CpCudRelation>
     */
    @Select(value = "SELECT\n" +
            "\t`metricDirId`,\n" +
            "\t`rootEvent`,\n" +
            "\tce.id AS eventId,\n" +
            "\tce.`name` AS eventName,\n" +
            "\tce.label AS eventLabel,\n" +
            "\tce.type AS eventType,\n" +
            "\tcc.id AS columnId,\n" +
            "\tcc.`name` AS columnName,\n" +
            "\tcc.label AS columnLabel,\n" +
            "\tcc.type AS columnType,\n" +
            "\tcc.`column` AS columnColumn,\n" +
            "\tcc.`tables` AS columnTable," +
            "\tcc.input_model_id AS inputModelId \n" +
            "FROM\n" +
            "\tcp_mdeca_relation AS cmr\n" +
            "\tLEFT JOIN cp_event AS ce ON cmr.eventid = ce.id\n" +
            "\tLEFT JOIN cp_column AS cc ON cmr.columnId = cc.id \n" +
            "\tLEFT JOIN cp_app_info AS ca ON cmr.appId = ca.id \n" +
            "WHERE\n" +
            "COALESCE(ca.type, 'APP') = #{type}\n" +
            "\tAND cmr.appId IN ( 0, #{appId}) ")
    @Results(id = "eventAndColumnInfo", value = {
            @Result(property = "metricDirId", column = "metricDirId", id = true),
            @Result(property = "rootEvent", column = "rootEvent"),
            @Result(property = "eventId", column = "eventId"),
            @Result(property = "eventName", column = "eventName"),
            @Result(property = "eventLabel", column = "eventLabel"),
            @Result(property = "eventType", column = "eventType"),
            @Result(property = "columnId", column = "columnId"),
            @Result(property = "columnName", column = "columnName"),
            @Result(property = "columnLabel", column = "columnLabel"),
            @Result(property = "columnType", column = "columnType"),
            @Result(property = "columnColumn", column = "columnColumn"),
            @Result(property = "columnTable", column = "columnTable"),
            @Result(property = "inputModelId", column = "inputModelId")
    })
    List<EventAndColumnInfo> findAllByApp(@Param(value = "appId") Long appId,
            @Param(value = "type") String type);

    /**
     * getOne
     *
     * @param id:
     * @Author: Mfrain
     * @Date: 2021/4/21 3:24 下午
     * @return: com.inke.compass.metadata.model.CpMdecaRelation
     */
    @Select(value = "SELECT * FROM cp_mdeca_relation where metricDirId = #{id}")
    @Results(id = "cp_mdeca_relation_one", value = {
            @Result(property = "metricDirId", column = "metricDirId", id = true),
            @Result(property = "eventId", column = "eventId"),
            @Result(property = "columnId", column = "columnId"),
            @Result(property = "rootEvent", column = "rootEvent"),
            @Result(property = "eventInfo", column = "eventInfo"),
            @Result(property = "cacheData", column = "cacheData")
    })
    CpMdecaRelation getOne(@Param(value = "id") long id);

    /**
     * getByEventId
     *
     * @param id:
     * @Author: Mfrain
     * @Date: 2021/4/28 1:55 上午
     * @return: java.util.List<com.inke.compass.metadata.model.CpMdecaRelation>
     */
    @Select(value = "SELECT * FROM cp_mdeca_relation where eventId = #{id}")
    @Results(id = "cp_mdeca_relation_by_eventid", value = {
            @Result(property = "metricDirId", column = "metricDirId", id = true),
            @Result(property = "eventId", column = "eventId"),
            @Result(property = "columnId", column = "columnId"),
            @Result(property = "rootEvent", column = "rootEvent"),
            @Result(property = "eventInfo", column = "eventInfo"),
            @Result(property = "cacheData", column = "cacheData")
    })
    List<CpMdecaRelation> getByEventId(@Param(value = "id") long id);

    /**
     * deleteById
     *
     * @param id:
     * @Author: Mfrain
     * @Date: 2021/4/21 3:25 下午
     * @return: void
     */
    @Delete("<script>" +
            "delete from cp_mdeca_relation " +
            " where metricDirId = #{id}" +
            "</script>")
    void deleteById(@Param(value = "id") long id);
}

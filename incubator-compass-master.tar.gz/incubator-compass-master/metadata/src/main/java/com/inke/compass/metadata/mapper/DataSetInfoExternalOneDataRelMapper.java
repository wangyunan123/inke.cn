package com.inke.compass.metadata.mapper;

import com.inke.compass.metadata.model.DataSetInfoExternalOneDataRel;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

public interface DataSetInfoExternalOneDataRelMapper
{
    @Insert(value = "<script>" +
            "INSERT INTO data_set_info_external_one_data_rel (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"rel.dataSetInfoId != null\" >`data_set_info_id`,</if>" +
            "   <if test=\"rel.dataSetExternalOneDataId != null\" >`data_set_external_one_data_id`,</if>" +
            "</trim>) " +
            "VALUES (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"rel.dataSetInfoId != null\" >#{rel.dataSetInfoId},</if>" +
            "   <if test=\"rel.dataSetExternalOneDataId != null\" >#{rel.dataSetExternalOneDataId},</if>" +
            "</trim>)" +
            "</script>")
    @Options(useGeneratedKeys = true, keyProperty = "rel.id", keyColumn = "id")
    void save(@Param(value = "rel") DataSetInfoExternalOneDataRel rel);

    @Select(value = "SELECT * FROM data_set_info_external_one_data_rel WHERE data_set_info_id = #{data_set_info_id} AND deleted = 0")
    @Results(id = "find_external_onedata_by_id", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "dataSetInfoId", column = "data_set_info_id"),
            @Result(property = "dataSetExternalOneDataId", column = "data_set_external_one_data_id"),
            @Result(property = "createTime", column = "create_time"),
            @Result(property = "updateTime", column = "update_time"),
            @Result(property = "deleted", column = "deleted")
    })
    DataSetInfoExternalOneDataRel findByDataSetInfoId(@Param(value = "data_set_info_id") Long id);

    @Select(value = "SELECT * FROM data_set_info_external_one_data_rel WHERE data_set_external_one_data_id = #{external_one_data_id} AND deleted = 0")
    @Results(id = "find_external_onedata_by_external_one_data_id", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "dataSetInfoId", column = "data_set_info_id"),
            @Result(property = "dataSetExternalOneDataId", column = "data_set_external_one_data_id"),
            @Result(property = "createTime", column = "create_time"),
            @Result(property = "updateTime", column = "update_time"),
            @Result(property = "deleted", column = "deleted")
    })
    DataSetInfoExternalOneDataRel findByExternalOneDataId(@Param(value = "external_one_data_id") Long externalOneDataId);

    @Update(value = "UPDATE `data_set_info_external_one_data_rel` SET deleted = 1 WHERE id = #{id}")
    void delete(@Param(value = "id") Long id);
}

package com.inke.compass.metadata.mapper;

import com.inke.compass.metadata.model.CpMetadata;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

public interface CpMetadataMapper
{
    @Insert(value = "<script>" +
            "INSERT INTO cp_metadata(<trim prefix=\"\" suffixOverrides=\",\">" +
            "<if test=\"md.name != null\">`name`,</if>" +
            "<if test=\"md.description != null\">`description`,</if>" +
            "<if test=\"md.databaseName != null\">`database_name`,</if>" +
            "<if test=\"md.tableName != null\">`table_name`,</if>" +
            "<if test=\"md.cycle != null\">`cycle`,</if>" +
            "<if test=\"md.check != null\">`check`,</if>" +
            "<if test=\"md.autoRecovery != null\">`auto_recovery`,</if>" +
            "<if test=\"md.monitor != null\">`monitor`,</if>" +
            "<if test=\"md.lastDate != null\">`last_date`,</if>" +
            "<if test=\"md.retentionTime != null\">`retention_time`,</if>" +
            "<if test=\"md.createUser != null\">`create_user`,</if>" +
            "<if test=\"md.active != null\">`active`,</if>" +
            "</trim>) " +
            "VALUES (<trim prefix=\"\" suffixOverride=\",\">" +
            "<if test=\"md.name != null\">#{md.name},</if>" +
            "<if test=\"md.description != null\">#{md.description},</if>" +
            "<if test=\"md.databaseName != null\">#{md.databaseName},</if>" +
            "<if test=\"md.tableName != null\">#{md.tableName},</if>" +
            "<if test=\"md.cycle != null\">#{md.cycle},</if>" +
            "<if test=\"md.check != null\">#{md.check},</if>" +
            "<if test=\"md.autoRecovery != null\">#{md.autoRecovery},</if>" +
            "<if test=\"md.monitor != null\">#{md.monitor},</if>" +
            "<if test=\"md.lastDate != null\">#{md.lastDate},</if>" +
            "<if test=\"md.retentionTime != null\">#{md.retentionTime},</if>" +
            "<if test=\"md.createUser != null\">#{md.createUser},</if>" +
            "<if test=\"md.active != null\">#{md.active},</if>" +
            "</trim>)" +
            "</script>")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    void save(@Param(value = "md") CpMetadata md);

    @Update(value = "<script>" +
            "UPDATE cp_metadata" +
            "<set>" +
            "   <if test=\"md.name != null\">" +
            "       name = #{md.name}," +
            "   </if>" +
            "   <if test=\"md.description != null\">" +
            "       description = #{md.description}," +
            "   </if>" +
            "   <if test=\"md.databaseName != null\">" +
            "       databaseName = #{md.databaseName}," +
            "   </if>" +
            "   <if test=\"md.tableName != null\">" +
            "       tableName = #{md.tableName}," +
            "   </if>" +
            "   <if test=\"md.cycle != null\">" +
            "       cycle = #{md.cycle}," +
            "   </if>" +
            "   <if test=\"md.check != null\">" +
            "       check = #{md.check}," +
            "   </if>" +
            "   <if test=\"md.autoRecovery != null\">" +
            "       autoRecovery = #{md.autoRecovery}," +
            "   </if>" +
            "   <if test=\"md.monitor != null\">" +
            "       monitor = #{md.monitor}," +
            "   </if>" +
            "   <if test=\"md.lastDate != null\">" +
            "       lastDate = #{md.lastDate}," +
            "   </if>" +
            "   <if test=\"md.retentionTime != null\">" +
            "       retentionTime = #{md.retentionTime}," +
            "   </if>" +
            "   <if test=\"md.createUser != null\">" +
            "       createUser = #{md.createUser}," +
            "   </if>" +
            "   <if test=\"md.active != null\">" +
            "       active = #{md.active}," +
            "   </if>" +
            "</set>)" +
            "WHERE id = #{md.id}" +
            "</script>")
    void update(@Param(value = "md") CpMetadata md);

    @Select(value = "SELECT * FROM cp_metadata WHERE id = #{id}")
    @Results(id = "get_md_by_id", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "name", column = "name"),
            @Result(property = "description", column = "description"),
            @Result(property = "databaseName", column = "database_name"),
            @Result(property = "tableName", column = "table_name"),
            @Result(property = "cycle", column = "cycle"),
            @Result(property = "check", column = "check"),
            @Result(property = "autoRecovery", column = "auto_recovery"),
            @Result(property = "monitor", column = "monitor"),
            @Result(property = "lastDate", column = "lastDate"),
            @Result(property = "retentionTime", column = "retention_time"),
            @Result(property = "createUser", column = "create_user"),
            @Result(property = "active", column = "active"),
            @Result(property = "createTime", column = "create_time"),
            @Result(property = "updateTime", column = "update_time"),
    })
    CpMetadata getById(@Param(value = "id") long id);
}

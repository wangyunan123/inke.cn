package com.inke.compass.metadata.form;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <p> @Description :  </p>
 * <p> @incubator-compass </p>
 * <p> @Author : <a href="mailTo:mfr1339941169@qq.com">Mfrain</a>  </p>
 * <p> @Create Time : 2021/7/15 9:07 下午 </p>
 * <p> @Version : 1.0 </p>
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ColumnV0
{
    private long columnId;
    private String name;
    private String dataType;
}

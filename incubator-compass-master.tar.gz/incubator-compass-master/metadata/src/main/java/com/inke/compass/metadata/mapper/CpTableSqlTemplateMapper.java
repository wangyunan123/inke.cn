package com.inke.compass.metadata.mapper;

import com.inke.compass.metadata.model.CpTableSqlTemplate;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

/**
 * <p> @Description : 指标字典目录操作mapper </p>
 * <p> @incubator-compass </p>
 * <p> @Author : Mfrain </p>
 * <p> @Create Time : 2021/4/27 4:01 下午 </p>
 * <p> @Author Email: <a href="mailTo:mfr1339941169@qq.com">Mfrain</a> </p>
 * <p> @Version : 1.0 </p>
 */
public interface CpTableSqlTemplateMapper
{
    /**
     * <font color="yellow">isnert</font>
     *
     * @param ctst obj
     * @Author: Mfrain
     * @Date: 2021/4/27 5:53 下午
     * @return: void
     */
    @Insert(value = "<script>" +
            "INSERT INTO cp_table_sql_template (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"ctst.name != null\" >`name`,</if>" +
            "   <if test=\"ctst.template != null\" >`template`,</if>" +
            "   <if test=\"ctst.desc != null\" >`desc`,</if>" +
            "   <if test=\"ctst.creator != null\" >`creator`,</if>" +
            "   <if test=\"ctst.type != null\" >`type`,</if>" +
            "</trim>) " +
            "VALUES (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"ctst.name != null\" >#{ctst.name},</if>" +
            "   <if test=\"ctst.template != null\" >#{ctst.template},</if>" +
            "   <if test=\"ctst.desc != null\" >#{ctst.desc},</if>" +
            "   <if test=\"ctst.creator != null\" >#{ctst.creator},</if>" +
            "   <if test=\"ctst.type != null\" >#{ctst.type},</if>" +
            "</trim>)" +
            "</script>")
    @Options(useGeneratedKeys = true, keyProperty = "ctst.id", keyColumn = "id")
    void save(@Param(value = "ctst") CpTableSqlTemplate ctst);

    /**
     * <font color="yellow">update</font>
     *
     * @param ctst obj
     * @Author: Mfrain
     * @Date: 2021/4/27 5:53 下午
     * @return: void
     */
    @Update("<script>" +
            "update cp_table_sql_template" +
            "    <set >" +
            "      <if test=\"ctst.name != null\" >" +
            "        name = #{ctst.name}," +
            "      </if>" +
            "      <if test=\"ctst.template != null\" >" +
            "        template = #{ctst.template}," +
            "      </if>" +
            "      <if test=\"ctst.desc != null\" >" +
            "        desc = #{ctst.desc}," +
            "      </if>" +
            "      <if test=\"ctst.creator != null\" >" +
            "        creator = #{ctst.creator}," +
            "      </if>" +
            "      <if test=\"ctst.type != null\" >" +
            "        type = #{ctst.type}," +
            "      </if>" +
            "    </set>" +
            "    where id = #{ctst.id}" +
            "</script>")
    void update(@Param(value = "ctst") CpTableSqlTemplate ctst);

    /**
     * <font color="yellow">findAll</font>
     *
     * @Author: Mfrain
     * @Date: 2021/4/27 6:05 下午
     * @return: java.util.List<com.inke.compass.metadata.model.CpTableSqlTemplate>
     */
    @Select(value = "SELECT * FROM cp_table_sql_template")
    @Results(id = "cp_table_sql_template_all", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "appId", column = "appId"),
            @Result(property = "name", column = "name"),
            @Result(property = "label", column = "label"),
            @Result(property = "type", column = "type"),
            @Result(property = "owner", column = "owner"),
            @Result(property = "createTime", column = "create_time"),
            @Result(property = "updateTime", column = "update_time"),
            @Result(property = "rootNode", column = "rootNode"),
            @Result(property = "visible", column = "visible"),
            @Result(property = "server", column = "server"),
            @Result(property = "adminNode", column = "adminNode")
    })
    List<CpTableSqlTemplate> findAll();

    @Select(value = "SELECT * FROM cp_table_sql_template " +
            "WHERE name = #{name} " +
            "ORDER BY type")
    @ResultMap(value = "cp_table_sql_template_all")
    List<CpTableSqlTemplate> findByName(@Param(value = "name") String name);

    /**
     * <font color="yellow">getCtstById</font>
     *
     * @param id
     * @Author: Mfrain
     * @Date: 2021/4/27 6:07 下午
     * @return: com.inke.compass.metadata.model.CpTableSqlTemplate
     */
    @Select(value = "SELECT * FROM cp_table_sql_template  where id = #{id}")
    @Results(id = "get_ctst_by_id", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "name", column = "name"),
            @Result(property = "template", column = "template"),
            @Result(property = "desc", column = "desc"),
            @Result(property = "creator", column = "creator"),
            @Result(property = "createTime", column = "create_time"),
            @Result(property = "updateTime", column = "update_time"),
            @Result(property = "type", column = "type")
    })
    CpTableSqlTemplate getCtstById(@Param(value = "id") long id);

    /**
     * <font color="yellow">getCtstByName</font>
     *
     * @param name
     * @Author: Mfrain
     * @Date: 2021/4/27 6:08 下午
     * @return: com.inke.compass.metadata.model.CpTableSqlTemplate
     */
    @Select(value = "SELECT * FROM cp_table_sql_template  where name = #{name}")
    @Results(id = "get_ctst_by_name", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "name", column = "name"),
            @Result(property = "template", column = "template"),
            @Result(property = "desc", column = "desc"),
            @Result(property = "creator", column = "creator"),
            @Result(property = "createTime", column = "create_time"),
            @Result(property = "updateTime", column = "update_time"),
            @Result(property = "type", column = "type")
    })
    CpTableSqlTemplate getCtstByName(@Param(value = "name") String name);

    /**
     * <font color="yellow">getCtstsByType</font>
     *
     * @param type
     * @Author: Mfrain
     * @Date: 2021/4/27 6:09 下午
     * @return: java.util.List<com.inke.compass.metadata.model.CpTableSqlTemplate>
     */
    @Select(value = "SELECT * FROM cp_table_sql_template  where type = #{type}")
    @Results(id = "get_ctsts_by_type", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "name", column = "name"),
            @Result(property = "template", column = "template"),
            @Result(property = "desc", column = "desc"),
            @Result(property = "creator", column = "creator"),
            @Result(property = "createTime", column = "create_time"),
            @Result(property = "updateTime", column = "update_time"),
            @Result(property = "type", column = "type")
    })
    List<CpTableSqlTemplate> getCtstsByType(@Param(value = "type") String type);
}

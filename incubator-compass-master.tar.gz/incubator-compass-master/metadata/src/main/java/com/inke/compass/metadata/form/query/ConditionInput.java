package com.inke.compass.metadata.form.query;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * <p> incubator-compass</p>
 * <p> Description :  </p>
 * <p> Author : 24k-xiao-shan </p>
 * <p> Version :  </p>
 * <p> Create Time :  2021-01-19 11:06:15 </p>
 * <p> Author Email: <a href="mailTo:1912079423@qq.com">gaojunshan</a> </p>
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ConditionInput
        implements Serializable
{
    private String column;
    private String expression;
    private List<String> values;
    private List<String> value;
    private Long eventId;
}

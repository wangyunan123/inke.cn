package com.inke.compass.metadata.form.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <p> incubator-compass</p>
 * <p> Description :  </p>
 * <p> Author : 24k-xiao-shan </p>
 * <p> Version :  </p>
 * <p> Create Time :  2021-06-03 16:55:57 </p>
 * <p> Author Email: <a href="mailTo:1912079423@qq.com">gaojunshan</a> </p>
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Field
{
    private String fieldName;
    private String fieldType;
    private String fieldAlias;
}

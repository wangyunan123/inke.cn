package com.inke.compass.metadata.databusi;

import com.google.gson.GsonBuilder;
import com.google.gson.annotations.SerializedName;
import io.edurt.gcm.common.jdk.ObjectBuilder;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Arrays;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class CreateSchedulerRequest {
    private String email;
    private String engine;
    private String sql;
    @SerializedName(value = "crontab_expression")
    private CrontabExpression cronExpr;
    private String name;

    public final static String taskNamePrefix = "olap_task_";
    public final static String schedulerNamePrefix = "olap_sched_";

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    static public class CrontabExpression {
        private String month;
        private String week;
        private String day;
        private String hour;
        private String minute;
        private String second;

        public static CrontabExpression buildDailyExpression(String hour, String minute, String second) {
            return ObjectBuilder.of(CrontabExpression::new).
                    with(CrontabExpression::setMonth, "*").
                    with(CrontabExpression::setWeek, "?").
                    with(CrontabExpression::setDay, "*").
                    with(CrontabExpression::setHour, hour).
                    with(CrontabExpression::setMinute, minute).
                    with(CrontabExpression::setSecond, second).
                    build();
        }

        public static CrontabExpression buildWeeklyExpression(Integer weekNum, String hour, String minute, String second) {
            return ObjectBuilder.of(CrontabExpression::new).
                    with(CrontabExpression::setMonth, "*").
                    with(CrontabExpression::setWeek, Arrays.asList("MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN").get(weekNum-1)).
                    with(CrontabExpression::setDay, "?").
                    with(CrontabExpression::setHour, hour).
                    with(CrontabExpression::setMinute, minute).
                    with(CrontabExpression::setSecond, second).
                    build();
        }

        public static CrontabExpression buildWeeklyExpression(String weekAbbr, String hour, String minute, String second) {
            return ObjectBuilder.of(CrontabExpression::new).
                    with(CrontabExpression::setMonth, "*").
                    with(CrontabExpression::setWeek, weekAbbr).
                    with(CrontabExpression::setDay, "*").
                    with(CrontabExpression::setHour, hour).
                    with(CrontabExpression::setMinute, minute).
                    with(CrontabExpression::setSecond, second).
                    build();
        }

        public static CrontabExpression buildMonthlyExpression(String day, String hour, String minute, String second) {
            return ObjectBuilder.of(CrontabExpression::new).
                    with(CrontabExpression::setMonth, "*").
                    with(CrontabExpression::setWeek, "*").
                    with(CrontabExpression::setDay, day).
                    with(CrontabExpression::setHour, hour).
                    with(CrontabExpression::setMinute, minute).
                    with(CrontabExpression::setSecond, second).
                    build();
        }
        public static CrontabExpression buildHourlyExpression(String hour, String minute, String second) {
            return ObjectBuilder.of(CrontabExpression::new).
                    with(CrontabExpression::setMonth, "*").
                    with(CrontabExpression::setWeek, "?").
                    with(CrontabExpression::setDay, "*").
                    with(CrontabExpression::setHour, String.format("*/%s", hour)).
                    with(CrontabExpression::setMinute, minute).
                    with(CrontabExpression::setSecond, second).
                    build();
        }
        public static CrontabExpression buildMinutelyExpression(String minute, String second) {
            return ObjectBuilder.of(CrontabExpression::new).
                    with(CrontabExpression::setMonth, "*").
                    with(CrontabExpression::setWeek, "?").
                    with(CrontabExpression::setDay, "*").
                    with(CrontabExpression::setHour, "*").
                    with(CrontabExpression::setMinute, String.format("*/%s", minute)).
                    with(CrontabExpression::setSecond, second).
                    build();
        }
    }

    public String toJson() {
        // json builder
        GsonBuilder gb = new GsonBuilder();
        return gb.create().toJson(this);
    }
}

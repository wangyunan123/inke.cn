package com.inke.compass.metadata.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * hive表信息
 *
 * @author Mfrain
 * @version 1.0
 * @since 2021-06-30
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CpAllHiveTable
        implements Serializable
{
    private static final long serialVersionUID = 1478620655471062236L;


    private String app;
    private String dbName;
    private String tbName;
    private String isImport;







}



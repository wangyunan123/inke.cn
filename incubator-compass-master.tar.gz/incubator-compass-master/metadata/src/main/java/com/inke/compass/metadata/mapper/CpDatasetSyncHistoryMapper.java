package com.inke.compass.metadata.mapper;

import com.inke.compass.metadata.info.DatasetHistoryInfo;
import com.inke.compass.metadata.model.CpDatasetSyncHistory;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.ResultType;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

public interface CpDatasetSyncHistoryMapper
{
//增加数据同步记录去重的不逻辑，只按时间展示最新记录
    @Select(value =
            "SELECT a.`id`, b.`name`, a.`dataset_id`, a.`partition`, b.`start_time`, b.`end_time`, \n "+
                    "b.`create_user`, b.`status`,b.`size`, b.`total`, b.`sync_mode`, b.`type`, b.`message`\n"+
                    "from(select dataset_id,`partition`,max(id) as id \n"+
                    "from cp_dataset_sync_history where dataset_id = #{datasetId}\n"+
                    "group by dataset_id,`partition`)a \n"+
                    "left join(SELECT `id`, `name`, `dataset_id`, `partition`, `start_time`, `end_time`, \n"+
                    "`create_user`, `status`, `size`, `total`, `sync_mode`, `type`, `message`  \n"+
                    "from cp_dataset_sync_history where dataset_id = #{datasetId})b\n"+
                    "on a.`partition`=b.`partition`\n"+
                    "and a.id=b.id order by a.`partition` desc" )
    @Results(id = "dataset", value = {
            @Result(property = "id", column = "id"),
            @Result(property = "name", column = "name"),
            @Result(property = "datasetId", column = "dataset_id"),
            @Result(property = "partition", column = "partition"),
            @Result(property = "startTime", column = "start_time"),
            @Result(property = "endTime", column = "end_time"),
            @Result(property = "createUser", column = "create_user"),
            @Result(property = "status", column = "status"),
            @Result(property = "size", column = "size"),
            @Result(property = "total", column = "total"),
            @Result(property = "syncMode", column = "sync_mode"),
            @Result(property = "type", column = "type"),
            @Result(property = "message", column = "message")
    })
    List<CpDatasetSyncHistory> findAllByDatasetId(@Param(value = "datasetId") Long datasetId);

    @Select(value = "SELECT * FROM cp_dataset_sync_history WHERE id = #{id}")
    @ResultMap(value = "dataset_by_conditions")
    CpDatasetSyncHistory findById(@Param(value = "id") Long id);

    @Select(value = "<script>" +
            "SELECT `id`, `name`, `dataset_id`, `partition`, `start_time`, `end_time`, `create_user`, `status`, `size`, `total`, `sync_mode`, `type`, `message`, `external_extra_info` " +
            "FROM cp_dataset_sync_history " +
            "WHERE dataset_id = #{datasetId} " +
            "<trim prefix=\"\" suffixOverrides=\",\">" +
            "<if test=\"empty != null and empty\" >" +
            "  AND coalesce(`total`, 0) = 0 " +
            "</if>" +
            "<if test=\"empty != null and !empty\" >" +
            "  AND coalesce(`total`, 0) &gt; 0 " +
            "</if>" +
            "<if test=\"statuses != null and statuses.size() > 0\" >" +
            "  AND `status` IN " +
            "   <foreach item=\"item\" index=\"i\" collection=\"statuses\"" +
            "       open=\"(\" separator=\",\" close=\")\">" +
            "       #{item}" +
            "   </foreach>" +
            "</if>" +
            "<if test=\"partitionFrom != null and partitionFrom.length() > 0\" >" +
            "  AND `partition` &gt;= #{partitionFrom} " +
            "</if>" +
            "<if test=\"partitionTo != null and partitionTo.length() > 0\" >" +
            "  AND `partition` &lt;= #{partitionTo} " +
            "</if>" +
            "</trim>" +
            "ORDER BY `name` DESC " +
            "LIMIT #{offset}, #{size}" +
            "</script>")
    @Results(id = "dataset_by_conditions", value = {
            @Result(property = "id", column = "id"),
            @Result(property = "name", column = "name"),
            @Result(property = "datasetId", column = "dataset_id"),
            @Result(property = "partition", column = "partition"),
            @Result(property = "startTime", column = "start_time"),
            @Result(property = "endTime", column = "end_time"),
            @Result(property = "createUser", column = "create_user"),
            @Result(property = "status", column = "status"),
            @Result(property = "size", column = "size"),
            @Result(property = "total", column = "total"),
            @Result(property = "syncMode", column = "sync_mode"),
            @Result(property = "type", column = "type"),
            @Result(property = "message", column = "message"),
            @Result(property = "isImport", column = "isImport"),
            @Result(property = "externalExtraInfo", column = "external_extra_info")
    })
    List<CpDatasetSyncHistory> findByConditions(
            @Param(value = "datasetId") Long datasetId,
            @Param(value = "statuses") List<String> statuses,
            @Param(value = "empty") Boolean isDataEmpty,
            @Param(value = "partitionFrom") String partitionFrom,
            @Param(value = "partitionTo") String partitionTo,
            @Param(value = "offset") int offset,
            @Param(value = "size") int size);

    @Select(value = "<script>" +
            "SELECT COUNT(1) " +
            "FROM cp_dataset_sync_history " +
            "WHERE dataset_id = #{datasetId} " +
            "<trim prefix=\"\" suffixOverrides=\",\">" +
            "<if test=\"empty != null and empty\" >" +
            "  AND coalesce(`total`, 0) = 0 " +
            "</if>" +
            "<if test=\"empty != null and !empty\" >" +
            "  AND coalesce(`total`, 0) > 0 " +
            "</if>" +
            "<if test=\"statuses != null and statuses.size() > 0\" >" +
            "  AND `status` IN " +
            "   <foreach item=\"item\" index=\"i\" collection=\"statuses\"" +
            "       open=\"(\" separator=\",\" close=\")\">" +
            "       #{item}" +
            "   </foreach>" +
            "</if>" +
            "<if test=\"partitionFrom != null and partitionFrom.length() > 0\" >" +
            "  AND `partition` &gt;= #{partitionFrom} " +
            "</if>" +
            "<if test=\"partitionTo != null and partitionTo.length() > 0\" >" +
            "  AND `partition` &lt;= #{partitionTo} " +
            "</if>" +
            "</trim>" +
            "</script>")
    @ResultType(value = Integer.class)
    Integer countByConditions(
            @Param(value = "datasetId") Long datasetId,
            @Param(value = "statuses") List<String> statuses,
            @Param(value = "empty") Boolean isDataEmpty,
            @Param(value = "partitionFrom") String partitionFrom,
            @Param(value = "partitionTo") String partitionTo);

    //导入hive库表，更新数据库
    @Update("<script>" +
            "update cp_dataset_sync_history" +
            "    <set >" +
            "      <if test=\"ctst.name != null\" >" +
            "        name = #{ctst.name}," +
            "      </if>" +
            "      <if test=\"ctst.datasetId != null\" >" +
            "        dataset_id = #{ctst.datasetId}," +
            "      </if>" +
            "      <if test=\"ctst.partition != null\" >" +
            "        `partition` = #{ctst.partition}," +
            "      </if>" +
            "      <if test=\"ctst.startTime != null\" >" +
            "        start_time = #{ctst.startTime}," +
            "      </if>" +
            "      <if test=\"ctst.endTime != null\" >" +
            "        end_time = #{ctst.endTime}," +
            "      </if>" +
            "      <if test=\"ctst.createUser != null\" >" +
            "        create_user = #{ctst.createUser}," +
            "      </if>" +
            "      <if test=\"ctst.status != null\" >" +
            "        status = #{ctst.status}," +
            "      </if>" +
            "      <if test=\"ctst.size != null\" >" +
            "        size = #{ctst.size}," +
            "      </if>" +
            "      <if test=\"ctst.total != null\" >" +
            "        total = #{ctst.total}," +
            "      </if>" +
            "      <if test=\"ctst.syncMode != null\" >" +
            "        sync_mode = #{ctst.syncMode}," +
            "      </if>" +
            "      <if test=\"ctst.type != null\" >" +
            "        `type` = #{ctst.type}," +
            "      </if>" +
            "      <if test=\"ctst.externalExtraInfo != null\" >" +
            "        `external_extra_info` = #{ctst.externalExtraInfo}," +
            "      </if>" +
            "      <if test=\"ctst.message != null\" >" +
            "        `message` = #{ctst.message}," +
            "      </if>" +
            "    </set>" +
            "    where id = #{ctst.id}" +
            "</script>")
    void update(@Param(value = "ctst") CpDatasetSyncHistory ctst);

    //根据传入的appName去查询当下的同步的表
    @Select(value = "select a.appName,a.dbName,a.tbName,b.create_user,b.status,b.start_time,b.end_time\n " +
            "FROM (SELECT appName,dbName,tbName,concat(dbName,'.',tbName) as res,isImport FROM cp_hive_metadata)a \n" +
            "left join cp_dataset_sync_history as b \n" +
            "on b.name=a.res\n " +
            "WHERE a.appName = #{appName}\n " +
            "AND a.isImport>0 "
    )
    @Results(id = "datasetsync", value = {
            @Result(property = "appName", column = "appName"),
            @Result(property = "dbName", column = "dbName"),
            @Result(property = "tbName", column = "tbName"),
            @Result(property = "create_user", column = "create_user"),
            @Result(property = "status", column = "status"),
            @Result(property = "start_time", column = "start_time"),
            @Result(property = "end_time", column = "end_time")
    })
    List<CpDatasetSyncHistory> findAllByApp(@Param(value = "appName") String appName);

    //查询当前库下的所有hive表，标注是否完成导入的状态

    @Select(value = "select * FROM cp_hive_metadata WHERE appName = #{appName}\n ")
    @Results(id = "allhivetable", value = {
            @Result(property = "id", column = "id"),
            @Result(property = "name", column = "name"),
            @Result(property = "datasetId", column = "dataset_id"),
            @Result(property = "partition", column = "partition"),
            @Result(property = "startTime", column = "start_time"),
            @Result(property = "endTime", column = "end_time"),
            @Result(property = "createUser", column = "create_user"),
            @Result(property = "status", column = "status"),
            @Result(property = "size", column = "size"),
            @Result(property = "total", column = "total"),
            @Result(property = "syncMode", column = "sync_mode"),
            @Result(property = "type", column = "type"),
            @Result(property = "isImport", column = "isImport"),
    })
    List<CpDatasetSyncHistory> findAllHiveTable(@Param(value = "appName") String appName);

    @Delete("<script>" +
            "DELETE FROM cp_dataset_sync_history " +
            "WHERE dataset_id = #{dataSetId}" +
            "</script>")
    void deleteAllByDataSetId(@Param(value = "dataSetId") Long dataSetId);

    @Insert(value = "<script>" +
            "INSERT INTO cp_dataset_sync_history (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"info.name != null\" >`name`,</if>" +
            "   <if test=\"info.datasetId != null\" >`dataset_id`,</if>" +
            "   <if test=\"info.partition != null\" >`partition`,</if>" +
            "   <if test=\"info.startTime != null\" >`start_time`,</if>" +
            "   <if test=\"info.endTime != null\" >`end_time`,</if>" +
            "   <if test=\"info.createUser != null\" >`create_user`,</if>" +
            "   <if test=\"info.status != null\" >`status`,</if>" +
            "   <if test=\"info.size != null\" >`size`,</if>" +
            "   <if test=\"info.total != null\" >`total`,</if>" +
            "   <if test=\"info.syncMode != null\" >`sync_mode`,</if>" +
            "   <if test=\"info.type != null\" >`type`,</if>" +
            "   <if test=\"info.message != null\" >`message`,</if>" +
            "   <if test=\"info.externalExtraInfo != null\" >`external_extra_info`,</if>" +
            "</trim>) " +
            "VALUES (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"info.name != null\" >#{info.name},</if>" +
            "   <if test=\"info.datasetId != null\" >#{info.datasetId},</if>" +
            "   <if test=\"info.partition != null\" >#{info.partition},</if>" +
            "   <if test=\"info.startTime != null\" >#{info.startTime},</if>" +
            "   <if test=\"info.endTime != null\" >#{info.endTime},</if>" +
            "   <if test=\"info.createUser != null\" >#{info.createUser},</if>" +
            "   <if test=\"info.status != null\" >#{info.status},</if>" +
            "   <if test=\"info.size != null\" >#{info.size},</if>" +
            "   <if test=\"info.total != null\" >#{info.total},</if>" +
            "   <if test=\"info.syncMode != null\" >#{info.syncMode},</if>" +
            "   <if test=\"info.type != null\" >#{info.type},</if>" +
            "   <if test=\"info.message != null\" >#{info.message},</if>" +
            "   <if test=\"info.externalExtraInfo != null\" >#{info.externalExtraInfo},</if>" +
            "</trim>)" +
            "</script>")
    @Options(useGeneratedKeys = true, keyProperty = "info.id", keyColumn = "id")
    void save(@Param(value = "info") CpDatasetSyncHistory info);

    @Insert(value = "<script>" +
            "INSERT INTO cp_dataset_sync_history (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"info.name != null\" >`name`,</if>" +
            "   <if test=\"info.datasetId != null\" >`dataset_id`,</if>" +
            "   <if test=\"info.partition != null\" >`partition`,</if>" +
            "   <if test=\"info.startTime != null\" >`start_time`,</if>" +
            "   <if test=\"info.endTime != null\" >`end_time`,</if>" +
            "   <if test=\"info.createUser != null\" >`create_user`,</if>" +
            "   <if test=\"info.status != null\" >`status`,</if>" +
            "   <if test=\"info.size != null\" >`size`,</if>" +
            "   <if test=\"info.total != null\" >`total`,</if>" +
            "   <if test=\"info.syncMode != null\" >`sync_mode`,</if>" +
            "   <if test=\"info.type != null\" >`type`,</if>" +
            "   <if test=\"info.message != null\" >`message`,</if>" +
            "</trim>) " +
            "VALUES (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"info.name != null\" >#{info.name},</if>" +
            "   <if test=\"info.datasetId != null\" >#{info.datasetId},</if>" +
            "   <if test=\"info.partition != null\" >#{info.partition},</if>" +
            "   <if test=\"info.startTime != null\" >#{info.startTime},</if>" +
            "   <if test=\"info.endTime != null\" >#{info.endTime},</if>" +
            "   <if test=\"info.createUser != null\" >#{info.createUser},</if>" +
            "   <if test=\"info.status != null\" >#{info.status},</if>" +
            "   <if test=\"info.size != null\" >#{info.size},</if>" +
            "   <if test=\"info.total != null\" >#{info.total},</if>" +
            "   <if test=\"info.syncMode != null\" >#{info.syncMode},</if>" +
            "   <if test=\"info.type != null\" >#{info.type},</if>" +
            "   <if test=\"info.message != null\" >#{info.message},</if>" +
            "</trim>)" +
            "</script>")
    @Options(useGeneratedKeys = true, keyProperty = "info.id", keyColumn = "id")
    void saveHistory(@Param(value = "info") DatasetHistoryInfo info);

    //增加查看文件夹初始化的文件件id
    @Select(value = "SELECT id FROM cp_dataset_info WHERE app = #{dataSetId} and label like '%_Flowwidthtable%' ")
    String folderId(@Param(value = "app") String app);

}

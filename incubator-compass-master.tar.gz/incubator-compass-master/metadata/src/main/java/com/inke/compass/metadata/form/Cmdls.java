/**
 * Copyright 2021 json.cn
 */
package com.inke.compass.metadata.form;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Auto-generated: 2021-07-08 4:56:53
 *
 * @author json.cn (i@json.cn)
 * @website http://www.json.cn/java2pojo/
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Cmdls
{

    private int id;
    private int appId;
    private String name;
    private String label;
    private String type;
    private boolean visible;
    private String owner;
    private boolean adminNode;
    private int rootNode;
    private int active;
    private String tableType;
    private List<Cmdls> cmdls;
}
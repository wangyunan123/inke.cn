package com.inke.compass.metadata.form;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DatasetTableInfo {
    private long datasetId;
    private String dbName;
    private String tableName;
    private List<ColumnV0> columns;
    private Long eventId;
}

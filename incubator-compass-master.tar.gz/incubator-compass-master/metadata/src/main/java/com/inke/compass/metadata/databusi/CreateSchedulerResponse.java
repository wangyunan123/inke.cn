package com.inke.compass.metadata.databusi;

import com.google.gson.GsonBuilder;
import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class CreateSchedulerResponse {
    @SerializedName(value = "dm_error")
    private Integer code;
    @SerializedName(value = "error_msg")
    private String message;
    private Data data;

    @lombok.Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Data {
        private Long id;
    }

    public static CreateSchedulerResponse fromJson(String json)
    {
        // json builder
        GsonBuilder gb = new GsonBuilder();
        return gb.create().fromJson(json, CreateSchedulerResponse.class);
    }
}

package com.inke.compass.metadata.form;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Set;

/**
 * <p> incubator-compass</p>
 * <p> Description : 指标 </p>
 * <p> @Author : 24k-xiao-shan </p>
 * <p> Version : 1.0 </p>
 * <p> Create Time :  2021-01-05 09:52:32 </p>
 * <p> Author Email: <a href="mailTo:1912079423@qq.com">gaojunshan</a> </p>
 */
@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class CpColumnForm
{
    private long id;
    private long eventId;
    private String name;
    private String column;
    private String label;
    private Long dataType;
    private String description;
    private Set<Long> express;
    private boolean visible;
    private boolean defaulted;
    private boolean deleted;
    private Long inputModel;
    private String type;
    private String content;
    private String tables;
    private Set<Long> filter;
    private String dict;
    private String condition;
}

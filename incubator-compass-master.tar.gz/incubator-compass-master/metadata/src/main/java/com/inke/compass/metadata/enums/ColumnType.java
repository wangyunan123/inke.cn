package com.inke.compass.metadata.enums;

public enum ColumnType
{
    METRIC,
    DIMENSION
}

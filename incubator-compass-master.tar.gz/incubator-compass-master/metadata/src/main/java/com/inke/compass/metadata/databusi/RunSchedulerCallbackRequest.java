package com.inke.compass.metadata.databusi;

import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RunSchedulerCallbackRequest {
    @SerializedName(value = "start_time")
    private String startTime;
    @SerializedName(value = "end_time")
    private String endTime;
    private String qid;
    private String status;
    @SerializedName(value = "scheduler_id")
    private Long schedulerId;
    @SerializedName(value = "batch_date")
    private String batchDate;
    @SerializedName(value = "scheduler_name")
    private String schedulerName;
    @SerializedName(value = "scheduler_error")
    private String schedulerError;
    @SerializedName(value = "executed_sql")
    private String executedSql;

    public boolean runSuccessfully()
    {
        return this.status.equals("success");
    }
}
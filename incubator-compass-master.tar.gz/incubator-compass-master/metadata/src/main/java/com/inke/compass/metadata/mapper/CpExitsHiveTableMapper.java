package com.inke.compass.metadata.mapper;

import com.inke.compass.metadata.model.CpDatasetSyncHistory;
import org.apache.ibatis.annotations.*;

import java.util.List;

public interface CpExitsHiveTableMapper
{

//    @Select(value = "SELECT `id`, `app`, `appId`, `dbName`" +
//            "FROM cp_hive_exits_table " +
//            "WHERE app = #{app} AND dbName = #{dbName}")
//    @Results(id = "dataset", value = {
//            @Result(property = "id", column = "id"),
//            @Result(property = "app", column = "app"),
//            @Result(property = "appId", column = "appId"),
//            @Result(property = "dbName", column = "dbName")
//    })
//    List<CpExitsHiveTable> findAllByAppDBname(@Param(value = "app") String app, @Param(value = "dbName") string dbName);
//导入hive库表，更新数据库
    @Update("<script>" +
            "update cp_dataset_sync_history" +
            "    <set >" +
            "      <if test=\"ctst.id != null\" >" +
            "        id = #{ctst.id}," +
            "      </if>" +
            "      <if test=\"ctst.name != null\" >" +
            "        name = #{ctst.name}," +
            "      </if>" +
            "      <if test=\"ctst.datasetId != null\" >" +
            "        datasetId = #{ctst.datasetId}," +
            "      </if>" +
            "      <if test=\"ctst.partition != null\" >" +
            "        partition = #{ctst.partition}," +
            "      </if>" +
            "      <if test=\"ctst.startTime != null\" >" +
            "        startTime = #{ctst.startTime}," +
            "      </if>" +
            "      <if test=\"ctst.endTime != null\" >" +
            "        endTime = #{ctst.endTime}," +
            "      </if>" +
            "      <if test=\"ctst.createUser != null\" >" +
            "        createUser = #{ctst.createUser}," +
            "      </if>" +
            "      <if test=\"ctst.status != null\" >" +
            "        status = #{ctst.status}," +
            "      </if>" +
            "      <if test=\"ctst.size != null\" >" +
            "        size = #{ctst.size}," +
            "      </if>" +
            "      <if test=\"ctst.endTime != null\" >" +
            "        endTime = #{ctst.endTime}," +
            "      </if>" +
            "      <if test=\"ctst.total != null\" >" +
            "        total = #{ctst.total}," +
            "      </if>" +
            "      <if test=\"ctst.syncMode != null\" >" +
            "        syncMode = #{ctst.syncMode}," +
            "      </if>" +
            "      <if test=\"ctst.type != null\" >" +
            "        siztypee = #{ctst.type}," +
            "      </if>" +
            "    </set>" +
            "    where id = #{ctst.id}" +
            "</script>")
    void update(@Param(value = "ctst") CpExitsHiveTableMapper ctst);

//根据传入的appName去查询当下的同步的表
    @Select(value = "select a.appName,a.dbName,a.tbName,b.create_user,b.status,b.start_time,b.end_time\n " +
            "FROM (SELECT appName,dbName,tbName,concat(dbName,'.',tbName) as res FROM cp_hive_metadata)a \n" +
            "left join cp_dataset_sync_history as b \n"+
            "on b.name=a.res\n "+
            "WHERE a.appName = #{appName} "
    )
    @Results(id = "datasetsync", value = {
            @Result(property = "appName", column = "appName"),
            @Result(property = "dbName", column = "dbName"),
            @Result(property = "tbName", column = "tbName"),
            @Result(property = "create_user", column = "create_user"),
            @Result(property = "status", column = "status"),
            @Result(property = "start_time", column = "start_time"),
           @Result(property = "end_time", column = "end_time")
    })
    List<CpDatasetSyncHistory> findAllByApp(@Param(value = "appName") String appName);

    //查询当前库下的所有hive表，标注是否完成导入的状态


}

package com.inke.compass.metadata.form.query;

import com.inke.compass.metadata.enums.Unit;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

/**
 * <p> incubator-compass</p>
 * <p> Description :  </p>
 * <p> Author : 24k-xiao-shan </p>
 * <p> Version :  </p>
 * <p> Create Time :  2021-01-19 10:45:15 </p>
 * <p> Author Email: <a href="mailTo:1912079423@qq.com">gaojunshan</a> </p>
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DeveloperBuilderInput
{
    private String dataSource;
    private String type;
    private Unit unit;
    private Map<String, Object> params;
}

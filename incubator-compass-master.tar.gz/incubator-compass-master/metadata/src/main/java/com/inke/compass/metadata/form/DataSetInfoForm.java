/**
 * Copyright 2021 json.cn
 */
package com.inke.compass.metadata.form;

import com.inke.compass.metadata.model.CpMetadataSyncHistory;
import com.inke.compass.metadata.model.CpTableColumn;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Auto-generated: 2021-07-09 16:28:56
 *
 * @author json.cn (i@json.cn)
 * @website http://www.json.cn/java2pojo/
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DataSetInfoForm
{
    private String name;
    private long eventId;
    private String tableName;
    private String appKey;
    private String tableType;
    private String owner;
    private String updater;
    private String cycle;
    private String updateTime;
    private String createTime;
    private String size;
    private String desc;
    private String backViewJson;
    private List<CpMetadataSyncHistory> history;
    private List<CpTableColumn> columnInfo;
    private Boolean parallel;
    private Integer parallelThreadNum;
    private Boolean isRealtime;
}
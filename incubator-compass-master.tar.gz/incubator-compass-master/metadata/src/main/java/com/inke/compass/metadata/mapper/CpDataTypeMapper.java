package com.inke.compass.metadata.mapper;

import com.inke.compass.metadata.model.CpDatatype;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

public interface CpDataTypeMapper
{
    @Select(value = "SELECT DISTINCT\n" +
            "\tcd.`id` AS `id`,\n" +
            "\t`name`,\n" +
            "\t`label`,\n" +
            "\t`create_time`,\n" +
            "\t`active` \n" +
            "FROM\n" +
            "\tcp_datatype AS cd\n" +
            "\tLEFT JOIN cp_cem_relation AS ccr ON cd.id = ccr.datatype_id \n" +
            "WHERE\n" +
            "\tccr.column_id = #{columnId}")
    @Results(
            id = "full",
            value = {
                    @Result(property = "id", column = "id", id = true),
                    @Result(property = "name", column = "name"),
                    @Result(property = "label", column = "label"),
                    @Result(property = "active", column = "active"),
                    @Result(property = "createTime", column = "create_time")
            })
    CpDatatype findByColumnId(@Param(value = "columnId") Long columnId);
}

package com.inke.compass.metadata.form;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Map;

/**
 * <p> @Description : 构建结果信息 </p>
 * <p> @incubator-compass </p>
 * <p> @Author : <a href="mailTo:mfr1339941169@qq.com">Mfrain</a>  </p>
 *
 * <p> @Create Time : 2021/4/23 3:03 下午 </p>
 * <p> @Version : 1.0 </p>
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BuildInfo
        implements Serializable
{
    private static final long serialVersionUID = 938524198381758872L;

    private Map<Boolean, String> transformTable;
    private Map<Boolean, String> localTable;
    private Map<Boolean, String> materializedView;
    private Map<Boolean, String> distributedTable;
    private Map<Boolean, String> loadHistoryData;
    private Map<Boolean, String> eventInfo;
    private Map<Boolean, String> columnInfo;
    private Map<Boolean, String> metricDir;
    private Long dataSetDirId;
}

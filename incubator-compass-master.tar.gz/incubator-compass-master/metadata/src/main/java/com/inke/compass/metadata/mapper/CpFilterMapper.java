package com.inke.compass.metadata.mapper;

import com.inke.compass.metadata.model.CpFilter;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface CpFilterMapper
{
    @Select(value = "SELECT\n" +
            "\tcf.`id` AS id,\n" +
            "\t`name`,\n" +
            "\t`label`,\n" +
            "\t`type`,\n" +
            "\t`create_time`,\n" +
            "\t`active` \n" +
            "FROM\n" +
            "\tcp_filter AS cf\n" +
            "\tLEFT JOIN cp_cem_relation AS ccr ON cf.id = ccr.filter_id \n" +
            "WHERE\n" +
            "\tccr.column_id = #{columnId}")
    @Results(
            id = "full",
            value = {
                    @Result(property = "id", column = "id", id = true),
                    @Result(property = "name", column = "name"),
                    @Result(property = "label", column = "label"),
                    @Result(property = "type", column = "type"),
                    @Result(property = "active", column = "active"),
                    @Result(property = "createTime", column = "create_time")
            })
    List<CpFilter> findByColumnId(@Param(value = "columnId") Long columnId);
}

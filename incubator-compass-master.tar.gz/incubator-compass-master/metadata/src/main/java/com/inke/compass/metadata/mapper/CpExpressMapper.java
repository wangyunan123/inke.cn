package com.inke.compass.metadata.mapper;

import com.inke.compass.metadata.model.CpExpress;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface CpExpressMapper
{
    @Select(value = "SELECT\n" +
            "\tce.`id` AS id,\n" +
            "\t`name`,\n" +
            "\t`label`,\n" +
            "\t`express`,\n" +
            "\t`create_time`,\n" +
            "\t`active` \n" +
            "FROM\n" +
            "\tcp_express AS ce\n" +
            "\tLEFT JOIN cp_cem_relation AS ccr ON ce.id = ccr.express_id \n" +
            "WHERE\n" +
            "\tccr.column_id = #{columnId}")
    @Results(
            id = "full",
            value = {
                    @Result(property = "id", column = "id", id = true),
                    @Result(property = "name", column = "name"),
                    @Result(property = "label", column = "label"),
                    @Result(property = "express", column = "express"),
                    @Result(property = "active", column = "active"),
                    @Result(property = "createTime", column = "create_time")
            })
    List<CpExpress> findByColumnId(@Param(value = "columnId") Long columnId);
}

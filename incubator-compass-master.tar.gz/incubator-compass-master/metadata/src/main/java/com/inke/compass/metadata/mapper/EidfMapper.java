package com.inke.compass.metadata.mapper;

import com.inke.compass.metadata.info.InputModelInfo;
import com.inke.compass.metadata.model.CpChlLevelName;
import com.inke.compass.metadata.model.CpDatatype;
import com.inke.compass.metadata.model.CpDeRelation;
import com.inke.compass.metadata.model.CpDhRelation;
import com.inke.compass.metadata.model.CpExpress;
import com.inke.compass.metadata.model.CpFilter;
import com.inke.compass.metadata.model.CpInputModel;
import com.inke.compass.metadata.model.CpUnits;
import com.inke.compass.metadata.relation.DatasetHiveRelation;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Set;

/**
 * incubator-compass
 * <p>Description :
 * 此页代码为 express\datatype\input_model\filter多个枚举表的mapper
 * <p>Author : 24k-xiao-shan
 * <p>Version : 1.0
 * <p>Create Time : 2021-01-07 21:21:24
 * <p>Author Email: <a href="mailTo:1912079423@qq.com">gaojunshan</a>
 */
public interface EidfMapper
{
    /**
     * 查询cp_express表
     *
     * @param id
     * @return
     */
    @Select(
            value =
                    "<script>"
                            + "select * FROM cp_express "
                            + "where 1 = 1 "
                            + "<if test=\"id != null\" >"
                            + " and id = #{id}"
                            + "</if>"
                            + "</script>")
    @Results(
            id = "express_find",
            value = {
                    @Result(property = "id", column = "id", id = true),
                    @Result(property = "name", column = "name"),
                    @Result(property = "label", column = "label"),
                    @Result(property = "active", column = "active"),
            })
    CpExpress expressFindById(@Param(value = "id") Long id);

    @Select(value = "SELECT * " +
            "FROM cp_express " +
            "WHERE name = #{name}")
    CpExpress findByName(@Param(value = "name") String name);

    /**
     * 查询cp_input_model表
     *
     * @param id
     * @return
     */
    @Select(
            value =
                    "<script>"
                            + "select * FROM cp_input_model "
                            + "where 1 = 1 "
                            + "<if test=\"id != null\" >"
                            + " and id = #{id}"
                            + "</if>"
                            + "</script>")
    @Results(
            id = "input_model_find",
            value = {
                    @Result(property = "id", column = "id", id = true),
                    @Result(property = "name", column = "name"),
                    @Result(property = "label", column = "label"),
                    @Result(property = "active", column = "active"),
            })
    CpInputModel inputModelFindById(@Param(value = "id") long id);

    /**
     * 查询cp_input_model表所有数据
     *
     * @return
     */
    @Select(
            value =
                    "<script>"
                            + "select * FROM cp_input_model "
                            + "where 1 = 1 "
                            + "</script>")
    @Results(
            id = "input_model_findAll",
            value = {
                    @Result(property = "id", column = "id", id = true),
                    @Result(property = "name", column = "name"),
                    @Result(property = "label", column = "label"),
                    @Result(property = "active", column = "active"),
            })
    Set<CpInputModel> inputModelFindAll();

    /**
     * 查询cp_datatype表
     *
     * @param id
     * @return
     */
    @Select(
            value =
                    "<script>"
                            + "select * FROM cp_datatype "
                            + "where 1 = 1 "
                            + "<if test=\"id != null\" >"
                            + " and id = #{id}"
                            + "</if>"
                            + "</script>")
    @Results(
            id = "datatype_find",
            value = {
                    @Result(property = "id", column = "id", id = true),
                    @Result(property = "name", column = "name"),
                    @Result(property = "label", column = "label"),
                    @Result(property = "active", column = "active"),
            })
    CpDatatype datatypeFindById(@Param(value = "id") Long id);

    /**
     * 查询cp_filter表
     *
     * @param id
     * @return
     */
    @Select(
            value =
                    "<script>"
                            + "select * FROM cp_filter "
                            + "where 1 = 1 "
                            + "<if test=\"id != null\" >"
                            + " and id = #{id}"
                            + "</if>"
                            + "</script>")
    @Results(
            id = "filter_find",
            value = {
                    @Result(property = "id", column = "id", id = true),
                    @Result(property = "name", column = "name"),
                    @Result(property = "label", column = "label"),
                    @Result(property = "active", column = "active"),
            })
    CpFilter cpFilterFindById(@Param(value = "id") Long id);

    /**
     * 查询cp_express表all
     */
    @Select(value = "select * FROM cp_express ")
    @Results(id = "express_all",
            value = {
                    @Result(property = "id", column = "id", id = true),
                    @Result(property = "name", column = "name"),
                    @Result(property = "label", column = "label"),
                    @Result(property = "active", column = "active"),
            })
    List<CpExpress> expressFindAll();

    /**
     * 查询cp_datatype表
     */
    @Select(value = "select * FROM cp_datatype ")
    @Results(
            id = "datatype_find_all",
            value = {
                    @Result(property = "id", column = "id", id = true),
                    @Result(property = "name", column = "name"),
                    @Result(property = "label", column = "label"),
                    @Result(property = "active", column = "active"),
            })
    List<CpDatatype> datatypeFindAll();

    /**
     * 查询cp_filter表all
     */
    @Select(value = "select * FROM cp_filter ")
    @Results(
            id = "filter_find_all",
            value = {
                    @Result(property = "id", column = "id", id = true),
                    @Result(property = "name", column = "name"),
                    @Result(property = "label", column = "label"),
                    @Result(property = "active", column = "active"),
            })
    List<CpFilter> cpFilterFindByAll();

    /**
     * 查询chl_level_name表all
     */
    @Select(value = "<script>" + "select * FROM cp_chl_level_name "
            + "where 1 = 1 "
            + "<if test=\"model.chlLevel1Name != null\" >"
            + " and chl_level1_name = #{model.chlLevel1Name}"
            + "</if>"
            + "<if test=\"model.chlLevel2Name != null\" >"
            + " and chl_level2_name = #{model.chlLevel2Name}"
            + "</if>"
            + "</script>")
    @Results(
            id = "chl_level_find_all",
            value = {
                    @Result(property = "id", column = "id", id = true),
                    @Result(property = "chlLevel1Name", column = "chl_level1_name"),
                    @Result(property = "chlLevel2Name", column = "chl_level2_name"),
                    @Result(property = "chlLevel3Name", column = "chl_level3_name"),
            })
    Set<CpChlLevelName> findCpChlLevelName(@Param(value = "model") CpChlLevelName cpChlLevelName);

    /**
     * 查询cp_units表
     *
     * @Author: Mfrain
     * @Date: 2021/3/8 6:11 下午
     * @return: java.util.List<com.inke.compass.metadata.model.CpUnits>
     */
    @Select(value = "select * FROM cp_units ")
    @Results(
            id = "unit_find_all",
            value = {
                    @Result(property = "id", column = "id", id = true),
                    @Result(property = "name", column = "name"),
                    @Result(property = "label", column = "label"),
                    @Result(property = "active", column = "active"),
            })
    List<CpUnits> unitFindAll();

    /**
     * unitFindById
     *
     * @param id:
     * @Author: Mfrain
     * @Date: 2021/3/8 6:13 下午
     * @return: com.inke.compass.metadata.model.CpUnits
     */
    @Select(
            value =
                    "<script>"
                            + "select * FROM cp_units "
                            + "where 1 = 1 "
                            + "<if test=\"id != null\" >"
                            + " and id = #{id}"
                            + "</if>"
                            + "</script>")
    @Results(
            id = "unit_find_by_id",
            value = {
                    @Result(property = "id", column = "id", id = true),
                    @Result(property = "name", column = "name"),
                    @Result(property = "label", column = "label"),
                    @Result(property = "active", column = "active"),
            })
    CpUnits unitFindById(@Param(value = "id") Long id);

    /**
     * <font color="yellow">findall</font>
     *
     * @Author: Mfrain
     * @Date: 2021/4/25 2:20 下午
     * @return: java.util.List<com.inke.compass.metadata.model.CpExpress>
     */
    @Select(value = "select * FROM cp_express ")
    @Results(id = "express_find_all", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "name", column = "name"),
            @Result(property = "label", column = "label"),
            @Result(property = "active", column = "active"),
    })
    List<CpExpress> findAllExpress();

    /**
     * <font color="yellow"></font>
     *
     * @param dataSetId
     * @Author: Mfrain
     * @Date: 2021/7/9 5:28 下午
     * @return: java.lang.Long
     */
    @Select(value = "select eventId FROM cp_de_relation where dataSetId = #{dataSetId}  ")
    Long getEventId(@Param(value = "dataSetId") Long dataSetId);

    @Insert(value = "<script>" +
            "INSERT INTO cp_de_relation (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"ctst.eventId != null\" >`eventId`,</if>" +
            "   <if test=\"ctst.dataSetId != null\" >`dataSetId`,</if>" +
            "</trim>) " +
            "VALUES (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"ctst.eventId != null\" >#{ctst.eventId},</if>" +
            "   <if test=\"ctst.dataSetId != null\" >#{ctst.dataSetId},</if>" +
            "</trim>)" +
            "</script>")
    @Options(useGeneratedKeys = true, keyProperty = "ctst.id", keyColumn = "id")
    void save(@Param(value = "ctst") CpDeRelation ctst);

    @Select(value = "select eventId, dataSetId from cp_de_relation where dataSetId = #{dataSetId}")
    @Results(id = "cpDeRelation", value = {
            @Result(property = "eventId", column = "eventId"),
            @Result(property = "dataSetId", column = "dataSetId")
    })
    CpDeRelation findDatasetAndEventRelationByDatasetId(@Param(value = "dataSetId") Long dataSetId);

    /**
     * <font color="yellow"></font>
     *
     * @param ctst
     * @Author: Mfrain
     * @Date: 2021/7/14 7:39 上午
     * @return: void
     */
    @Insert(value = "<script>" +
            "INSERT INTO cp_dh_relation (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"ctst.dsid != null\" >`dsid`,</if>" +
            "   <if test=\"ctst.htid != null\" >`htid`,</if>" +
            "</trim>) " +
            "VALUES (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"ctst.dsid != null\" >#{ctst.dsid},</if>" +
            "   <if test=\"ctst.htid != null\" >#{ctst.htid},</if>" +
            "</trim>)" +
            "</script>")
    @Options(useGeneratedKeys = true, keyProperty = "ctst.id", keyColumn = "id")
    void saveDh(@Param(value = "ctst") CpDhRelation ctst);

    /**
     * <font color="yellow"></font>
     *
     * @param dsid
     * @Author: Mfrain
     * @Date: 2021/7/14 7:32 上午
     * @return: java.util.List<com.inke.compass.metadata.model.CpExpress>
     */
    @Select(value = "select * FROM cp_dh_relation  where dsid = #{dsid}")
    @Results(id = "cp_dh_relation_find_all_by_dsid", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "dsid", column = "dsid"),
            @Result(property = "htid", column = "htid")
    })
    List<CpDhRelation> findHtIdByDsId(@Param(value = "dsid") long dsid);

    @Select(
            value = "SELECT name, label " +
                    "FROM cp_input_model "
                    + "WHERE id = #{id}")
    InputModelInfo findById(@Param(value = "id") Long id);

    @Delete(value = "DELETE FROM cp_dh_relation WHERE dsid = #{dataSetId}")
    Integer deleteDatasetAndHiveRelationByDatesetId(@Param(value = "dataSetId") Long dataSetId);

    @Select(value = "DELETE FROM cp_de_relation WHERE dataSetId = #{dataSetId}")
    Integer deleteDatasetAndEventRelationByDatasetId(@Param(value = "dataSetId") Long dataSetId);

    @Select(value = "select dsid, htid from cp_dh_relation where dsid = #{dataSetId}")
    @Results(id = "datasetAndHiveRelation", value = {
            @Result(property = "datasetId", column = "dsid"),
            @Result(property = "hiveId", column = "htid")
    })
    DatasetHiveRelation findDatasetAndHiveRelationByDatasetId(@Param(value = "dataSetId") Long dataSetId);
}

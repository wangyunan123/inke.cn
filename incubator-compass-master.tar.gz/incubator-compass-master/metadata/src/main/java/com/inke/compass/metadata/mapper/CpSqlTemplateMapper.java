/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.inke.compass.metadata.mapper;

import com.inke.compass.metadata.model.CpSqlTemplate;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.mybatis.guice.transactional.Transactional;

import java.util.List;

public interface CpSqlTemplateMapper
{
    @Insert(value = "<script>" +
            "INSERT INTO cp_sql_template (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"model.name != null\" >name,</if>" +
            "   <if test=\"model.type != null\" >`type`,</if>" +
            "   <if test=\"model.config != null\" >`config`,</if>" +
            "   <if test=\"model.template != null\" >`template`,</if>" +
            "</trim>) " +
            "VALUES (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"model.name != null\" >#{model.name},</if>" +
            "   <if test=\"model.type != null\" >#{model.type},</if>" +
            "   <if test=\"model.config != null\" >#{model.config},</if>" +
            "   <if test=\"model.template != null\" >#{model.template},</if>" +
            "</trim>)" +
            "</script>")
    @Options(useGeneratedKeys = true, keyProperty = "model.id")
    @Transactional
    int save(@Param(value = "model") CpSqlTemplate model);

    @Select(value = "SELECT * FROM cp_sql_template ")
    @Results(id = "cp_sql_template", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "name", column = "name"),
            @Result(property = "type", column = "type"),
            @Result(property = "unit", column = "unit"),
            @Result(property = "config", column = "config"),
            @Result(property = "hg", column = "hg"),
            @Result(property = "ck", column = "ck"),
            @Result(property = "active", column = "active"),
            @Result(property = "createTime", column = "create_time")
    })
    List<CpSqlTemplate> findAll();

    @Select(value = "SELECT * FROM cp_sql_template WHERE id = #{id} AND active=true")
    @ResultMap(value = "cp_sql_template")
    CpSqlTemplate findOne(Integer id);

    @Select(value = "SELECT * FROM cp_sql_template WHERE type = #{type} AND unit = #{unit} AND active=true")
    @ResultMap(value = "cp_sql_template")
    CpSqlTemplate findOneByTypeAndUnit(@Param(value = "type") String type,
            @Param(value = "unit") String unit);
}

package com.inke.compass.metadata.form.response;

import com.inke.compass.metadata.enums.CommonEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <p> incubator-compass</p>
 * <p> Description :  </p>
 * <p> @Author : 24k-xiao-shan </p>
 * <p> Version :  </p>
 * <p> Create Time :  2021-01-19 21:51:12 </p>
 * <p> Author Email: <a href="mailTo:1912079423@qq.com">gaojunshan</a> </p>
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class QueryResponse<T>
{
    private boolean success;
    private Object message;
    private int code;
    private long timestamp;
//    private String` client;
//    private String server;
//    private String username;
    private T data;
    private T error;

    public QueryResponse(boolean success)
    {
        this.success = success;
        this.code = success ? 0 : 1;
    }

    public static QueryResponse build(CommonEnum message)
    {
        QueryResponse result = new QueryResponse();
        result.setCodeMessage(message);
        return result;
    }

    public static <T> QueryResponse build(T data)
    {
        QueryResponse result = new QueryResponse();
        result.setData(data);
        return result;
    }

    public static <T> QueryResponse build(T data, T error)
    {
        QueryResponse result = new QueryResponse();
        result.setData(data);
//        result.setError(error);
        return result;
    }

    public static <T> QueryResponse build(CommonEnum message, T data)
    {
        QueryResponse result = new QueryResponse();
        result.setCodeMessage(message);
        result.setData(data);
        return result;
    }

    public static <T> QueryResponse build(CommonEnum message, String details, T data)
    {
        QueryResponse result = new QueryResponse();
        result.setCode(message.getCode());
        result.setMessage(message.getValue() + ": " + details);
        result.setData(data);
        return result;
    }

    public static <T> QueryResponse build(CommonEnum message, T data, T error)
    {
        QueryResponse result = new QueryResponse();
        result.setCodeMessage(message);
        result.setData(data);
        result.setError(error);
        return result;
    }

    public void setSuccess(boolean success)
    {
        this.success = success;
        this.code = success ? 0 : 1;
    }

    private void setCodeMessage(CommonEnum enums)
    {
        this.code = enums.getCode();
        this.message = enums.getValue();
    }
}

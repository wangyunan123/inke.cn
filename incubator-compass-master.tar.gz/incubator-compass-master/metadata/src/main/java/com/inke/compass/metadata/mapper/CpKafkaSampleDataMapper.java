package com.inke.compass.metadata.mapper;

import com.inke.compass.metadata.model.CpKafkaConnection;
import com.inke.compass.metadata.model.CpKafkaSampleData;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultType;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

public interface CpKafkaSampleDataMapper
{
    @Insert(value = "<script>" +
            "INSERT INTO cp_kafka_sample_data(<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"ksd.sampleData != null\">`sample_data`,</if>" +
            "   <if test=\"ksd.topic != null\">`topic`,</if>" +
            "   <if test=\"ksd.zkAddr != null\">`zk_addr`,</if>" +
            "   <if test=\"ksd.createUser != null\">`create_user`</if>" +
            "</trim>) " +
            "VALUES (<trim prefix=\"\" suffixOverride=\",\">" +
            "   <if test=\"ksd.sampleData != null\">#{ksd.sampleData},</if>" +
            "   <if test=\"ksd.topic != null\">#{ksd.topic},</if>" +
            "   <if test=\"ksd.zkAddr != null\">#{ksd.zkAddr},</if>" +
            "   <if test=\"ksd.createUser != null\">#{ksd.createUser}</if>" +
            "</trim>)" +
            "</script>")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    void save(@Param(value = "ksd") CpKafkaSampleData ksd);

    @Update(value = "<script>" +
            "UPDATE cp_kafka_sample_data" +
            "<set>" +
            "   <if test=\"ksd.sampleData != null\">" +
            "       sample_data = #{ksd.sampleData}" +
            "   </if>" +
            "</set>" +
            "WHERE id = #{ksd.id}"+
            "</script>")
    void updateById(@Param(value = "ksd") CpKafkaSampleData ksd);

    @Update(value = "<script>" +
            "UPDATE cp_kafka_sample_data" +
            "<set>" +
            "   <if test=\"ksd.sampleData != null\">" +
            "       sample_data = #{ksd.sampleData}" +
            "   </if>" +
            "</set>" +
            "WHERE zk_addr = #{ksd.zkAddr} AND topic = #{ksd.topic}" +
            "</script>")
    void updateByZkAddrAndTopic(@Param(value = "ksd") CpKafkaSampleData ksd);

    @Select(value = "SELECT * FROM cp_kafka_sample_data WHERE zk_addr = #{zkAddr} AND topic = #{topic}")
    @Results(id = "get_ksd_by_addr_and_topic", value = {
            @Result(property = "id", column = "id"),
            @Result(property = "sampleData", column = "sample_data"),
            @Result(property = "topic", column = "topic"),
            @Result(property = "zkAddr", column = "zk_addr"),
            @Result(property = "createUser", column = "create_user"),
            @Result(property = "createTime", column = "create_time"),
    })
    CpKafkaSampleData getByZkAddrAndTopic(@Param(value = "zkAddr") String zkAddr, @Param(value = "topic") String topic);

    @Select(value = "SELECT * FROM cp_kafka_sample_data WHERE id = #{id}")
    @Results(id = "get_ksd_by_id", value = {
            @Result(property = "id", column = "id"),
            @Result(property = "sampleData", column = "sample_data"),
            @Result(property = "topic", column = "topic"),
            @Result(property = "zkAddr", column = "zk_addr"),
            @Result(property = "createUser", column = "create_user"),
            @Result(property = "createTime", column = "create_time"),
    })
    CpKafkaSampleData getById(@Param(value = "id") Long id);

    @Select(value = "SELECT COUNT(1) FROM cp_kafka_sample_data WHERE `zk_addr` = #{zkAddr} AND `topic` = #{topic}")
    @ResultType(value = Integer.class)
    Integer getTotalByAddrAndTopic(@Param(value = "zkAddr") String zkAddr, @Param(value = "topic") String topic);
}

package com.inke.compass.metadata.mapper;

import com.inke.compass.metadata.model.CpCudRelation;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

/**
 * <p> @Description : 维度上卷下钻维度关系操作mapper </p>
 * <p> @incubator-compass </p>
 * <p> @Author : Mfrain </p>
 * <p> @Create Time : 2021/1/27 9:51 下午 </p>
 * <p> @Author Amail: <a href="mailTo:mfr1339941169@qq.com">Mfrain</a> </p>
 * <p> @Version : 1.0 </p>
 */
public interface CpCudRelationMapper
{
    /**
     * save
     *
     * @param cudRelation:
     * @Author: Mfrain
     * @Date: 2021/1/17 9:54 下午
     * @return: void
     */
    @Insert(value = "<script>" +
            "INSERT INTO cp_cud_relation (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"cudRelation.columnId != null\" >`column_id`,</if>" +
            "   <if test=\"cudRelation.rollUpId != null\" >`roll_up_id`,</if>" +
            "   <if test=\"cudRelation.drillDownId != null\" >`drill_down_id`,</if>" +
            "</trim>) " +
            "VALUES (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"cudRelation.columnId != null\" >#{cudRelation.columnId},</if>" +
            "   <if test=\"cudRelation.rollUpId != null\" >#{cudRelation.rollUpId},</if>" +
            "   <if test=\"cudRelation.drillDownId != null\" >#{cudRelation.drillDownId},</if>" +
            "</trim>)" +
            "</script>")
    @Options(useGeneratedKeys = false)
    void save(@Param(value = "cudRelation") CpCudRelation cudRelation);

    /**
     * update
     *
     * @param cudRelation:
     * @Author: Mfrain
     * @Date: 2021/1/17 10:08 下午
     * @return: void
     */
    @Update("<script>" +
            "update cp_cud_relation" +
            "    <set >" +
            "      <if test=\"cudRelation.rollUpId != null\" >" +
            "        roll_up_id = #{cudRelation.rollUpId},    " +
            "      </if>" +
            "      <if test=\"cudRelation.drillDownId != null\" >" +
            "        drill_down_id = #{cudRelation.drillDownId}," +
            "      </if>" +
            "    </set>" +
            "    where column_id = #{cudRelation.columnId}" +
            "</script>")
    void update(@Param(value = "cudRelation") CpCudRelation cudRelation);

    /**
     * select all
     *
     * @Author: Mfrain
     * @Date: 2021/1/17 10:04 下午
     * @return: java.util.List<com.inke.compass.metadata.model.CpEvent>
     */
    @Select(value = "SELECT * FROM cp_cud_relation ")
    @Results(id = "cp_cud_relation_all_2", value = {
            @Result(property = "columnId", column = "column_id", id = true),
            @Result(property = "rollUpId", column = "roll_up_id"),
            @Result(property = "drillDownId", column = "drill_down_id")
    })
    List<CpCudRelation> findAll();

    /**
     * getOne
     *
     * @param columnId:
     * @Author: Mfrain
     * @Date: 2021/3/9 5:31 下午
     * @return: com.inke.compass.metadata.model.CpCudRelation
     */
    @Select(value = "SELECT * FROM cp_cud_relation where column_id = #{columnId}")
    @Results(id = "cp_cud_relation_all_1", value = {
            @Result(property = "columnId", column = "column_id", id = true),
            @Result(property = "rollUpId", column = "roll_up_id"),
            @Result(property = "drillDownId", column = "drill_down_id")
    })
    CpCudRelation getOne(@Param(value = "columnId") long columnId);

    /**
     * deleteBycolumnId
     *
     * @param columnId:
     * @Author: Mfrain
     * @Date: 2021/1/17 10:11 下午
     * @return: void
     */
    @Delete("<script>" +
            "delete from cp_cud_relation " +
            " where column_id = #{columnId}" +
            "</script>")
    void deleteByColumnId(@Param(value = "columnId") long columnId);
}

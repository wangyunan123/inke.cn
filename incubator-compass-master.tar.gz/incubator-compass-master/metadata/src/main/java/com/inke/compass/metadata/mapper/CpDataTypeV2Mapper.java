package com.inke.compass.metadata.mapper;

import com.inke.compass.metadata.model.CpDataTypeV2;
import org.apache.ibatis.annotations.*;

import java.util.List;
import java.util.Map;

public interface CpDataTypeV2Mapper
{
    @Insert(value = "<script>" +
            "INSERT INTO cp_data_type(<trim prefix=\"\" suffixOverrides=\",\">" +
            "<if test=\"md.name != null\">`name`,</if>" +
            "<if test=\"md.type != null\">`type`,</if>" +
            "<if test=\"md.label_en\t != null\">`label_en`,</if>" +
            "<if test=\"md.label_zh != null\">`label_zh`,</if>" +
            "<if test=\"md.description != null\">`description`,</if>" +
            "<if test=\"md.version != null\">`version`,</if>" +
            "<if test=\"md.last_version != null\">`last_version`,</if>" +
            "<if test=\"md.check != null\">`check`,</if>" +
            "<if test=\"md.mock != null\">`mock`,</if>" +
            "<if test=\"md.relation != null\">`relation`,</if>" +
            "<if test=\"md.create_time != null\">`create_time`,</if>" +
            "<if test=\"md.last_time != null\">`last_time`,</if>" +
            "<if test=\"md.create_user != null\">`create_user`,</if>" +
            "<if test=\"md.active != null\">`active`,</if>" +
            "</trim>) " +
            "VALUES (<trim prefix=\"\" suffixOverride=\",\">" +
            "<if test=\"md.name != null\">#{md.name},</if>" +
            "<if test=\"md.type != null\">#{md.type},</if>" +
            "<if test=\"md.label_en != null\">#{md.label_en},</if>" +
            "<if test=\"md.label_zh != null\">#{md.label_zh},</if>" +
            "<if test=\"md.description != null\">#{md.description},</if>" +
            "<if test=\"md.version != null\">#{md.version},</if>" +
            "<if test=\"md.last_version != null\">#{md.last_version},</if>" +
            "<if test=\"md.check != null\">#{md.check},</if>" +
            "<if test=\"md.mock != null\">#{md.mock},</if>" +
            "<if test=\"md.relation != null\">#{md.relation},</if>" +
            "<if test=\"md.create_time != null\">#{md.create_time},</if>" +
            "<if test=\"md.last_time != null\">#{md.last_time},</if>" +
            "<if test=\"md.create_user != null\">#{md.create_user},</if>" +
            "<if test=\"md.active != null\">#{md.active},</if>" +
            "</trim>)" +
            "</script>")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    void save(@Param(value = "md") CpDataTypeV2 md);

    @Update(value = "<script>" +
            "UPDATE cp_data_type" +
            "<set>" +
            "   <if test=\"md.name != null\">" +
            "       name = #{md.name}," +
            "   </if>" +
            "   <if test=\"md.type != null\">" +
            "       type = #{md.type}," +
            "   </if>" +
            "   <if test=\"md.label_en != null\">" +
            "       label_en = #{md.label_en}," +
            "   </if>" +
            "   <if test=\"md.label_zh != null\">" +
            "       label_zh = #{md.label_zh}," +
            "   </if>" +
            "   <if test=\"md.description != null\">" +
            "       description = #{md.description}," +
            "   </if>" +
            "   <if test=\"md.version != null\">" +
            "       version = #{md.version}," +
            "   </if>" +
            "   <if test=\"md.last_version != null\">" +
            "       last_version = #{md.last_version}," +
            "   </if>" +
            "   <if test=\"md.check != null\">" +
            "       check = #{md.check}," +
            "   </if>" +
            "   <if test=\"md.mock != null\">" +
            "       mock = #{md.mock}," +
            "   </if>" +
            "   <if test=\"md.relation != null\">" +
            "       mock = #{md.relation}," +
            "   </if>" +
            "   <if test=\"md.create_time != null\">" +
            "       create_time = #{md.create_time}," +
            "   </if>" +
            "   <if test=\"md.last_time != null\">" +
            "       last_time = #{md.last_time}," +
            "   </if>" +
            "   <if test=\"md.create_user != null\">" +
            "       create_user = #{md.create_user}," +
            "   </if>" +
            "   <if test=\"md.active != null\">" +
            "       active = #{md.active}," +
            "   </if>" +
            "</set>)" +
            "WHERE id = #{md.id}" +
            "</script>")
    void update(@Param(value = "md") CpDataTypeV2 md);

    @Select(value = "SELECT * FROM cp_data_type WHERE id = #{id}")
    @Results(id = "get_md_by_id", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "name", column = "name"),
            @Result(property = "type", column = "type"),
            @Result(property = "label_en", column = "label_en"),
            @Result(property = "label_zh", column = "label_zh"),
            @Result(property = "description", column = "description"),
            @Result(property = "version", column = "version"),
            @Result(property = "last_version", column = "last_version"),
            @Result(property = "check", column = "check"),
            @Result(property = "mock", column = "mock"),
            @Result(property = "relation", column = "relation"),
            @Result(property = "create_time", column = "create_time"),
            @Result(property = "last_time", column = "last_time"),
            @Result(property = "create_user", column = "create_user"),
            @Result(property = "active", column = "active"),
    })
    List<CpDataTypeV2> findAllById();


    @Select(value = "SELECT * FROM cp_data_type WHERE type ='CLICKHOUSE'")
    @ResultMap(value = "get_md_by_name")
    List<CpDataTypeV2> findAll();

    @Select(value = "SELECT * FROM cp_data_type WHERE name = #{name}")
    @Results(id = "get_md_by_name", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "name", column = "name"),
            @Result(property = "type", column = "type"),
            @Result(property = "label_en", column = "label_en"),
            @Result(property = "label_zh", column = "label_zh"),
            @Result(property = "description", column = "description"),
            @Result(property = "version", column = "version"),
            @Result(property = "last_version", column = "last_version"),
            @Result(property = "check", column = "check"),
            @Result(property = "mock", column = "mock"),
            @Result(property = "relation", column = "relation"),
            @Result(property = "create_time", column = "create_time"),
            @Result(property = "last_time", column = "last_time"),
            @Result(property = "create_user", column = "create_user"),
            @Result(property = "active", column = "active"),
    })
    List<CpDataTypeV2> findAllByName();

    @Select(value = "SELECT\n" +
            "  distinct \n"+
            "    cp.id AS id,\n" +
            "    cp.`name` AS `name`,\n" +
            "    cp.label AS label,\n" +
            "    cp.type AS type\n" +
            "FROM cp_edt_relation AS cer\n" +
            "LEFT JOIN cp_filter AS  cp ON cer.filter_id = cp.id\n" +
            "WHERE cer.data_type_id = #{dataTypeId}")
    List<Map<String, String>> getFiltersById(@Param(value = "dataTypeId") Long dataTypeId);

    @Select(value = "SELECT\n" +
            "  distinct \n"+
            "    ce.id AS id,\n" +
            "    ce.`name` AS `name`,\n" +
            "    ce.label AS label,\n" +
            "    ce.express AS express\n" +
            "FROM cp_edt_relation AS cer\n" +
            "LEFT JOIN cp_express AS ce ON cer.express_id = ce.id\n" +
            "WHERE cer.data_type_id = #{dataTypeId}")
    List<Map<String, String>> getExpressById(@Param(value = "dataTypeId") Long dataTypeId);
}


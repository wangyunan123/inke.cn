package com.inke.compass.metadata.mapper;

import com.inke.compass.metadata.form.DataSetAndPartition;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
 * <p> @Description : app信息mapper </p>
 * <p> @incubator-compass </p>
 * <p> @Author : Mfrain </p>
 * <p> @Create Time : 2021/1/5 4:58 下午 </p>
 * <p> @Author Email: <a href="mailTo:mfr1339941169@qq.com">Mfrain</a> </p>
 * <p> @Version : 1.0 </p>
 */
public interface DataSetAndPartitionMapper
{

    @Insert(value = "<script>" +
            "INSERT INTO dataset_partition_relation (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"dataSetAndPartition.dataset_id != null\" >`dataset_id`,</if>" +
            "   <if test=\"dataSetAndPartition.is_no_partition != null\" >`is_no_partition`,</if>" +
            "</trim>) " +
            "VALUES (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"dataSetAndPartition.dataset_id != null\" >#{dataSetAndPartition.dataset_id},</if>" +
            "   <if test=\"dataSetAndPartition.is_no_partition != null\" >#{dataSetAndPartition.is_no_partition},</if>" +
            "</trim>)" +
            "</script>")
    @Options(useGeneratedKeys = true, keyProperty = "app.dataset_id", keyColumn = "dataset_id")
    void save(@Param(value = "dataSetAndPartition") DataSetAndPartition dataSetAndPartition);



    @Select(value = "SELECT is_no_partition FROM dataset_partition_relation WHERE dataset_id = #{dataset_id}")
    String dataSetAndPartition(@Param(value = "dataset_id") long dataset_id);

    @Select(value = "SELECT count(1) as dataset_num FROM dataset_partition_relation WHERE dataset_id = #{dataset_id}")
    Long dataSetNum(@Param(value = "dataset_id") long dataset_id);




}
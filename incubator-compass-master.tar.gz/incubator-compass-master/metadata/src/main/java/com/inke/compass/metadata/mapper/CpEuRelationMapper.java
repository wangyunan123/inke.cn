package com.inke.compass.metadata.mapper;

import com.inke.compass.metadata.model.CpEuRelation;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

/**
 * <p> @Description : 事件units关系操作mapper </p>
 * <p> @incubator-compass </p>
 * <p> @Author : Mfrain </p>
 * <p> @Create Time : 2021/1/17 9:51 下午 </p>
 * <p> @Author Email: <a href="mailTo:mfr1339941169@qq.com">Mfrain</a> </p>
 * <p> @Version : 1.0 </p>
 */
public interface CpEuRelationMapper
{
    /**
     * save
     *
     * @param euRelation:
     * @Author: Mfrain
     * @Date: 2021/1/17 9:54 下午
     * @return: void
     */
    @Insert(value = "<script>" +
            "INSERT INTO cp_eu_relation (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"eu.eventId != null\" >`event_id`,</if>" +
            "   <if test=\"eu.unitId != null\" >`unit_id`,</if>" +
            "</trim>) " +
            "VALUES (<trim prefix=\"\" suffixOverrides=\",\">" +
            "   <if test=\"eu.eventId != null\" >#{eu.eventId},</if>" +
            "   <if test=\"eu.unitId != null\" >#{eu.unitId},</if>" +
            "</trim>)" +
            "</script>")
    @Options(useGeneratedKeys = true)
    void save(@Param(value = "eu") CpEuRelation euRelation);

    /**
     * update
     *
     * @param euRelation:
     * @Author: Mfrain
     * @Date: 2021/1/17 10:08 下午
     * @return: void
     */
    @Update("<script>" +
            "update cp_eu_relation" +
            "    <set >" +
            "      <if test=\"eu.eventId != null\" >" +
            "        event_id = #{eu.eventId},    " +
            "      </if>" +
            "      <if test=\"eu.unitId != null\" >" +
            "        unit_id = #{eu.unitId}," +
            "      </if>" +
            "    </set>" +
            "    where id = #{eu.id}" +
            "</script>")
    void update(@Param(value = "eu") CpEuRelation euRelation);

    /**
     * select all
     *
     * @Author: Mfrain
     * @Date: 2021/1/17 10:04 下午
     * @return: java.util.List<com.inke.compass.metadata.model.CpEvent>
     */
    @Select(value = "SELECT * FROM cp_eu_relation ")
    @Results(id = "cp_eu_relation_all", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "eventId", column = "event_id"),
            @Result(property = "unitId", column = "unit_id")
    })
    List<CpEuRelation> findAll();

    /**
     * findAllByEventId
     *
     * @param eventId:
     * @Author: Mfrain
     * @Date: 2021/1/17 10:15 下午
     * @return: java.util.List<com.inke.compass.metadata.model.CpEuRelation>
     */
    @Select(value = "SELECT * FROM cp_eu_relation where event_id = #{eventId}")
    @Results(id = "cp_eu_relation_all_findAllByEventId", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "eventId", column = "event_id"),
            @Result(property = "unitId", column = "unit_id")
    })
    List<CpEuRelation> findAllByEventId(@Param(value = "eventId") long eventId);

    /**
     * findAllByUnitId
     *
     * @param unitId:
     * @Author: Mfrain
     * @Date: 2021/1/17 10:15 下午
     * @return: java.util.List<com.inke.compass.metadata.model.CpEuRelation>
     */
    @Select(value = "SELECT * FROM cp_eu_relation where unit_id = #{unitId}")
    @Results(id = "cp_eu_relation_all_findAllByUnitId", value = {
            @Result(property = "id", column = "id", id = true),
            @Result(property = "eventId", column = "event_id"),
            @Result(property = "unitId", column = "unit_id")
    })
    List<CpEuRelation> findAllByUnitId(@Param(value = "unitId") long unitId);

    /**
     * deleteByEventId
     *
     * @param eventId:
     * @Author: Mfrain
     * @Date: 2021/1/17 10:11 下午
     * @return: void
     */
    @Delete("<script>" +
            "delete from cp_eu_relation " +
            " where event_id = #{eventId}" +
            "</script>")
    void deleteByEventId(@Param(value = "eventId") long eventId);

    /**
     * deleteByUnitId
     *
     * @param unitId:
     * @Author: Mfrain
     * @Date: 2021/1/17 10:11 下午
     * @return: void
     */
    @Delete("<script>" +
            "delete from cp_eu_relation " +
            " where unit_id = #{unitId}" +
            "</script>")
    void deleteByUnitId(@Param(value = "unitId") long unitId);

    /**
     * findEventIdByUnitId
     *
     * @param unitId:
     * @Author: Mfrain
     * @Date: 2021/1/18 1:42 上午
     * @return: java.util.List<java.lang.Long>
     */
    @Select(value = "SELECT distinct event_id FROM cp_eu_relation  where unit_id = #{unitId}")
    List<Long> findEventIdByUnitId(@Param(value = "unitId") long unitId);

    /**
     * findUnitIdByEventId
     *
     * @param eventId:
     * @Author: Mfrain
     * @Date: 2021/1/18 1:42 上午
     * @return: java.util.List<java.lang.Long>
     */
    @Select(value = "SELECT distinct unit_id FROM cp_eu_relation  where event_id = #{eventId}")
    List<Long> findUnitIdByEventId(@Param(value = "eventId") long eventId);
}
